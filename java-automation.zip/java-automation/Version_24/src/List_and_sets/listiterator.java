package List_and_sets;
import java.util.*;
public class listiterator {


	    static void listDisplay() {
	        List<String> name = new ArrayList<>();

	        name.add("Sanjee");
	        name.add("Jaya");
	        name.add("Jaya");
	        name.add(null);
	        name.add("Ananya");
	        name.add(null);

	        ListIterator<String> allvalues = name.listIterator();

	        System.out.println("Forward direction:");
	        while (allvalues.hasNext()) {
	        System.out.println(allvalues.next());
	        }

	        System.out.println(" ");
	        System.out.println("Backward direction:");

	        while (allvalues.hasPrevious()) {
	        System.out.println(allvalues.previous());
	        }
	    }

	    public static void main(String[] args) {
	        listDisplay();
	    }
	}
