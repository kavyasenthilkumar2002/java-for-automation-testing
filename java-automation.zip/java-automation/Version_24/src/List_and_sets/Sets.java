package List_and_sets;
import java.util.*;
public class Sets {


				static void demo() {
		        Set<Integer> rollno = new HashSet<>();

		        rollno.add(102);
		        rollno.add(102);
		        rollno.add(103);
		        rollno.add(null);
		        rollno.add(null);

		        System.out.println(rollno);
		    }

		    static void demo1() {
		        Set<String> name = new HashSet<>();

		        name.add(null);
		        name.add("Anu");
		        name.add("Kavya");
		        name.add(null);
		        name.add("Jaya");
		        name.add("Sanjee");
		        name.add("Ananya");
		        name.add(null);

		        System.out.println(name);
		    }

		    public static void main(String[] args) {
		        demo();
		        demo1();
		    }
		}

