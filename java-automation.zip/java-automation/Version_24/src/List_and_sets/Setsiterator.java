package List_and_sets;
import java.util.*;
public class Setsiterator {
  
	    		static void listDisplay() {
		        Set <String> name = new HashSet<>();

		        name.add("Sanjee");
		        name.add("Jaya");
		        name.add("Jaya");
		        name.add(null);
		        name.add("Ananya");
		        name.add("Kavya");

		        Iterator <String> allvalues = name.iterator();

		        System.out.println("Forward direction:");
		        while (allvalues.hasNext()) {
		        System.out.println(allvalues.next());
		        }
	    		}
		    
	    		
		    public static void main(String[] args) {
		        listDisplay();
		    }
		}
			
	  
