package List_and_sets;
import java.util.*; 
public class list {

	    
	static void demo() {
        Set<Integer> rollno = new HashSet<>();

        rollno.add(null);
        rollno.add(102);
        rollno.add(102);
        rollno.add(103);
        rollno.add(111);
        rollno.add(null);

        System.out.println(rollno);
    }
	
	static void listDisplay() {
	        List<String> name = new ArrayList<>();

	        name.add("Sanjee");
	        name.add("Anu");
	        name.add("Kavya");
	        name.add(null);
	        name.add("Jaya");
	        name.add("Anu");
	        name.add("Ananya");
	        name.add(null);

	        System.out.println(name);
	    }

	    static void array() {
	        System.out.println("Array method called");
	    }

	    public static void main(String[] args) {
	        demo();
	    	listDisplay();
	        array();
	    }
	}
