package IfCondition;
public class ifcondition {

	void meesho(int productId)
	{
		if(productId > 10)
		{
			System.out.println("Ordered");
		}
		else
		{
			System.out.println("Not Ordered");
		}
	}
	
	void meesho_profile(int customer_id,int productid)
	{
		if(productid > 10 && customer_id < 8 )
		{
			System.out.println("Confirm Ordered");
		}
		else
		{
			System.out.println("Not Confirm Ordered");
		}
	}
	
	void meesho_phnlist(int meesho_id,int meesho_num)
	{
		if(meesho_id > 10 || meesho_num < 8 )
		{
			System.out.println("Packed");
		}
		else
		{
			System.out.println("Not Packed");
		}
	}
	
	void display()
	{
		this.meesho(5);
		this.meesho_profile(5,7);
		this.meesho_phnlist(3,5);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ifcondition b=new ifcondition();
		b.display();
	}

}
