package StringandStringBuilder;

public class StringBuildersss {

    void s() {
        StringBuilder name=new StringBuilder("Meesho");
        name.append(" Application"); 
        System.out.println(name);      
    }

    public static void main(String[] args) {
    	StringBuildersss obj = new StringBuildersss(); 
        obj.s();                                
    }
}
