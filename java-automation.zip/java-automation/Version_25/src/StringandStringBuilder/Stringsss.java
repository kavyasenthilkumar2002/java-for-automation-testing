package StringandStringBuilder;

public class Stringsss {
  

	    void s() {
	        String name = "Qtree";
	        name = name.concat(" Technology"); 
	        System.out.println(name);      
	    }

	    public static void main(String[] args) {
	    	Stringsss obj = new Stringsss(); 
	        obj.s();                                
	    }
	}
