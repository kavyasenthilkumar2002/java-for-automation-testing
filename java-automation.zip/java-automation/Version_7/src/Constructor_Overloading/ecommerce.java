package Constructor_Overloading;

public class ecommerce {

    void login(String username, String password) {
    	System.out.println("Constructor Overloading");
    	System.out.println("Username: " + username);
        System.out.println("Password: " + password);
    }

    void login1(int phoneNumber, int OTP) {
        System.out.println("Phone number: " + phoneNumber);
        System.out.println("OTP: " + OTP);
    }

    public static void main(String[] args) {
        ecommerce meesho = new ecommerce();
        meesho.login("Anu", "meesho456");
        meesho.login1(912345670, 987654);
    }
}
