package Static_asblock;

public class Ecommerce {

    // STATIC VARIABLE
    static int customer_number;

    // GLOBAL VARIABLE
    int number_of_orders;
    String platform_name;

    // STATIC BLOCK
    static {
        System.out.println("Welcome to Meesho E-commerce!");
    }

    // STATIC METHOD
    static void demo() {
        customer_number++;
        int number_of_orders = 3; // local
        System.out.println("Customer Number : " + customer_number);
        System.out.println("Orders Placed : " + number_of_orders);
    }

    // NON-STATIC METHOD
    void demo1() {
        customer_number++;
        int number_of_orders = 5; // local
        System.out.println("Customer Number : " + customer_number);
        System.out.println("Orders Placed : " + number_of_orders);
    }

    public static void main(String[] args) {
        demo();
        Ecommerce obj = new Ecommerce();
        obj.demo1();
    }
}