package Static_asblock;

public class Insurance {
	
	// STATIC VARIABLE
    static int policy_id;

    // GLOBAL VARIABLE
    int claim_number;
    String policy_name;

    // STATIC BLOCK
    static {
        System.out.println("Welcome to Acko Insurance!");
    }

    // STATIC METHOD
    static void demo() {
        policy_id++;
        int claim_number = 2001; // local
        System.out.println("Policy ID : " + policy_id);
        System.out.println("Claim Number : " + claim_number);
    }

    // NON-STATIC METHOD
    void demo1() {
        policy_id++;
        int claim_number = 3002; // local
        System.out.println("Policy ID : " + policy_id);
        System.out.println("Claim Number : " + claim_number);
    }

    public static void main(String[] args) {
        demo();
        Insurance obj = new Insurance();
        obj.demo1();
    }
}