package Static_asblock;

public class Hospital {

    // STATIC VARIABLE
    static int patient_id;

    // GLOBAL VARIABLE
    int ward_number;
    String doctor_name;

    // STATIC BLOCK
    static {
        System.out.println("Welcome to Kuppusamy Hospital!");
    }

    // STATIC METHOD
    static void demo() {
        patient_id++;
        int ward_number = 101; // local
        System.out.println("Patient ID : " + patient_id);
        System.out.println("Ward Number : " + ward_number);
    }

    // NON-STATIC METHOD
    void demo1() {
        patient_id++;
        int ward_number = 202; // local
        System.out.println("Patient ID : " + patient_id);
        System.out.println("Ward Number : " + ward_number);
    }

    public static void main(String[] args) {
        demo();
        Hospital obj = new Hospital();
        obj.demo1();
    }
}