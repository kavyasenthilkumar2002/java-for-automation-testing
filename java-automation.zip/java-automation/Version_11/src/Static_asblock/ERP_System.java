package Static_asblock;

public class ERP_System {
	
	// STATIC VARIABLE
    static int user_id;

    // GLOBAL VARIABLE
    int module_count;
    String module_name;

    // STATIC BLOCK
    static {
        System.out.println("Welcome to ERP Management System!");
    }

    // STATIC METHOD
    static void demo() {
        user_id++;
        int module_count = 4; // local
        System.out.println("User ID : " + user_id);
        System.out.println("Modules Assigned : " + module_count);
    }

    // NON-STATIC METHOD
    void demo1() {
        user_id++;
        int module_count = 6; // local
        System.out.println("User ID : " + user_id);
        System.out.println("Modules Assigned : " + module_count);
    }

    public static void main(String[] args) {
        demo();
        ERP_System obj = new ERP_System();
        obj.demo1();
    }
}