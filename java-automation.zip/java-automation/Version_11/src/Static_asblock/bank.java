package Static_asblock;

public class bank {

    // STATIC VARIABLE
    static int account_number;

    // GLOBAL VARIABLE
    int balance;
    String branch_name;

    // STATIC BLOCK
    static {
        System.out.println("Welcome to Indian Bank Services!");
    }

    // STATIC METHOD
    static void demo() {
        account_number++;
        int balance = 5000; // local
        System.out.println("Account Number : " + account_number);
        System.out.println("Balance : " + balance);
    }

    // NON-STATIC METHOD
    void demo1() {
        account_number++;
        int balance = 10000; // local
        System.out.println("Account Number : " + account_number);
        System.out.println("Balance : " + balance);
    }

    public static void main(String[] args) {
        demo();
        bank obj = new bank();
        obj.demo1();
    }
}