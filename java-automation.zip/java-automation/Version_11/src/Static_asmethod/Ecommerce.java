package Static_asmethod;

public class Ecommerce {

	    
	    // STATIC VARIABLE
	    static int orderId;
	    
	    // GLOBAL VARIABLE
	    int cartItems;
	    String productName;
	    
	    // STATIC METHOD
	    static void demo() {
	        orderId++;
	        int cartItems = 5;
	        
	        System.out.println("E-COMMERCE");
	        System.out.println("Order ID : " + orderId);
	        System.out.println("Cart Items : " + cartItems);
	        System.out.println("------------------");
	    }
	    
	    // NON-STATIC METHOD
	    void demo1() {
	        orderId++;
	        System.out.println("Order ID : " + orderId);
	        System.out.println("Cart Items : " + cartItems);
	        System.out.println("------------------");
	    }
	    
	    public static void main(String[] args) {
	        demo();
	        Ecommerce e = new Ecommerce();
	        e.demo1();
	    }
	}

