package Static_asmethod;

public class ERP_System {

	 // STATIC VARIABLE
    static int moduleId;
    
    // GLOBAL VARIABLE
    int activeUsers;
    String moduleName;
    
    // STATIC METHOD
    static void demo() {
        moduleId++;
        int activeUsers = 100;
        
        System.out.println("ERP SYSTEM");
        System.out.println("Module ID : " + moduleId);
        System.out.println("Active Users : " + activeUsers);
        System.out.println("------------------");
    }
    
    // NON-STATIC METHOD
    void demo1() {
        moduleId++;
        System.out.println("Module ID : " + moduleId);
        System.out.println("Active Users : " + activeUsers);
        System.out.println("------------------");
    }
    
    public static void main(String[] args) {
        demo();
        ERP_System e = new ERP_System();
        e.demo1();
    }
}
