package Static_asmethod;

public class Insurance {
    
    // STATIC VARIABLE
    static int policyNo;
    
    // GLOBAL VARIABLE
    int claimCount;
    String policyType;
    
    // STATIC METHOD
    static void demo() {
        policyNo++;
        int claimCount = 3;
        
        System.out.println("INSURANCE");
        System.out.println("Policy Number : " + policyNo);
        System.out.println("Claim Count : " + claimCount);
        System.out.println("------------------");
    }
    
    // NON-STATIC METHOD
    void demo1() {
        policyNo++;
        System.out.println("Policy Number : " + policyNo);
        System.out.println("Claim Count : " + claimCount);
        System.out.println("------------------");
    }
    
    public static void main(String[] args) {
        demo();
        Insurance i = new Insurance();
        i.demo1();
    }
}
