package Static_asmethod;

public class Hospital {
    
    // STATIC VARIABLE
    static int hospitalId;
    
    // GLOBAL VARIABLE
    int patientCount;
    String doctorName;
    
    // STATIC METHOD
    static void demo() {
        hospitalId++;
        int patientCount = 20;
        
        System.out.println("HOSPITAL");
        System.out.println("Hospital ID : " + hospitalId);
        System.out.println("Patient Count : " + patientCount);
        System.out.println("------------------");
    }
    
    // NON-STATIC METHOD
    void demo1() {
        hospitalId++;
        System.out.println("Hospital ID : " + hospitalId);
        System.out.println("Patient Count : " + patientCount);
        System.out.println("------------------");
    }
    
    public static void main(String[] args) {
        demo();
        Hospital h = new Hospital();
        h.demo1();
    }
}