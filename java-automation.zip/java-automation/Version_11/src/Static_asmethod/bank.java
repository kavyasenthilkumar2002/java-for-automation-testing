package Static_asmethod;

public class bank {
    
    // STATIC VARIABLE
    static int branch_code;
    
    // GLOBAL VARIABLE
    int account_count;
    String branch_name;
    
    // STATIC METHOD
    static void demo() {
        branch_code++;
        int account_count = 50;
        
        System.out.println("BANK");
        System.out.println("Branch Code : " + branch_code);
        System.out.println("Account Count : " + account_count);
        System.out.println("------------------");
    }
    
    // NON-STATIC METHOD
    void demo1() {
        branch_code++;
        System.out.println("Branch Code : " + branch_code);
        System.out.println("Account Count : " + account_count);
        System.out.println("------------------");
    }
    
    public static void main(String[] args) {
        demo();
        bank b = new bank();
        b.demo1();
    }
}
