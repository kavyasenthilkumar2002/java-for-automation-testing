package Static_asvariable;

public class ERP_System {

	 static int moduleId = 300;    // static variable
	    int activeUsers = 5;          // global variable
	    
	    void demo() {
	        moduleId++;
	        activeUsers++;
	        System.out.println("=== ERP SYSTEM ===");
	        System.out.println("Module ID: " + moduleId);
	        System.out.println("Active Users: " + activeUsers);
	        System.out.println("-------------");
	    }
	    
	    public static void main(String[] args) {
	    	ERP_System e1 = new ERP_System();
	        e1.demo();
	        
	        ERP_System e2 = new ERP_System();
	        e2.demo();
	        e2.demo();
	    }
	}
