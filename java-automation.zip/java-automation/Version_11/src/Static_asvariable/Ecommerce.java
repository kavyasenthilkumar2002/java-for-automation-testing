package Static_asvariable;

public class Ecommerce {
    
    static int orderId = 5000;   // static variable
    int cartItems = 2;           // global variable
    
    void demo() {
        orderId++;
        cartItems++;
        System.out.println("E-COMMERCE");
        System.out.println("Order ID: " + orderId);
        System.out.println("Cart Items: " + cartItems);
        System.out.println("-------------");
    }
    
    public static void main(String[] args) {
        Ecommerce e1 = new Ecommerce();
        e1.demo();
        
        Ecommerce e2 = new Ecommerce();
        e2.demo();
        e2.demo();
    }
}


