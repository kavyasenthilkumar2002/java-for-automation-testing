package Static_asvariable;

public class Hospital {
    
    static int hospitalId = 200;  // static variable
    int patientCount = 10;        // global variable
    
    void demo() {
        hospitalId++;
        patientCount++;
        System.out.println("HOSPITAL");
        System.out.println("Hospital ID: " + hospitalId);
        System.out.println("Patient Count: " + patientCount);
        System.out.println("-------------");
    }
    
    public static void main(String[] args) {
        Hospital h1 = new Hospital();
        h1.demo();
        
        Hospital h2 = new Hospital();
        h2.demo();
        h2.demo();
    }
}
