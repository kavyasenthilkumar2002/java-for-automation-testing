package Static_asvariable;

public class bank {
    
    static int branchCode = 1001;   // static variable
    int customerCount = 50;         // global variable
    
    void demo() {
        branchCode++;
        customerCount++;
        System.out.println("BANK");
        System.out.println("Branch Code: " + branchCode);
        System.out.println("Customer Count: " + customerCount);
        System.out.println("-------------");
    }
    
    public static void main(String[] args) {
    	bank b1 = new bank();
        b1.demo();
        b1.demo();
        
        bank b2 = new bank();
        b2.demo();
        
        bank b3 = new bank();
        b3.demo();
    }
}
