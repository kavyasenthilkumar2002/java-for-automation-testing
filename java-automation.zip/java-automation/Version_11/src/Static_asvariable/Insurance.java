package Static_asvariable;

public class Insurance {
	    
	    static int policyNo = 10000;   // static variable
	    int claimCount = 2;            // global variable
	    
	    void demo() {
	        policyNo++;
	        claimCount++;
	        System.out.println("=== INSURANCE ===");
	        System.out.println("Policy Number: " + policyNo);
	        System.out.println("Claim Count: " + claimCount);
	        System.out.println("-------------");
	    }
	    
	    public static void main(String[] args) {
	    	Insurance i1 = new Insurance();
	        i1.demo();
	        
	        Insurance i2 = new Insurance();
	        i2.demo();
	        i2.demo();
	    }
	}
