package Withthis_Method;


public class Hospital {

			
					//Global variable
						int number;
						String Hospital;
						String Location;
						
						// methods
					 void diplayname (int number,String Hospital,String Location) {
						 // this keyword is used 
						 this.number= number;
						 this.Hospital= Hospital;
						 this.Location=Location;
						 
					 }
					
					void display() {
						this.diplayname(10,"Kuppusamy Hospital","Gandhipuram");
						System.out.println("Kuppusamy Hospital");
						System.out.println("Saving is: " + number);
						System.out.println("Bankname is: " + Hospital);
						System.out.println("Location is: " + Location);
					}
				 

					public static void main(String[] args) {
						// TODO Auto-generated method stub

						Hospital a=new Hospital();
						a.display();
					}

				}



