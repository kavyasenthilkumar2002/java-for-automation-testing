package Withthis_Method;

public class ecommerce {

							//Global variable
							int number;
							String Product;
							String Location;
							
							// methods
							//parameterized 
						 void diplayname (int number,String Product,String Location) {
							 // this keyword is used 
							 this.number= number;
							 this.Product= Product;
							 this.Location=Location;
							 
						 }
						
						void display() {
							this.diplayname(11, "Chudidar","Saiababa colony");
							System.out.println("MEESHO");
							System.out.println("Saving is: " + number);
							System.out.println("Bankname is: " + Product);
							System.out.println("Location is: " + Location);
						}
					 

						public static void main(String[] args) {
							// TODO Auto-generated method stub

							ecommerce a=new ecommerce();
							a.display();
						}

					}



