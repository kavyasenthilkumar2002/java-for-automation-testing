package Withthis_Method;

public class ERP_System {

			
				//Global variable
					int number;
					String SystemName;
					String About;
					
					// methods
				 void diplayname (int System,String SystemName,String About) {
					 // this keyword is used 
					 this.number= System;
					 this.SystemName= SystemName;
					 this.About=About;
					 
				 }
				
				void display() {
					this.diplayname(10,"PC","Gandhipuram");
					System.out.println("ERP_Systems");
					System.out.println("Number is: " + number);
					System.out.println("SystemName is: " + SystemName);
					System.out.println("About is:" + About);
				}
			 

				public static void main(String[] args) {
					// TODO Auto-generated method stub

					ERP_System a=new ERP_System();
					a.display();
				}

			}








