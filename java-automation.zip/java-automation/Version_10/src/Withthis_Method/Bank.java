package Withthis_Method;

public class Bank {

			
				//Global variable
					int Savings;
					String Bankname;
					String Location;
					
					// methods
				 void diplayname (int Savings,String Bankname,String Location) {
					 // this keyword is used 
					 this.Savings= Savings;
					 this.Bankname= Bankname;
					 this.Location=Location;
					 
				 }
				
				void display() {
					this.diplayname(10,"INDIANBANK","Gandhipuram");
					System.out.println("INDIANBANK");
					System.out.println("Saving is: " + Savings);
					System.out.println("Bankname is: " + Bankname);
					System.out.println("Location is: " + Location);
				}
			 

				public static void main(String[] args) {
					// TODO Auto-generated method stub

					Bank a=new Bank();
					a.display();
				}

			}






