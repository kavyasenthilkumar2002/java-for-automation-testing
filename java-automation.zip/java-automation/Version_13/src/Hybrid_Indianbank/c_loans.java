package Hybrid_Indianbank;

	public class c_loans extends a_indianbank {

	    void loans_module(String loan_type, int active_loans) {
	        System.out.println("LOANS MODULE");
	        System.out.println("Loan Type    : " + loan_type);
	        System.out.println("Active Loans : " + active_loans);
	        System.out.println("");
	    }

	    public static void main(String[] args) {
	        c_loans c = new c_loans();
	        c.bank_details("Indian Bank", "Chennai, India", 1907);
	        c.loans_module("Home Loan", 50000);
	    }
	}
