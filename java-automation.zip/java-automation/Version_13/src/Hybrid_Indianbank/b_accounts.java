package Hybrid_Indianbank;

	public class b_accounts extends a_indianbank {

	    void accounts_module(String account_type, int total_accounts) {
	        System.out.println("ACCOUNTS MODULE");
	        System.out.println("Account Type   : " + account_type);
	        System.out.println("Total Accounts : " + total_accounts);
	        System.out.println("");
	    }

	    public static void main(String[] args) {
	        b_accounts b = new b_accounts();
	        b.bank_details("Indian Bank", "Chennai, India", 1907);
	        b.accounts_module("Savings", 250000);
	    }
	}


