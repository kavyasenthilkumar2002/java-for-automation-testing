package Hybrid_Indianbank;

public class g_notifications extends f_customers {  

    void notifications_module(String type, String status) {
        System.out.println("NOTIFICATIONS MODULE");
        System.out.println("Notification Type : " + type);
        System.out.println("Status            : " + status);
        System.out.println("");
    }

    public static void main(String[] args) {
        g_notifications g = new g_notifications();
        g.bank_details("Indian Bank", "Chennai, India", 1907);
        g.accounts_module("Savings", 250000);
        g.cards_module("Credit Card", 80000);
        g.customers_module(1200000, "Tamil Nadu");
        g.notifications_module("SMS Alert", "Active");
    }
}

 

