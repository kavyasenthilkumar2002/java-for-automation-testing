package Hybrid_Indianbank;

public class a_indianbank {

	    static {
	        System.out.println("INDIAN BANK SYSTEM");
	        System.out.println("");
	    }

	    a_indianbank() {
	        System.out.println("WELCOME TO INDIAN BANK");
	        System.out.println("");
	    }

	    String bank_name;
	    String headquarters;
	    int established_year;

	    void bank_details(String bank_name, String headquarters, int established_year) {
	        this.bank_name = bank_name;
	        this.headquarters = headquarters;
	        this.established_year = established_year;

	        System.out.println("Bank Name        : " + bank_name);
	        System.out.println("Headquarters     : " + headquarters);
	        System.out.println("Established Year : " + established_year);
	        System.out.println("");
	    }

	    public static void main(String[] args) {
	        a_indianbank a = new a_indianbank();
	        a.bank_details("Indian Bank", "Chennai, India", 1907);
	    }
	}


