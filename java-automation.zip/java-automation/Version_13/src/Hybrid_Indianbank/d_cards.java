package Hybrid_Indianbank;
	public class d_cards extends b_accounts {

	    void cards_module(String card_type, int issued_cards) {
	        System.out.println("CARDS MODULE");
	        System.out.println("Card Type    : " + card_type);
	        System.out.println("Issued Cards : " + issued_cards);
	        System.out.println("");
	    }

	    public static void main(String[] args) {
	        d_cards d = new d_cards();
	        d.bank_details("Indian Bank", "Chennai, India", 1907);
	        d.accounts_module("Savings", 250000);
	        d.cards_module("Credit Card", 80000);
	    }
	}


