package Hybrid_Indianbank;
	public class e_transactions extends c_loans {

	    void transactions_module(String type, int volume) {
	        System.out.println("TRANSACTIONS MODULE");
	        System.out.println("Transaction Type : " + type);
	        System.out.println("Volume           : " + volume);
	        System.out.println("");
	    }

	    public static void main(String[] args) {
	        e_transactions e = new e_transactions();
	        e.bank_details("Indian Bank", "Chennai, India", 1907);
	        e.loans_module("Home Loan", 50000);
	        e.transactions_module("UPI", 1500000);
	    }
	}

