package Hybrid_Indianbank;
public class f_customers extends d_cards {

    void customers_module(int total_customers, String region) {
        System.out.println("CUSTOMERS MODULE");
        System.out.println("Total Customers : " + total_customers);
        System.out.println("Region          : " + region);
        System.out.println("");
    }

    public static void main(String[] args) {
        f_customers f = new f_customers();
        f.bank_details("Indian Bank", "Chennai, India", 1907);
        f.accounts_module("Savings", 250000);
        f.cards_module("Credit Card", 80000);
        f.customers_module(1200000, "Tamil Nadu");
    }
}

