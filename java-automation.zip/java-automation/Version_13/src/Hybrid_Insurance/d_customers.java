package Hybrid_Insurance;

	public class d_customers extends b_policy {

	    void customers_module(int customers, String region) {
	        System.out.println("CUSTOMERS MODULE");
	        System.out.println("Customers : " + customers);
	        System.out.println("Region    : " + region);
	        System.out.println("");
	    }

	    public static void main(String[] args) {
	        d_customers d = new d_customers();
	        d.insurance_details("Acko Insurance", "Mumbai, India", 2016);
	        d.policy_module("Health Insurance", 35000);
	        d.customers_module(120000, "Maharashtra");
	    }
	}
