package Hybrid_Insurance;

	public class c_claims extends a_insurance {

	    void claims_module(int claims_received, int claims_settled) {
	        System.out.println("CLAIMS MODULE");
	        System.out.println("Claims Received : " + claims_received);
	        System.out.println("Claims Settled  : " + claims_settled);
	        System.out.println("");
	    }

	    public static void main(String[] args) {
	        c_claims c = new c_claims();
	        c.insurance_details("Acko Insurance", "Mumbai, India", 2016);
	        c.claims_module(1200, 950);
	    }
	}


