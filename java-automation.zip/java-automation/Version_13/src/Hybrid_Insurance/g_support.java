package Hybrid_Insurance;

public class g_support extends e_payments {  

    void support_module(String channel, String status) {
        System.out.println("SUPPORT MODULE");
        System.out.println("Channel : " + channel);
        System.out.println("Status  : " + status);
        System.out.println("");
    }

    public static void main(String[] args) {
        g_support g = new g_support();
        g.insurance_details("Acko Insurance", "Mumbai, India", 2016);
        g.claims_module(1200, 950);
        g.payments_module("Online", 2500000);
        g.support_module("Chatbot", "Active");
    }
}
