package Hybrid_Insurance;

public class a_insurance {


	    static {
	        System.out.println("INSURANCE SYSTEM");
	        System.out.println("");
	    }

	    a_insurance() {
	        System.out.println("WELCOME TO INSURANCE COMPANY");
	        System.out.println("");
	    }

	    String company_name;
	    String headquarters;
	    int founded_year;

	    void insurance_details(String company_name, String headquarters, int founded_year) {
	        this.company_name = company_name;
	        this.headquarters = headquarters;
	        this.founded_year = founded_year;

	        System.out.println("Company Name   : " + company_name);
	        System.out.println("Headquarters   : " + headquarters);
	        System.out.println("Founded Year   : " + founded_year);
	        System.out.println("");
	    }

	    public static void main(String[] args) {
	        a_insurance a = new a_insurance();
	        a.insurance_details("Acko Insurance", "Mumbai, India", 2016);
	    }
	}

