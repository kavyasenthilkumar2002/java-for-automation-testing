package Hybrid_Insurance;

	public class e_payments extends c_claims {

	    void payments_module(String mode, int total) {
	        System.out.println("PAYMENTS MODULE");
	        System.out.println("Payment Mode : " + mode);
	        System.out.println("Total Amount : Rs." + total);
	        System.out.println("");
	    }

	    public static void main(String[] args) {
	        e_payments e = new e_payments();
	        e.insurance_details("Acko Insurance", "Mumbai, India", 2016);
	        e.claims_module(1200, 950);
	        e.payments_module("Online", 2500000);
	    }
	}