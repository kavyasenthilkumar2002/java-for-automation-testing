package Hybrid_Insurance;


	public class b_policy extends a_insurance {

	    void policy_module(String policy_type, int active_policies) {
	        System.out.println("POLICY MODULE");
	        System.out.println("Policy Type     : " + policy_type);
	        System.out.println("Active Policies : " + active_policies);
	        System.out.println("");
	    }

	    public static void main(String[] args) {
	        b_policy b = new b_policy();
	        b.insurance_details("Acko Insurance", "Mumbai, India", 2016);
	        b.policy_module("Health Insurance", 35000);
	    }
	}


