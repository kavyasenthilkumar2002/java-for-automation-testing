package Hybrid_Insurance;

	public class f_agents extends d_customers {

	    void agents_module(int agents, String region) {
	        System.out.println("AGENTS MODULE");
	        System.out.println("Agents : " + agents);
	        System.out.println("Region : " + region);
	        System.out.println("");
	    }

	    public static void main(String[] args) {
	        f_agents f = new f_agents();
	        f.insurance_details("Acko Insurance", "Mumbai, India", 2016);
	        f.policy_module("Health Insurance", 35000);
	        f.customers_module(120000, "Maharashtra");
	        f.agents_module(500, "West India");
	    }
	}


