package Hybrid_Meesho;

	public class d_orders extends b_products {

	    String order_id;
	    String customer_name;
	    String product_name;

	    void order_1(String order_id, String customer_name, String product_name) {
	        this.order_id = order_id;
	        this.customer_name = customer_name;
	        this.product_name = product_name;

	        System.out.println("ORDER DETAILS");
	        System.out.println("Order ID      : " + order_id);
	        System.out.println("Customer Name : " + customer_name);
	        System.out.println("Product       : " + product_name);
	        System.out.println("");
	    }

	    void display_d() {
	        this.order_1("ORD1001", "Priya", "Saree");
	    }

	    public static void main(String[] args) {
	        d_orders d = new d_orders();
	        d.meesho_details("Meesho Online Shopping", "Bangalore, India", 2015);
	        d.display_b();
	        d.display_d();
	    }
	}

