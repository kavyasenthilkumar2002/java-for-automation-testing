package Hybrid_Meesho;

	public class b_products extends a_meesho {

	    static int product_count;

	    String product_name;
	    String category;
	    int price;

	    void product_1(String product_name, String category, int price) {
	        product_count++;
	        this.product_name = product_name;
	        this.category = category;
	        this.price = price;

	        System.out.println("PRODUCT DETAILS");
	        System.out.println("Product No   : " + product_count);
	        System.out.println("Product Name : " + product_name);
	        System.out.println("Category     : " + category);
	        System.out.println("Price        : Rs." + price);
	        System.out.println("");
	    }

	    void product_2(String product_name, String category, int price) {
	        product_count++;
	        this.product_name = product_name;
	        this.category = category;
	        this.price = price;

	        System.out.println("Product No   : " + product_count);
	        System.out.println("Product Name : " + product_name);
	        System.out.println("Category     : " + category);
	        System.out.println("Price        : Rs." + price);
	        System.out.println("");
	    }

	    void display_b() {
	        this.product_1("Saree", "Fashion", 799);
	        this.product_2("Mixer Grinder", "Home Appliance", 2499);
	    }

	    static void product_list() {
	        System.out.println("Total Products : " + product_count);
	    }

	    public static void main(String[] args) {
	        b_products b = new b_products();
	        b.meesho_details("Meesho Online Shopping", "Bangalore, India", 2015);
	        b.display_b();
	        product_list();
	    }
	}

