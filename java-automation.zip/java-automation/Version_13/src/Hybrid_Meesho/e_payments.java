package Hybrid_Meesho;

	public class e_payments extends c_customers {

	    String payment_id;
	    String payment_mode;
	    int amount;

	    void payment_1(String payment_id, String payment_mode, int amount) {
	        this.payment_id = payment_id;
	        this.payment_mode = payment_mode;
	        this.amount = amount;

	        System.out.println("PAYMENT DETAILS");
	        System.out.println("Payment ID    : " + payment_id);
	        System.out.println("Mode          : " + payment_mode);
	        System.out.println("Amount        : Rs." + amount);
	        System.out.println("");
	    }

	    void display_e() {
	        this.payment_1("PAY5001", "UPI", 799);
	    }

	    public static void main(String[] args) {
	        e_payments e = new e_payments();
	        e.meesho_details("Meesho Online Shopping", "Bangalore, India", 2015);
	        e.display_c();
	        e.display_e();
	    }
	}


