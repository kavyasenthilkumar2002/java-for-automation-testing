package Hybrid_Meesho;


	public class g_reviews extends c_customers {

	    String customer_name;
	    String product_name;
	    String review;

	    void review_1(String customer_name, String product_name, String review) {
	        this.customer_name = customer_name;
	        this.product_name = product_name;
	        this.review = review;

	        System.out.println("REVIEW DETAILS");
	        System.out.println("Customer Name : " + customer_name);
	        System.out.println("Product       : " + product_name);
	        System.out.println("Review        : " + review);
	        System.out.println("");
	    }

	    void display_g() {
	        this.review_1("Kavya", "Mixer Grinder", "Very Good Quality!");
	    }

	    public static void main(String[] args) {
	        g_reviews g = new g_reviews();
	        g.meesho_details("Meesho Online Shopping", "Bangalore, India", 2015);
	        g.display_c();
	        g.display_g();
	    }
	}


