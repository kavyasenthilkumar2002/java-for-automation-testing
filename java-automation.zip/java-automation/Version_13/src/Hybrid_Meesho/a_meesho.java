package Hybrid_Meesho;

public class a_meesho {

	    static {
	        System.out.println("MEESHO E-COMMERCE");
	        System.out.println("");
	    }

	    a_meesho() {
	        System.out.println("WELCOME TO MEESHO");
	        System.out.println("");
	    }

	    String platform_name;
	    String headquarters;
	    int established_year;

	    void meesho_details(String platform_name, String headquarters, int established_year) {
	        this.platform_name = platform_name;
	        this.headquarters = headquarters;
	        this.established_year = established_year;

	        System.out.println("Platform Name   : " + platform_name);
	        System.out.println("Headquarters    : " + headquarters);
	        System.out.println("Established Year: " + established_year);
	        System.out.println("");
	    }

	    public static void main(String[] args) {
	        a_meesho a = new a_meesho();
	        a.meesho_details("Meesho Online Shopping", "Bangalore, India", 2015);
	    }
	}

