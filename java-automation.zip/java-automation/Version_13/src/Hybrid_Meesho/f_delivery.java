package Hybrid_Meesho;

	public class f_delivery extends d_orders {

	    String delivery_id;
	    String address;
	    String status;

	    void delivery_1(String delivery_id, String address, String status) {
	        this.delivery_id = delivery_id;
	        this.address = address;
	        this.status = status;

	        System.out.println("DELIVERY DETAILS");
	        System.out.println("Delivery ID   : " + delivery_id);
	        System.out.println("Address       : " + address);
	        System.out.println("Status        : " + status);
	        System.out.println("");
	    }

	    void display_f() {
	        this.delivery_1("DEL7001", "Coimbatore", "Shipped");
	    }

	    public static void main(String[] args) {
	        f_delivery f = new f_delivery();
	        f.meesho_details("Meesho Online Shopping", "Bangalore, India", 2015);
	        f.display_b();
	        f.display_d();
	        f.display_f();
	    }
	}


