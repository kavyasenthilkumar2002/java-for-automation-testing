package Hybrid_Meesho;

	public class c_customers extends a_meesho {

	    static int total_customers;

	    String customer_name;
	    String customer_number;

	    void customer_1(String customer_name, String customer_number) {
	        total_customers++;
	        this.customer_name = customer_name;
	        this.customer_number = customer_number;

	        System.out.println("CUSTOMER DETAILS");
	        System.out.println("Customer ID   : " + total_customers);
	        System.out.println("Name          : " + customer_name);
	        System.out.println("Number        : " + customer_number);
	        System.out.println("");
	    }

	    void customer_2(String customer_name, String customer_number) {
	        total_customers++;
	        this.customer_name = customer_name;
	        this.customer_number = customer_number;

	        System.out.println("Customer ID   : " + total_customers);
	        System.out.println("Name          : " + customer_name);
	        System.out.println("Number        : " + customer_number);
	        System.out.println("");
	    }

	    void display_c() {
	        this.customer_1("Priya", "9876543210");
	        this.customer_2("Kavya", "8765432109");
	    }

	    public static void main(String[] args) {
	        c_customers c = new c_customers();
	        c.meesho_details("Meesho Online Shopping", "Bangalore, India", 2015);
	        c.display_c();
	    }
	}


