package Hybrid_ERP;
public class b_hr extends a_erp {

	    void hr_module(String manager, int employees) {
	        System.out.println("HR MODULE");
	        System.out.println("HR Manager : " + manager);
	        System.out.println("Employees  : " + employees);
	        System.out.println("");
	    }

	    public static void main(String[] args) {
	        b_hr b = new b_hr();
	        b.erp_details("NextGen ERP Solutions", "Chennai, India", 2010);
	        b.hr_module("Priya", 150);
	    }
	}


