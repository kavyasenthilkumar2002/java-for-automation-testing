package Hybrid_ERP;

public class a_erp {

	    static {
	        System.out.println("ERP SYSTEM");
	        System.out.println("");
	    }

	    a_erp() {
	        System.out.println("WELCOME TO ERP");
	        System.out.println("");
	    }

	    String company_name;
	    String headquarters;
	    int established_year;

	    void erp_details(String company_name, String headquarters, int established_year) {
	        this.company_name = company_name;
	        this.headquarters = headquarters;
	        this.established_year = established_year;

	        System.out.println("Company Name     : " + company_name);
	        System.out.println("Headquarters     : " + headquarters);
	        System.out.println("Established Year : " + established_year);
	        System.out.println("");
	    }

	    public static void main(String[] args) {
	        a_erp a = new a_erp();
	        a.erp_details("NextGen ERP Solutions", "Chennai, India", 2010);
	    }
	}

