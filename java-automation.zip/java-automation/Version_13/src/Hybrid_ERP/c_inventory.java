package Hybrid_ERP;

	public class c_inventory extends a_erp {

	    void inventory_module(String product, int stock) {
	        System.out.println("INVENTORY MODULE");
	        System.out.println("Product : " + product);
	        System.out.println("Stock   : " + stock);
	        System.out.println("");
	    }

	    public static void main(String[] args) {
	        c_inventory c = new c_inventory();
	        c.erp_details("NextGen ERP Solutions", "Chennai, India", 2010);
	        c.inventory_module("Laptops", 250);
	    }
	}

