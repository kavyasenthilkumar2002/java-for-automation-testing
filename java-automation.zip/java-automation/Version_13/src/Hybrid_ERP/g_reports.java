package Hybrid_ERP;

	public class g_reports extends e_purchase {

	    void reports_module(String report_type, String status) {
	        System.out.println("REPORTS MODULE");
	        System.out.println("Report Type : " + report_type);
	        System.out.println("Status      : " + status);
	        System.out.println("");
	    }

	    public static void main(String[] args) {
	        g_reports g = new g_reports();
	        g.erp_details("NextGen ERP Solutions", "Chennai, India", 2010);
	        g.inventory_module("Laptops", 250);
	        g.purchase_module("Dell India", 1200000);
	        g.reports_module("Annual Report", "Generated");
	    }
	}


