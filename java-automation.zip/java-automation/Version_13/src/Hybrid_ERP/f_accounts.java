package Hybrid_ERP;

	public class f_accounts extends d_sales {

	    void accounts_module(String account_head, int balance) {
	        System.out.println("ACCOUNTS MODULE");
	        System.out.println("Head    : " + account_head);
	        System.out.println("Balance : Rs." + balance);
	        System.out.println("");
	    }

	    public static void main(String[] args) {
	        f_accounts f = new f_accounts();
	        f.erp_details("NextGen ERP Solutions", "Chennai, India", 2010);
	        f.hr_module("Priya", 150);
	        f.sales_module("South India", 5000000);
	        f.accounts_module("Corporate Account", 8000000);
	    }
	}

