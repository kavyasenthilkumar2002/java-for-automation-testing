package Hybrid_ERP;

	public class e_purchase extends c_inventory {

	    void purchase_module(String supplier, int amount) {
	        System.out.println("PURCHASE MODULE");
	        System.out.println("Supplier : " + supplier);
	        System.out.println("Amount   : Rs." + amount);
	        System.out.println("");
	    }

	    public static void main(String[] args) {
	        e_purchase e = new e_purchase();
	        e.erp_details("NextGen ERP Solutions", "Chennai, India", 2010);
	        e.inventory_module("Laptops", 250);
	        e.purchase_module("Dell India", 1200000);
	    }
	}


