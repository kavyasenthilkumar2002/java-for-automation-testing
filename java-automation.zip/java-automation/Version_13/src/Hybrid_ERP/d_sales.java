package Hybrid_ERP;

	public class d_sales extends b_hr {

	    void sales_module(String region, int revenue) {
	        System.out.println("SALES MODULE");
	        System.out.println("Region  : " + region);
	        System.out.println("Revenue : Rs." + revenue);
	        System.out.println("");
	    }

	    public static void main(String[] args) {
	        d_sales d = new d_sales();
	        d.erp_details("NextGen ERP Solutions", "Chennai, India", 2010);
	        d.hr_module("Priya", 150);
	        d.sales_module("South India", 5000000);
	    }
	}

