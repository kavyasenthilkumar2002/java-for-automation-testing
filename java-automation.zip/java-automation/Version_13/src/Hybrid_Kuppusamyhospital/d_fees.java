package Hybrid_Kuppusamyhospital;

public class d_fees extends a_kuppusamy {
		
		
		private static final String b = null;
		String doctor_name;
		String doctor_fees;
		
		void doctor_1(String doctor_name,String doctor_fees)
		{
			this.doctor_name = doctor_name;
			this.doctor_fees = doctor_fees;
			
			System.out.println("");
			System.out.println("CARDIO SPECIALIST FEES");
			System.out.println("Doctor Name : " + doctor_name);
			System.out.println("Doctor Fees : " +  doctor_fees);
			System.out.println("");
		}
		
		void doctor_2(String doctor_name,String doctor_fees)
		{
			this.doctor_name = doctor_name;
			this.doctor_fees = doctor_fees;
			
			System.out.println("ENT SPECIALIST FEES");
			System.out.println("Doctor Name : " + doctor_name);
			System.out.println("Doctor Fees : " +  doctor_fees);
			System.out.println("");
		}
		
		void doctor_3(String doctor_name,String doctor_fees)
		{
			this.doctor_name = doctor_name;
			this.doctor_fees = doctor_fees;
			
			System.out.println("GYNO SPECIALIST FEES");
			System.out.println("Doctor Name : " + doctor_name);
			System.out.println("Doctor Fees : " +  doctor_fees);
			System.out.println("");
		}
		
		void doctor_4(String doctor_name,String doctor_fees)
		{
			this.doctor_name = doctor_name;
			this.doctor_fees = doctor_fees;
			
			System.out.println("CHILD SPECIALIST FEES");
			System.out.println("Doctor Name : " + doctor_name);
			System.out.println("Doctor Fees : " +  doctor_fees);
			System.out.println("");
		}
		
		
		void display()
		{
			this.doctor_1("Ananya","RS.300");
			this.doctor_2("kavya","RS.500");
			this.doctor_3("sanjee","RS.400");
			this.doctor_4("jaya","RS.350");
		}
		
		
		public static void main(String[] args) {
	        d_fees d = new d_fees();
	        d.hospital_details("Gandhipuram, Coimbatore", 641027, "0422-7890654");
	        d.display();
	        
		}
}

