package Hybrid_Kuppusamyhospital;

public class b_doctor extends a_kuppusamy {
	
		
	static int doctor_number;
		
		
		String doctor_name;
		String doctor_specialization;
		int doctor_experience;
		int doctor_fees;
		
		//METHODS

		
		void doctor_1(String doctor_name,String doctor_specialization,int doctor_experience,int doctor_fees)
		{
			doctor_number++;
			this.doctor_name = doctor_name;
			this.doctor_specialization  = doctor_specialization;
			this.doctor_experience = doctor_experience;
			this.doctor_fees = doctor_fees;
			
			System.out.println("");
			System.out.println("DOCTOR DETAILS");
			System.out.println("");
			System.out.println("DOCTOR NUMBER         : " + doctor_number);
			System.out.println("DOCTOR NAME           : " + doctor_name);
			System.out.println("DOCTOR SPECIALIZATION : " + doctor_specialization);
			System.out.println("DOCTOR EXPERIENCE     : " + doctor_experience);
			System.out.println("DOCTOR FEES           : " + doctor_fees);
			System.out.println("");
			

		}
		
		void doctor_2(String doctor_name,String doctor_specialization,int doctor_experience,int doctor_fees)
		{
			doctor_number++;
			this.doctor_name = doctor_name;
			this.doctor_specialization  = doctor_specialization;
			this.doctor_experience = doctor_experience;
			this.doctor_fees = doctor_fees;
			
			System.out.println("DOCTOR NUMBER         : " + doctor_number);
			System.out.println("DOCTOR NAME           : " + doctor_name);
			System.out.println("DOCTOR SPECIALIZATION : " + doctor_specialization);
			System.out.println("DOCTOR EXPERIENCE     : " + doctor_experience);
			System.out.println("DOCTOR FEES           : " + doctor_fees);
			System.out.println("");

		}
		
		void doctor_3(String doctor_name,String doctor_specialization,int doctor_experience,int doctor_fees)
		{
			doctor_number++;
			this.doctor_name = doctor_name;
			this.doctor_specialization  = doctor_specialization;
			this.doctor_experience = doctor_experience;
			this.doctor_fees = doctor_fees;
			
			System.out.println("DOCTOR NUMBER         : " + doctor_number);
			System.out.println("DOCTOR NAME           : " + doctor_name);
			System.out.println("DOCTOR SPECIALIZATION : " + doctor_specialization);
			System.out.println("DOCTOR EXPERIENCE     : " + doctor_experience);
			System.out.println("DOCTOR FEES           : " + doctor_fees);
			System.out.println("");

		}
		
		void doctor_4(String doctor_name,String doctor_specialization,int doctor_experience,int doctor_fees)
		{
			doctor_number++;
			this.doctor_name = doctor_name;
			this.doctor_specialization  = doctor_specialization;
			this.doctor_experience = doctor_experience;
			this.doctor_fees = doctor_fees;
			
			System.out.println("DOCTOR NUMBER         : " + doctor_number);
			System.out.println("DOCTOR NAME           : " + doctor_name);
			System.out.println("DOCTOR SPECIALIZATION : " + doctor_specialization);
			System.out.println("DOCTOR EXPERIENCE     : " + doctor_experience);
			System.out.println("DOCTOR FEES           : " + doctor_fees);
			System.out.println("");

		
		}
		
		void display_b()
		{
			this.doctor_1("Ananya","cardio",6,1200);
			this.doctor_2("Sanjeetha","ENT",4,1000);
			this.doctor_3("Kavya","Gyno",10,2000);
			this.doctor_4("Jayalakshmi","Dentist",20,2200);
		}
		
		static void doctor_list()
		{
			System.out.println("Doctors Count : " + doctor_number);
		}

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			b_doctor b = new b_doctor();
			b.hospital_details("Gandhipuram, Coimbatore",641027,"0422-7890654");		
			b.display_b();
			doctor_list();

		}

	}



