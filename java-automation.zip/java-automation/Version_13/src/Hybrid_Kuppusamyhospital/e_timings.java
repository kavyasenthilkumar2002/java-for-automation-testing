package Hybrid_Kuppusamyhospital;

	public class e_timings extends b_doctor{
		
		String doctor_name;
		String doctor_timings;
		
		void doctor_1(String doctor_name,String doctor_timings)
		{
			this.doctor_name = doctor_name;
			this.doctor_timings = doctor_timings;
			
			System.out.println("CARDIO SPECIALIST TIMING");
			System.out.println("Doctor Name : " + doctor_name);
			System.out.println("Doctor Timing : " +  doctor_timings);
			System.out.println("");
		}
		
		void doctor_2(String doctor_name,String doctor_timings)
		{
			this.doctor_name = doctor_name;
			this.doctor_timings = doctor_timings;
			
			System.out.println("ENT SPECIALIST TIMING");
			System.out.println("Doctor Name : " + doctor_name);
			System.out.println("Doctor Timing : " +  doctor_timings);
			System.out.println("");
		}
		
		void doctor_3(String doctor_name,String doctor_timings)
		{
			this.doctor_name = doctor_name;
			this.doctor_timings = doctor_timings;
			
			System.out.println("GYNO SPECIALIST TIMING");
			System.out.println("Doctor Name : " + doctor_name);
			System.out.println("Doctor Timing : " +  doctor_timings);
			System.out.println("");
		}
		
		void doctor_4(String doctor_name,String doctor_timings)
		{
			this.doctor_name = doctor_name;
			this.doctor_timings = doctor_timings;
			
			System.out.println("CHILD SPECIALIST TIMING");
			System.out.println("Doctor Name : " + doctor_name);
			System.out.println("Doctor Timing : " +  doctor_timings);
			System.out.println("");
		}
		
		
		void display()
		{
			System.out.println("TIMINGS");
			System.out.println("");
			this.doctor_1("Ananya","10AM - 1PM");
			this.doctor_2("kavya","1PM - 3PM");
			this.doctor_3("sanjee","10AM - 4PM");
			this.doctor_4("jaya","4PM - 7PM");
		}
		
		

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			e_timings e = new e_timings();
			e.hospital_details("Gandhipuram, Coimbatore",641027,"0422-7890654");
			e.display_b();
			e.display();

			
			

		}

	}


