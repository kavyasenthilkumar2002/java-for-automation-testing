package Hybrid_Kuppusamyhospital;

public class c_patient extends a_kuppusamy{

		
		static int total_patient;
		
		String patient_name;
		int patient_age;
		String patient_number;
		
		
		void patient_1(String patient_name,int patient_age,String patient_number)
		{
			total_patient++;
			this.patient_name = patient_name;
			this.patient_age = patient_age;
			this.patient_number = patient_number;
			
			System.out.println("PATIENT DETAILS");
			System.out.println("");
			System.out.println("Patient Number  :" + total_patient);
			System.out.println("Name            : " + patient_name);
			System.out.println("Age             :" + patient_age);
			System.out.println("number          : " + patient_number);
			System.out.println("");
			
		}
		
		void patient_2(String patient_name,int patient_age,String patient_number)
		{
			total_patient++;
			this.patient_name = patient_name;
			this.patient_age = patient_age;
			this.patient_number = patient_number;
			
		

			System.out.println("Patient Number  :" + total_patient);
			System.out.println("Name            : " + patient_name);
			System.out.println("Age             :" + patient_age);
			System.out.println("number          : " + patient_number);
			System.out.println("");
			
		}
		
		
		
		void patient_3(String patient_name,int patient_age,String patient_number)
		{
			total_patient++;
			this.patient_name = patient_name;
			this.patient_age = patient_age;
			this.patient_number = patient_number;
			
			System.out.println("Patient Number  :" + total_patient);
			System.out.println("Name            : " + patient_name);
			System.out.println("Age             :" + patient_age);
			System.out.println("number          : " + patient_number);
			System.out.println("");
			
		}
		
		
		void patient_4(String patient_name,int patient_age,String patient_number)
		{
			total_patient++;
			this.patient_name = patient_name;
			this.patient_age = patient_age;
			this.patient_number = patient_number;
			
			System.out.println("Patient Number  :" + total_patient);
			System.out.println("Name            : " + patient_name);
			System.out.println("Age             :" + patient_age);
			System.out.println("number          : " + patient_number);
			System.out.println("");
			
		}
		
		void display_c()
		{
			this.patient_1("Deepak",20,"9876543210");
			this.patient_2("Sakthy",20,"7853987432");
			this.patient_3("Berry",20,"7871400987");
			this.patient_4("Janu",20,"6379318081");
		}
		


		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			c_patient c = new c_patient();
			c.hospital_details("Gandhipuram, Coimbatore",641027,"0422-7890654");			c.display_c();

		}

	}



