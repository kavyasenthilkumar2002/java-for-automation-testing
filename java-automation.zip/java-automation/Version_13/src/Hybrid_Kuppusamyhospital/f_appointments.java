package Hybrid_Kuppusamyhospital;

public class f_appointments  extends c_patient {
		
		
		String patient;
		String doctor_name;
		String timing;
		
		void appointment_1(String patient,String doctor_name,String timing)
		{
			this.patient = patient;
			this.doctor_name = doctor_name;
			this.timing = timing;
			
			System.out.println("APPOINTMENT DETAILS");
			System.out.println("");
			System.out.println("Patient - 1     : " + patient);
			System.out.println("Doctor Name     :" + doctor_name);
			System.out.println("Timing          : " + timing);
			System.out.println("");
			
		}
		
		void appointment_2(String patient,String doctor_name,String timing)
		{
			this.patient = patient;
			this.doctor_name = doctor_name;
			this.timing = timing;
			
			
			System.out.println("Patient - 1     : " + patient);
			System.out.println("Doctor Name     :" + doctor_name);
			System.out.println("Timing          : " + timing);
			System.out.println("");
			
		}
		
		
		
		void appointment_3(String patient,String doctor_name,String timing)
		{
			this.patient = patient;
			this.doctor_name = doctor_name;
			this.timing = timing;
			
			
			System.out.println("Patient - 1     : " + patient);
			System.out.println("Doctor Name     :" + doctor_name);
			System.out.println("Timing          : " + timing);
			System.out.println("");
			
		}
		
		
		void appointment_4(String patient,String doctor_name,String timing)
		{
			this.patient = patient;
			this.doctor_name = doctor_name;
			this.timing = timing;
			
			
			System.out.println("Patient - 1     : " + patient);
			System.out.println("Doctor Name     :" + doctor_name);
			System.out.println("Timing          : " + timing);
			System.out.println("");
			
		}
		void display_f()
		{
			this.appointment_1("Deepak","Ananya","10am");
			this.appointment_2("Priya","Kavya","3pm");
			this.appointment_3("Dikshu","Sanjee","12pm");
			this.appointment_4("Anju","Jaya","6pm");
		}
		


		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			f_appointments f = new f_appointments();
	        f.hospital_details("Gandhipuram, Coimbatore", 641027, "0422-7890654");
			f.display_c();
			f.display_f();
			

		}
}

