package Hybrid_Kuppusamyhospital;

public class a_kuppusamy {
	
		
		static
		{
			System.out.println("KUPPUSAMY");
			System.out.println("");
			}
		
		a_kuppusamy()
		{
			System.out.println("ADHI HOSPITAL");
			System.out.println("");
		}

		String hospital_address;
		int hospital_pincode;
		String hospital_num;
		
		void hospital_details(String hospital_address,int hospital_pincode,String hospital_num)
		{
			this.hospital_address = hospital_address;
			this.hospital_pincode = hospital_pincode;
			this.hospital_num = hospital_num;
			
			
			System.out.println("Hospital Address : " + hospital_address);
			System.out.println("Hospital Pincode : " + hospital_pincode);
			System.out.println("Hospital Number  : " + hospital_num);
			System.out.println("");
			
			System.out.println("Hospital Timing : 10AM - 8PM");
			System.out.println("Regular Checkups");
			System.out.println("Surgeries");
			System.out.println("Xray & Scans");
			
		}
		
		
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			a_kuppusamy a = new a_kuppusamy();
			a.hospital_details("Gandhipuram, Coimbatore",641027,"0422-7890654");
			

		}

	}

