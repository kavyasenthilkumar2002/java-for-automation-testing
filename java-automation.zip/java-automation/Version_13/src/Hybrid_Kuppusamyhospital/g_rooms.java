package Hybrid_Kuppusamyhospital;

	public class g_rooms extends c_patient{
		
		String patient_name;
		int room_number;
		
		void room_1(String patient_name,int room_number)
		{
			System.out.println("ROOM ALLOTMENTS");
			System.out.println("");
			System.out.println("Paitient Name : " + patient_name);
			System.out.println("Room Number   : " + room_number);
			System.out.println("");
			

		}
		
		void room_2(String patient_name,int room_number)
		{
			System.out.println("Paitient Name : " + patient_name);
			System.out.println("Room Number   : " + room_number);
			System.out.println("");
			

		}
		
		
		
		void display_g()
		{
			this.room_1("Anju",209);
			this.room_2("Deekshu",256);
		}

		public static void main(String[] args) {
			// TODO Auto-generated method stub

			g_rooms g = new g_rooms();
	        g.hospital_details("Gandhipuram, Coimbatore", 641027, "0422-7890654");
			g.display_c();
			g.display_g();
			
			
			
		}

	}


