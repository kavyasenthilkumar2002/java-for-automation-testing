package ERPSystem_Interface;
public class ERPSystem implements ERPFeatures {
    
	static
	{
		 System.out.println("ERPSystem");
	}
	
	public void systemOverview() {
        System.out.println("ERP System Overview");
    }

    public void studentManagement() {
        System.out.println("Student Records Managed");
    }

    public void attendanceSystem() {
        System.out.println("Attendance Tracked");
    }

    public static void main(String[] args) {
        ERPSystem e = new ERPSystem();
        e.systemOverview();
        e.studentManagement();
        e.attendanceSystem();
    }
}