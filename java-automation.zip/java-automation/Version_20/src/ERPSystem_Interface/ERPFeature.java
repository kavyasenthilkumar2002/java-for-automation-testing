package ERPSystem_Interface;
interface ERPFeatures extends ERPBase {
   
	void studentManagement();
    void attendanceSystem();

    public static void main(String[] args) {
    }
}