package ERPSystem_Interface;
interface ERPBase {
   
	abstract void studentManagement();

    public static void main(String[] args) {
    }
}
