package KuppuswamyHospital_Interface;
interface HospitalService extends HospitalBase {
    
	void patientRegistration();
    void treatmentProcess();

    public static void main(String[] args) {
    }
}