package KuppuswamyHospital_Interface;
interface HospitalBase {
   
	abstract void patientRegistration();

    public static void main(String[] args) {
    }
}

