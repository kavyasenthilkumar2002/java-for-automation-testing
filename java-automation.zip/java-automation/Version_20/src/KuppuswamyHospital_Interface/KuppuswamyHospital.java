package KuppuswamyHospital_Interface;
public class KuppuswamyHospital implements HospitalService {
    
	static
	{
		 System.out.println("KuppuswamyHospital");
	}
	
	public void hospitalInfo() {
        System.out.println("Hospital Information Displayed");
    }

    public void patientRegistration() {
        System.out.println("Patient Registered Successfully");
    }

    public void treatmentProcess() {
        System.out.println("Treatment Process Started");
    }

    public static void main(String[] args) {
        KuppuswamyHospital h = new KuppuswamyHospital();
        h.hospitalInfo();
        h.patientRegistration();
        h.treatmentProcess();
    }
}