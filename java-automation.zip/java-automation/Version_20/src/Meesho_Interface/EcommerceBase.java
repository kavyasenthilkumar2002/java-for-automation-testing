package Meesho_Interface;
interface EcommerceBase {
   
	abstract void productListing();

    public static void main(String[] args) {
    }
}