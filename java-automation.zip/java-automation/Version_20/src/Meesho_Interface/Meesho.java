package Meesho_Interface;
public class Meesho implements EcommerceFeatures {
    
	static
	{
		 System.out.println("Meesho");
	}
	
	public void ecommerceSupport() {
        System.out.println("E-commerce Support Active");
    }

    public void productListing() {
        System.out.println("Product Listed Successfully");
    }

    public void orderDelivery() {
        System.out.println("Order Delivered to Customer");
    }

    public static void main(String[] args) {
        Meesho m = new Meesho();
        m.ecommerceSupport();
        m.productListing();
        m.orderDelivery();
    }
}