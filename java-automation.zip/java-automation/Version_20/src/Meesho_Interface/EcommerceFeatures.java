package Meesho_Interface;
interface EcommerceFeatures extends EcommerceBase {
    
	void productListing();
    void orderDelivery();

    public static void main(String[] args) {
    }
}