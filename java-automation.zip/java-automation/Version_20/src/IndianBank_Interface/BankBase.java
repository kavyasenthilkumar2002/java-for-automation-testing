package IndianBank_Interface;
interface BankBase {
    
	abstract void account();

    public static void main(String[] args) {
    }
}