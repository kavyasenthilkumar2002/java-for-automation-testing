package IndianBank_Interface;
public class IndianBank implements BankServices {
   
	static
	{
		 System.out.println("IndianBank");
	}
	
	public void bankSupport() {
        System.out.println("Banking Support Active");
    }

    public void account() {
        System.out.println("Account Verified");
    }

    public void loan() {
        System.out.println("Loan Processing Started");
    }

    public static void main(String[] args) {
        IndianBank b = new IndianBank();
        b.bankSupport();
        b.account();
        b.loan();
    }
}