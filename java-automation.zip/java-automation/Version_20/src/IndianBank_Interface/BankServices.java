package IndianBank_Interface;
interface BankServices extends BankBase {
    
	void account();
    void loan();

    public static void main(String[] args) {
    }
}