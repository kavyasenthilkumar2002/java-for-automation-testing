package ACKOInsurance_Interface;
interface ACKOInsuranceSystem {
    
	abstract void policyInfo();

    public static void main(String[] args) {
    }
}