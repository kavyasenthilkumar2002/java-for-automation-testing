package ACKOInsurance_Interface;
interface InsuranceBase extends ACKOInsuranceSystem {
   
	void policyInfo();
    void claimProcess();

    public static void main(String[] args) {
    }
}