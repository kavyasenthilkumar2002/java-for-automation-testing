package ACKOInsurance_Interface;
public class InsuranceDetails implements InsuranceBase {
  
	static
	{
		 System.out.println("ACKOInsurance");
	}
	
	public void insuranceSupport() {
        System.out.println("Insurance Support Active");
    }

    public void policyInfo() {
        System.out.println("Policy Information Displayed");
    }

    public void claimProcess() {
        System.out.println("Claim Process Started");
    }

    public static void main(String[] args) {
    	InsuranceDetails a = new InsuranceDetails();
        a.insuranceSupport();
        a.policyInfo();
        a.claimProcess();
    }
}
