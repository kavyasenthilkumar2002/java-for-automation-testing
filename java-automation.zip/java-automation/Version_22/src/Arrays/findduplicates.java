package Arrays;
public class findduplicates {

    static {
        System.out.println("Duplicates in array");
    }

        public static void main(String[] args) {

            int a[] = {1, 1, 2, 3, 3, 3, 4, 5, 5};
            int visited = -1; // marker for counted elements

            for (int i = 0; i < a.length; i++) {

                if (a[i] == visited)
                    continue;

                int count = 1;

                for (int j = i + 1; j < a.length; j++) {

                    if (a[i] == a[j]) {
                        count++;
                        a[j] = visited; // mark as counted
                    }
                }

                if (count > 1)
                    System.out.println(a[i] + " : " + count + " times");
            }
        }
    }