package Arrays;
public class Greatestof3 {

    static {
        System.out.println("Greatest of 3 Numbers:");
    }

		   
		    public static void main(String[] args) {
		        int[] numbers = {45, 78, 32};
		        
		        int greatest = numbers[0];
		        
		   
		        for (int i = 1; i < numbers.length; i++) {
		            if (numbers[i] > greatest) {
		                greatest = numbers[i];
		            }
		        }
		        
		        System.out.print("Numbers are: ");
		        for (int i = 0; i < numbers.length; i++) {
		            System.out.print(numbers[i] + " ");
		        }
		        
		        System.out.println("\nGreatest number is: " + greatest);
		    }
	
	}


