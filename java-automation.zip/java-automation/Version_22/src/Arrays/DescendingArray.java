package Arrays;

public class DescendingArray {
	static {
        System.out.println("Array in Descending Order:");
    }

	    public static void main(String[] args) {
	        int[] rollno = {70, 30, 40, 50, 90};
	        int temp;

	        for (int i = 0; i < rollno.length; i++) {
	            for (int j = i + 1; j < rollno.length; j++) {
	                if (rollno[i] < rollno[j]) {
	                    temp = rollno[i];
	                    rollno[i] = rollno[j];
	                    rollno[j] = temp;
	                }
	            }
	        }

	        System.out.print("");
	        for (int i = 0; i < rollno.length; i++) {
	            System.out.print(rollno[i] + " ");
	        }

	        System.out.println("\n");
	        
	        //int add = 0;
	        //for (int i = 0; i < 3; i++) {
	       //     add += rollno[i];
	       //}
	       // System.out.println("Sum of top 3 elements: " + add);

	       
	    }
	}
