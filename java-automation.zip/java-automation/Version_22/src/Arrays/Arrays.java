package Arrays;
public class Arrays {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//int[] rollno =new int[5];
		int [] rollno= {10,20,30,40,50};
		
		String [] names= {"kavs","anu","jays","sanjee"};
		
		//System.out.println(rollno);
		
		for (int i=0;i<rollno.length;i++)
		{
			System.out.println(rollno[i]);
		}
		
		for (int i=0;i<names.length;i++)
		{
			System.out.println(names[i]);
		}
		
	}



	}

