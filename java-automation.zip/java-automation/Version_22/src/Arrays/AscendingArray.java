package Arrays;

public class AscendingArray {

    static {
        System.out.println("Array in Ascending Order:");
    }

    public static void main(String[] args) {
        int[] rollno = {70, 30, 40, 50, 90};
        int temp;
      
        for (int i = 0; i < rollno.length; i++) {
            for (int j = i + 1; j < rollno.length; j++) {
                if (rollno[i] > rollno[j]) {
                    temp = rollno[i];
                    rollno[i] = rollno[j];
                    rollno[j] = temp;
                }
            }
        }

        
        for (int i = 0; i < rollno.length; i++) {
            System.out.print(rollno[i] + " ");
            
            
        }
    }
}
