package Exceptinalhandling;
public class Array_Forloop {
	
	void array()
	{
			//int[] rollno =new int[10];
			int[] b= {10,20,30,40,50,60,70,80,90,100};
									
			
			for (int i=0;i<100;i++)
			{
				System.out.println(b[i]);
			}
	}	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Array_Forloop a= new Array_Forloop();
		a.array();


	}
}