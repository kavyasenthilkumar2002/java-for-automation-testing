package Exceptinalhandling;

public class throwkeyword {

    void demo() {
        String name = "Hello";
        
        System.out.println("Hello");
        throw new ArithmeticException("ERROR");
      
    }

    public static void main(String[] args) {
        throwkeyword a = new throwkeyword();
        a.demo();
    }
}
