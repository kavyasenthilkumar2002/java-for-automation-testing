package Exceptinalhandling;

public class throwskeyword {


	    void demo()  throws ArithmeticException,ArrayIndexOutOfBoundsException
	    {
	        String name = "Hello";
	        
	        System.out.println(name);
	          
	    }

	    public static void main(String[] args) {
	        throwkeyword a = new throwkeyword();
	        a.demo();
	    }
	}
