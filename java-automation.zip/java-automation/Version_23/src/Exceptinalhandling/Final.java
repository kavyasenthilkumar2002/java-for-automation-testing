package Exceptinalhandling;
public class Final {


	    final void calc(int a, int b) {
	        System.out.println(a);
	        System.out.println(b);
	    }

	    final void calc(String name, int d) {
	        System.out.println(name);
	        System.out.println(d);
	    }

	    public static void main(String[] args) {
	    	Final obj = new Final();
	        obj.calc(7, 11);
	        obj.calc("Kavya", 23);
	    }
	}

