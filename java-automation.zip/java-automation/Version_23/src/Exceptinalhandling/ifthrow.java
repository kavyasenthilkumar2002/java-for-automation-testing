package Exceptinalhandling;

public class ifthrow
{

	void demo()
	{
		int age=23;
		if(30 > age)
		{
		//System.out.println("Less than jays");
		throw new ArithmeticException("ERROR");
		}
		
	
		
		else
		{
			System.out.println("Greater than jays");
		}
	}
	
		
			
		
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ifthrow a = new ifthrow();
		a.demo();
				
	}

}
