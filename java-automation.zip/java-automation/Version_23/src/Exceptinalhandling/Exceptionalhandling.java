package Exceptinalhandling;

public class Exceptionalhandling {
	
	
	int a=10;
	int b=0;
	int c;
	
	void math()
	{
		c=a/b;
		System.out.println(c);
	}
	
	void maths()
	{
		System.out.println("Hello");
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Exceptionalhandling a= new Exceptionalhandling();
		a.math();
		a.maths();
	}

}
