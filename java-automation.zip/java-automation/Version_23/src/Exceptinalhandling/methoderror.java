package Exceptinalhandling;
public class methoderror {

	void demo()
	{
	try 
	{
		int a=10;
		int b=0;
		int c;
		c=a/b;
		//System.out.println(c);
		System.out.println("Hello");
	}
		
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	void demoss()
	{
	try 
	{
		int a=11;
		int b=0;
		int c;
		c=a%b;
		System.out.println(c);
		
	}
		
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		methoderror a=new methoderror();
		a.demo();
		a.demoss();
	}

}
