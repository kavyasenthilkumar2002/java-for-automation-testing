package Exceptinalhandling;

public class handlewithkeywords {

	void demo()
	{
	try 
	{
		int a=10;
		int b=0;
		int c;
		c=a/b;
		//System.out.println(c);
		System.out.println("Hello");
	}
		
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	void demoss()
	{
		System.out.println("hey");
	}
	
		
	

		public static void main(String[] args) {
			// TODO Auto-generated method stub

			handlewithkeywords a= new handlewithkeywords();
			a.demo();
			a.demoss();
			
		}

	}
