package Whileloop;

public class Countdown {

	    int i = 10;

	    static {
	        System.out.println("Countdown Program");
	        System.out.println("-----------------");
	    }

	    void startCountdown() {
	        while (i >= 1) {
	            System.out.println("Countdown: " + i);
	            i--;
	        }
	        System.out.println("Blast off!");
	    }

	    public static void main(String[] args) {
	        Countdown obj = new Countdown();
	        obj.startCountdown();
	    }
	}
