package Whileloop;

public class Multiplication {


	    int num = 5;
	    int i = 1;

	    static {
	        System.out.println("Multiplication Table Program");
	        System.out.println("----------------------------");
	    }

	    void displayTable() {
	        while (i <= 10) {
	            System.out.println(num + " x " + i + " = " + (num * i));
	            i++;
	        }
	    }

	    public static void main(String[] args) {
	    	Multiplication obj = new Multiplication();
	        obj.displayTable();
	    }
	}

