package Whileloop;

public class Sumofnumbers {


	    int i = 1;
	    int sum = 0;

	    static {
	        System.out.println("Sum of Numbers Program");
	        System.out.println("----------------------");
	    }

	    void calculateSum() {
	        while (i <= 10) {
	            sum += i;
	            i++;
	        }
	        System.out.println("Sum of first 10 numbers is: " + sum);
	    }

	    public static void main(String[] args) {
	    	Sumofnumbers obj = new Sumofnumbers();
	        obj.calculateSum();
	    }
	}
