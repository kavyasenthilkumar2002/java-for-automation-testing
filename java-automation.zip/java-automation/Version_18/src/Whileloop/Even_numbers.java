package Whileloop;

public class Even_numbers {


	    int i = 1;

	    static {
	        System.out.println("Even Numbers Program");
	        System.out.println("--------------------");
	    }

	    void showEvenNumbers() {
	        while (i <= 20) {
	            if (i % 2 == 0) {
	                System.out.println(i);
	            }
	            i++;
	        }
	    }

	    public static void main(String[] args) {
	    	Even_numbers obj = new Even_numbers();
	        obj.showEvenNumbers();
	    }
	}
