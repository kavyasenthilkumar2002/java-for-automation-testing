package Methods;

public class Bank {

		 void accountInfo() 
		 {
		        String accountHolderName = "Kavya";
		        String accountType = "Savings";
		        String accountStatus = "Active";
		        float accountBalance = 15340.75f;
		        boolean isJointAccount = false;
		        String accountCurrency = "INR";
		        String accountCreatedDate = "2022-05-10";
		        boolean accountFrozen = false;
		        String accountRegion = "South Zone";
		        System.out.println(" Account Info");
		        System.out.println("Account Holder Name: " + accountHolderName);
		        System.out.println("Account Type: " + accountType);
		        System.out.println("Account Status: " + accountStatus);
		        System.out.println("Account Balance: " + accountBalance);
		        System.out.println("Joint Account: " + isJointAccount);
		        System.out.println("Currency: " + accountCurrency);
		        System.out.println("Created Date: " + accountCreatedDate);
		        System.out.println("Account Frozen: " + accountFrozen);
		        System.out.println("Account Region: " + accountRegion);
		        System.out.println();
		    }

		    void adminInfo() 
		    {
		        String adminName = "Ravi Kumar";
		        String adminEmail = "ravi@bank.com";
		        String adminRole = "Manager";
		        boolean adminActive = true;
		        String adminBranch = "Chennai";
		        int adminId = 1002;
		        boolean canOverride = true;
		        String adminAccessLevel = "Full";
		        System.out.println(" Admin Info");
		        System.out.println("Admin Name: " + adminName);
		        System.out.println("Admin Email: " + adminEmail);
		        System.out.println("Admin Role: " + adminRole);
		        System.out.println("Admin Active: " + adminActive);
		        System.out.println("Admin Branch: " + adminBranch);
		        System.out.println("Admin ID: " + adminId);
		        System.out.println("Can Override: " + canOverride);
		        System.out.println("Access Level: " + adminAccessLevel);
		        System.out.println();
		    }

		    void branchInfo() 
		    {
		        String branchName = "Chennai Main";
		        String branchCode = "CHN001";
		        String branchCity = "Chennai";
		        String branchState = "Tamil Nadu";
		        String branchCountry = "India";
		        boolean branchOperational = true;
		        int numberOfEmployees = 35;
		        boolean hasLoanDept = true;
		        boolean hasCashCounter = true;
		        System.out.println(" Branch Info");
		        System.out.println("Branch Name: " + branchName);
		        System.out.println("Branch Code: " + branchCode);
		        System.out.println("Branch City: " + branchCity);
		        System.out.println("Branch State: " + branchState);
		        System.out.println("Branch Country: " + branchCountry);
		        System.out.println("Branch Operational: " + branchOperational);
		        System.out.println("Number of Employees: " + numberOfEmployees);
		        System.out.println("Has Loan Dept: " + hasLoanDept);
		        System.out.println("Has Cash Counter: " + hasCashCounter);
		        System.out.println();
		    }

		    void cardInfo() 
		    {
		        String cardType = "Credit";
		        String cardNumber = "4111-1111-1111-1234";
		        boolean cardActive = true;
		        float cardLimit = 75000.0f;
		        float currentUsage = 5200.0f;
		        boolean contactlessEnabled = true;
		        String cardExpiry = "08/28";
		        boolean isInternational = true;
		        String cardStatus = "Active";
		        System.out.println(" Card Info");
		        System.out.println("Card Type: " + cardType);
		        System.out.println("Card Number: " + cardNumber);
		        System.out.println("Card Active: " + cardActive);
		        System.out.println("Card Limit: " + cardLimit);
		        System.out.println("Current Usage: " + currentUsage);
		        System.out.println("Contactless Enabled: " + contactlessEnabled);
		        System.out.println("Card Expiry: " + cardExpiry);
		        System.out.println("International: " + isInternational);
		        System.out.println("Card Status: " + cardStatus);
		        System.out.println();
		    }

		    void customerInfo() 
		    {
		        String customerName = "Meera";
		        String customerEmail = "meera@domain.com";
		        String customerPhone = "9876543211";
		        boolean kycVerified = true;
		        String customerType = "Retail";
		        String customerGender = "Female";
		        int customerAge = 29;
		        boolean isSeniorCitizen = false;
		        boolean emailSubscribed = true;
		        System.out.println(" Customer Info");
		        System.out.println("Customer Name: " + customerName);
		        System.out.println("Email: " + customerEmail);
		        System.out.println("Phone: " + customerPhone);
		        System.out.println("KYC Verified: " + kycVerified);
		        System.out.println("Customer Type: " + customerType);
		        System.out.println("Gender: " + customerGender);
		        System.out.println("Age: " + customerAge);
		        System.out.println("Senior Citizen: " + isSeniorCitizen);
		        System.out.println("Email Subscribed: " + emailSubscribed);
		        System.out.println();
		    }

		    void loanInfo() 
		    {
		        String loanType = "Home Loan";
		        float loanAmount = 1500000.0f;
		        float interestRate = 7.5f;
		        int loanTenureYears = 20;
		        String loanStatus = "Approved";
		        boolean isSecured = true;
		        String repaymentMode = "EMI";
		        boolean autoDebitEnabled = true;
		        String collateralType = "Property";
		        System.out.println(" Loan Info");
		        System.out.println("Loan Type: " + loanType);
		        System.out.println("Loan Amount: " + loanAmount);
		        System.out.println("Interest Rate: " + interestRate);
		        System.out.println("Tenure (Years): " + loanTenureYears);
		        System.out.println("Loan Status: " + loanStatus);
		        System.out.println("Secured: " + isSecured);
		        System.out.println("Repayment Mode: " + repaymentMode);
		        System.out.println("Auto Debit Enabled: " + autoDebitEnabled);
		        System.out.println("Collateral Type: " + collateralType);
		        System.out.println();
		    }

		    void notificationInfo() 
		    {
		        boolean smsAlertsEnabled = true;
		        boolean emailAlertsEnabled = true;
		        String lastNotification = "OTP Sent";
		        String notificationType = "Transaction";
		        boolean appNotificationsEnabled = true;
		        boolean promotionalSMS = false;
		        boolean promotionalEmail = false;
		        String alertPreference = "Critical Only";
		        boolean doNotDisturb = false;
		        System.out.println(" Notification Settings");
		        System.out.println("SMS Alerts: " + smsAlertsEnabled);
		        System.out.println("Email Alerts: " + emailAlertsEnabled);
		        System.out.println("Last Notification: " + lastNotification);
		        System.out.println("Notification Type: " + notificationType);
		        System.out.println("App Notifications: " + appNotificationsEnabled);
		        System.out.println("Promotional SMS: " + promotionalSMS);
		        System.out.println("Promotional Email: " + promotionalEmail);
		        System.out.println("Alert Preference: " + alertPreference);
		        System.out.println("Do Not Disturb: " + doNotDisturb);
		        System.out.println();
		    }

		    void paymentInfo() {
		        String paymentMethod = "UPI";
		        float paymentAmount = 5500.0f;
		        boolean paymentSuccessful = true;
		        String paymentStatus = "Completed";
		        String paymentDate = "2025-07-29";
		        String receiverName = "Ganesh Traders";
		        String receiverAccount = "1234567890";
		        String ifscCode = "INDB0000234";
		        boolean isRecurring = false;
		        System.out.println(" Payment Info");
		        System.out.println("Payment Method: " + paymentMethod);
		        System.out.println("Payment Amount: " + paymentAmount);
		        System.out.println("Payment Successful: " + paymentSuccessful);
		        System.out.println("Payment Status: " + paymentStatus);
		        System.out.println("Payment Date: " + paymentDate);
		        System.out.println("Receiver Name: " + receiverName);
		        System.out.println("Receiver Account: " + receiverAccount);
		        System.out.println("IFSC Code: " + ifscCode);
		        System.out.println("Recurring Payment: " + isRecurring);
		        System.out.println();
		    }

		    void supportInfo() 
		    {
		        String supportTicketId = "SUP90876";
		        String supportQuery = "Unable to reset password";
		        String supportStatus = "Resolved";
		        boolean escalationRequested = false;
		        String assignedAgent = "Deepak";
		        boolean liveChatUsed = true;
		        String resolutionDate = "2025-07-28";
		        boolean feedbackGiven = true;
		        String feedbackComment = "Very helpful staff";
		        System.out.println(" Support Info");
		        System.out.println("Ticket ID: " + supportTicketId);
		        System.out.println("Query: " + supportQuery);
		        System.out.println("Status: " + supportStatus);
		        System.out.println("Escalation Requested: " + escalationRequested);
		        System.out.println("Assigned Agent: " + assignedAgent);
		        System.out.println("Live Chat Used: " + liveChatUsed);
		        System.out.println("Resolution Date: " + resolutionDate);
		        System.out.println("Feedback Given: " + feedbackGiven);
		        System.out.println("Feedback Comment: " + feedbackComment);
		        System.out.println();
		    }

		    void transactionInfo() 
		    {
		        String transactionId = "TXN123456";
		        float transactionAmount = 1500.0f;
		        String transactionType = "Debit";
		        String transactionMode = "Net Banking";
		        String transactionDate = "2025-07-27";
		        boolean transactionReversed = false;
		        String transactionDescription = "Online Shopping";
		        boolean transactionFlagged = false;
		        boolean transactionApproved = true;
		        System.out.println(" Transaction Info");
		        System.out.println("Transaction ID: " + transactionId);
		        System.out.println("Amount: " + transactionAmount);
		        System.out.println("Type: " + transactionType);
		        System.out.println("Mode: " + transactionMode);
		        System.out.println("Date: " + transactionDate);
		        System.out.println("Reversed: " + transactionReversed);
		        System.out.println("Description: " + transactionDescription);
		        System.out.println("Flagged: " + transactionFlagged);
		        System.out.println("Approved: " + transactionApproved);
		        System.out.println();
		    }
		public static void main(String[] args) 
		{
			// TODO Auto-generated method stub

		}

	}
