package Methods;

public class Insurance {
	
		    void acko_admin() 
		    {
		        String adminId = "ADM001";
		        String adminName = "Ravi Kumar";
		        String adminEmail = "admin@acko.com";
		        boolean isAdminActive = true;
		        String adminDepartment = "Operations";
		        System.out.println("Admin");
		        System.out.println("Admin ID: " + adminId);
		        System.out.println("Admin Name: " + adminName);
		        System.out.println("Admin Email: " + adminEmail);
		        System.out.println("Admin Active: " + isAdminActive);
		        System.out.println("Admin Department: " + adminDepartment);
		        System.out.println();
		    }

		    void acko_claims() 
		    {
		        String claimId = "CLM20250730";
		        String claimType = "Vehicle Damage";
		        boolean claimApproved = false;
		        float claimAmount = 15000.75f;
		        String claimStatus = "Pending";
		        String claimDate = "2025-07-30";
		        System.out.println("Claims");
		        System.out.println("Claim ID: " + claimId);
		        System.out.println("Claim Type: " + claimType);
		        System.out.println("Claim Approved: " + claimApproved);
		        System.out.println("Claim Amount: " + claimAmount);
		        System.out.println("Claim Status: " + claimStatus);
		        System.out.println("Claim Date: " + claimDate);
		        System.out.println();
		    }

		    void acko_notifications()
		    {
		        String notificationId = "NTF001";
		        String notificationType = "Email";
		        boolean isNotificationRead = false;
		        String notificationMessage = "Policy expires soon";
		        String notificationSentDate = "2025-07-29";
		        System.out.println("Notifications");
		        System.out.println("Notification ID: " + notificationId);
		        System.out.println("Notification Type: " + notificationType);
		        System.out.println("Notification Read: " + isNotificationRead);
		        System.out.println("Message: " + notificationMessage);
		        System.out.println("Sent Date: " + notificationSentDate);
		        System.out.println();
		    }

		    void acko_payment() 
		    {
		        String paymentId = "PAY1023";
		        float paymentAmount = 3999.50f;
		        boolean isPaymentSuccessful = true;
		        String paymentMethod = "Credit Card";
		        String paymentDate = "2025-07-28";
		        System.out.println("Payment");
		        System.out.println("Payment ID: " + paymentId);
		        System.out.println("Payment Amount: " + paymentAmount);
		        System.out.println("Payment Successful: " + isPaymentSuccessful);
		        System.out.println("Payment Method: " + paymentMethod);
		        System.out.println("Payment Date: " + paymentDate);
		        System.out.println();
		    }

		    void acko_policy() 
		    {
		        String policyNumber = "ACKO123456";
		        String policyHolderName = "Sneha";
		        boolean isPolicyActive = true;
		        float policyCoverage = 500000.0f;
		        String policyStartDate = "2025-01-01";
		        String policyEndDate = "2026-01-01";
		        System.out.println("Policy");
		        System.out.println("Policy Number: " + policyNumber);
		        System.out.println("Policy Holder: " + policyHolderName);
		        System.out.println("Policy Active: " + isPolicyActive);
		        System.out.println("Coverage Amount: " + policyCoverage);
		        System.out.println("Start Date: " + policyStartDate);
		        System.out.println("End Date: " + policyEndDate);
		        System.out.println();
		    }

		    void acko_products() 
		    {
		        String productName = "Car Insurance";
		        String productType = "Comprehensive";
		        float productPremium = 4800.0f;
		        boolean isCashlessServiceAvailable = true;
		        String productDescription = "Covers theft, damage, and personal accident";
		        System.out.println("Products");
		        System.out.println("Product Name: " + productName);
		        System.out.println("Product Type: " + productType);
		        System.out.println("Premium: " + productPremium);
		        System.out.println("Cashless Service: " + isCashlessServiceAvailable);
		        System.out.println("Description: " + productDescription);
		        System.out.println();
		    }

		    void acko_security() 
		    {
		        boolean otpEnabled = true;
		        boolean isBiometricLoginEnabled = false;
		        String lastPasswordChangeDate = "2025-07-20";
		        boolean isSuspiciousLoginDetected = false;
		        String loginMethod = "Email";
		        System.out.println("Security");
		        System.out.println("OTP Enabled: " + otpEnabled);
		        System.out.println("Biometric Login Enabled: " + isBiometricLoginEnabled);
		        System.out.println("Last Password Change: " + lastPasswordChangeDate);
		        System.out.println("Suspicious Login Detected: " + isSuspiciousLoginDetected);
		        System.out.println("Login Method: " + loginMethod);
		        System.out.println();
		    }

		    void acko_support() 
		    {
		        String supportTicketId = "SUP001";
		        String issueType = "Login Issue";
		        boolean isIssueResolved = true;
		        String assignedAgent = "Divya";
		        String resolutionStatus = "Closed";
		        System.out.println("Support");
		        System.out.println("Ticket ID: " + supportTicketId);
		        System.out.println("Issue Type: " + issueType);
		        System.out.println("Issue Resolved: " + isIssueResolved);
		        System.out.println("Assigned Agent: " + assignedAgent);
		        System.out.println("Resolution Status: " + resolutionStatus);
		        System.out.println();
		    }

		    void acko_underwriting() 
		    {
		        String underwriterName = "Amit Sharma";
		        String riskLevel = "Medium";
		        float proposedPremium = 4200.75f;
		        boolean isManualReviewNeeded = false;
		        String underwritingNotes = "Eligible with standard premium";
		        System.out.println("Underwriting");
		        System.out.println("Underwriter: " + underwriterName);
		        System.out.println("Risk Level: " + riskLevel);
		        System.out.println("Proposed Premium: " + proposedPremium);
		        System.out.println("Manual Review Needed: " + isManualReviewNeeded);
		        System.out.println("Notes: " + underwritingNotes);
		        System.out.println();
		    }

		    void acko_user() 
		    {
		        String userId = "USR999";
		        String userName = "Kavya";
		        String userEmail = "kavya@gmail.com";
		        boolean isEmailVerified = true;
		        int userAge = 24;
		        boolean isPremiumUser = true;
		        System.out.println("User");
		        System.out.println("User ID: " + userId);
		        System.out.println("Name: " + userName);
		        System.out.println("Email: " + userEmail);
		        System.out.println("Email Verified: " + isEmailVerified);
		        System.out.println("Age: " + userAge);
		        System.out.println("Premium User: " + isPremiumUser);
		        System.out.println();
		    }

		    void acko_vehicle()
		    {
		        String vehicleNumber = "TN10AB1234";
		        String vehicleType = "SUV";
		        int vehicleYear = 2022;
		        float engineCapacity = 1497.0f;
		        boolean isVehicleInsured = true;
		        String fuelType = "Petrol";
		        System.out.println("Vehicle");
		        System.out.println("Vehicle Number: " + vehicleNumber);
		        System.out.println("Vehicle Type: " + vehicleType);
		        System.out.println("Year: " + vehicleYear);
		        System.out.println("Engine Capacity: " + engineCapacity);
		        System.out.println("Insured: " + isVehicleInsured);
		        System.out.println("Fuel Type: " + fuelType);
		        System.out.println();
		    }

		    void acko_location()
		    {
		        String city = "Coimbatore";
		        String state = "Tamil Nadu";
		        String country = "India";
		        int pinCode = 641045;
		        System.out.println("Location");
		        System.out.println("City: " + city);
		        System.out.println("State: " + state);
		        System.out.println("Country: " + country);
		        System.out.println("Pin Code: " + pinCode);
		        System.out.println();
		    }

		        

		public static void main(String[] args) 
		{
			// TODO Auto-generated method stub

		}

	}

