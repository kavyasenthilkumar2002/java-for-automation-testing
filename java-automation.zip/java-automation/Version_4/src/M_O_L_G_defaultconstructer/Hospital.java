package M_O_L_G_defaultconstructer;

public class Hospital {



	    // Global variable
	    String hospitalName = "Kuppuswamy Hospital";

	    // Default constructor
	    Hospital() {
	        System.out.println("=== Welcome to " + hospitalName + " ===");
	    }

	    void hospital_adminInfo() {
	        // Local variable
	        String adminName = "Dr. Arjun";
	        System.out.println("Hospital: " + hospitalName);
	        System.out.println("Admin Name: " + adminName);
	    }

	    void hospital_userInfo() {
	        String userName = "Kavya";
	        System.out.println("Hospital: " + hospitalName);
	        System.out.println("User Name: " + userName);
	    }


	    public static void main(String[] args) {
	        Hospital h = new Hospital();
	        h.hospital_adminInfo();
	        h.hospital_userInfo();

	    }
	}


