package M_O_L_G_defaultconstructer;

public class Bank {


	    // Global variable
	    String bankName = "Indian Bank";

	    // Default constructor
	    Bank() 
	    {
	        String branchName = "Chennai Branch"; // Local variable in constructor
	        System.out.println("Bank: " + bankName);
	        System.out.println("Branch: " + branchName);
	    }

	    void accountInfo()
	    {
	        // Local variable
	        String accountHolder = "Kavya";
	        String bankName = "Canara Bank"; 

	        System.out.println("Bank: " + bankName);
	        System.out.println("Account Holder: " + accountHolder);
	    }


	    public static void main(String[] args) {
	        Bank b = new Bank();  
	        b.accountInfo();
	       
	    }
	}

