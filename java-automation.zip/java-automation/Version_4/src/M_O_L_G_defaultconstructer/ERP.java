package M_O_L_G_defaultconstructer;

public class ERP {


	    // Global Variable
	    String companyName;

	    // Default Constructor
	    ERP() {
	        companyName = "ABC Pvt"; 
	        System.out.println("Default Constructor: ERP System Initialized for " + companyName);
	    }

	 // Local Variable
	    void assets() {
	        String assetName = "Dell Laptop"; 
	        System.out.println(companyName + " - Assets: " + assetName);
	    }

	    void finance() {
	        String fiscalYear = "2024-2025"; 
	        System.out.println(companyName + " - Finance Year: " + fiscalYear);
	    }

	    void hr() {
	        String employeeName = "Nandhini"; 
	        System.out.println(companyName + " - Employee: " + employeeName);
	    }

	    void inventory() {
	        String itemName = "Printer Ink"; 
	        System.out.println(companyName + " - Inventory Item: " + itemName);
	    }

	    void manufacturing() {
	        String productLine = "Textiles"; 
	        System.out.println(companyName + " - Product Line: " + productLine);
	    }

	    void projects() {
	        String projectName = "ERP Revamp"; 
	        System.out.println(companyName + " - Project: " + projectName);
	    }

	    public static void main(String[] args) {
	        ERP e = new ERP(); 
	        e.assets();
	        e.finance();
	        e.hr();
	        e.inventory();
	        e.manufacturing();
	        e.projects();
	    }
	}

