package M_O_L_G_defaultconstructer;

public class ecommerce {

	    // Global variable
	    String platformName = "Meesho";

	    // Default constructor
	    ecommerce()
	    {
	        System.out.println("Welcome to " + platformName + " E-commerce Platform");
	    }

	    // Product Info
	    void productInfo()
	    {
	    	// Local variable
	        String productName = "Floral Anarkali Kurti"; 
	        System.out.println("Platform: " + platformName);
	        System.out.println("Product Name: " + productName);
	    }

	    // Product Price
	    void productPrice() 
	    {
	        float price = 749.50f; // Local variable
	        System.out.println("Platform: " + platformName);
	        System.out.println("Price: ₹" + price);
	    }

	    // Product Category
	    void productCategory() 
	    {
	        String category = "Women's Clothing"; // Local variable
	        System.out.println("Platform: " + platformName);
	        System.out.println("Category: " + category);
	    }

	    // Product Stock Status
	    void stockStatus() 
	    {
	        boolean inStock = true; // Local variable
	        System.out.println("Platform: " + platformName);
	        System.out.println("In Stock: " + inStock);
	    }

	    public static void main(String[] args) {
	    	ecommerce m = new ecommerce(); // Calls default constructor
	        m.productInfo();
	        m.productPrice();
	        m.productCategory();
	        m.stockStatus();
	    }
	}


