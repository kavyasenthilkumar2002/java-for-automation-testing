package M_O_L_G_defaultconstructer;

public class Insurance {


	    // Global variable
	    String companyName = "ACKO Insurance";

	    // Default Constructor
	    Insurance() {
	        System.out.println("Welcome to " + companyName + "!");
	    }

	 // Local Variable
	    void acko_admin() {
	        String adminName = "Ravi Kumar"; 
	        System.out.println(companyName + " - Admin: " + adminName);
	    }

	    void acko_claims() {
	        String claimId = "CLM20250730";
	        System.out.println(companyName + " - Claim ID: " + claimId);
	    }

	    void acko_payment() {
	        String paymentId = "PAY1023";
	        System.out.println(companyName + " - Payment ID: " + paymentId);
	    }

	    void acko_policy() {
	        String policyNumber = "ACKO123456";
	        System.out.println(companyName + " - Policy No: " + policyNumber);
	    }

	    void acko_products() {
	        String productName = "Car Insurance";
	        System.out.println(companyName + " - Product: " + productName);
	    }

	    void acko_security() {
	        String loginMethod = "Email";
	        System.out.println(companyName + " - Login Method: " + loginMethod);
	    }


	    public static void main(String[] args) {
	        String branchName = "Main Branch"; // Local variable in main method
	        Insurance obj = new Insurance();
	        System.out.println("Branch: " + branchName);

	        obj.acko_admin();
	        obj.acko_claims();
	        obj.acko_payment();
	        obj.acko_policy();
	        obj.acko_products();
	        obj.acko_security();

	    }
	}


