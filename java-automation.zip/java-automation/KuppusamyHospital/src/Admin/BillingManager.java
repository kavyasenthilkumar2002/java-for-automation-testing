package Admin;

public class BillingManager {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
