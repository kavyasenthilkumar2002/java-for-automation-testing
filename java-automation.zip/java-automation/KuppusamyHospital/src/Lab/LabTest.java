package Lab;

public class LabTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
