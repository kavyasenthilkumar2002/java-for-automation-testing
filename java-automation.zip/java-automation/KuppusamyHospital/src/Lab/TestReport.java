package Lab;

public class TestReport {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
