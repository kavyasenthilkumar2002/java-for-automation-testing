package Lab;

public class LabTechnician {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
