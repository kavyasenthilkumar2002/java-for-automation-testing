package Lab;

public class SampleCollection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
