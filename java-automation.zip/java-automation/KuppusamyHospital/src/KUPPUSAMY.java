
public class KUPPUSAMY {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Admin
	    String adminName = "Dr. Arjun";
	    String adminEmail = "arjun@hospital.com";
	    boolean adminActive = true;
	    String adminRole = "Administrator";
	    int adminId = 101;
	    System.out.println(" Admin Info");
	    System.out.println("Admin Name: " + adminName);
	    System.out.println("Admin Email: " + adminEmail);
	    System.out.println("Admin Active: " + adminActive);
	    System.out.println("Admin Role: " + adminRole);
	    System.out.println("Admin ID: " + adminId);
	    System.out.println();

	    // App User
	    String userName = "Kavya";
	    String userEmail = "kavya@gmail.com";
	    String userRole = "Patient";
	    boolean userVerified = true;
	    int userAge = 25;
	    String userGender = "Female";
	    String userPhone = "9876543210";
	    String userCity = "Coimbatore";
	    boolean isInsured = true;
	    System.out.println("App User Info");
	    System.out.println("User Name: " + userName);
	    System.out.println("User Email: " + userEmail);
	    System.out.println("User Role: " + userRole);
	    System.out.println("User Verified: " + userVerified);
	    System.out.println("User Age: " + userAge);
	    System.out.println("User Gender: " + userGender);
	    System.out.println("User Phone: " + userPhone);
	    System.out.println("User City: " + userCity);
	    System.out.println("Insured: " + isInsured);
	    System.out.println();

	    // Cardiology
	    String cardiologistName = "Dr. Ramesh";
	    String heartCondition = "Arrhythmia";
	    float heartRate = 78.5f;
	    boolean requiresECG = true;
	    String cholesterolStatus = "Normal";
	    boolean takingBetaBlockers = false;
	    int bloodPressureSystolic = 120;
	    int bloodPressureDiastolic = 80;
	    boolean hasFamilyHistory = true;
	    System.out.println("Cardiology");
	    System.out.println("Cardiologist Name: " + cardiologistName);
	    System.out.println("Heart Condition: " + heartCondition);
	    System.out.println("Heart Rate: " + heartRate);
	    System.out.println("Requires ECG: " + requiresECG);
	    System.out.println("Cholesterol Status: " + cholesterolStatus);
	    System.out.println("Taking Beta Blockers: " + takingBetaBlockers);
	    System.out.println("Blood Pressure Systolic: " + bloodPressureSystolic);
	    System.out.println("Blood Pressure Diastolic: " + bloodPressureDiastolic);
	    System.out.println("Family History: " + hasFamilyHistory);
	    System.out.println();

	    // Emergency
	    String emergencyType = "Accident";
	    boolean isCritical = true;
	    int ambulanceArrivalMinutes = 12;
	    boolean firstAidGiven = true;
	    String emergencyLevel = "High";
	    String attendingDoctor = "Dr. Sameer";
	    System.out.println("Emergency");
	    System.out.println("Emergency Type: " + emergencyType);
	    System.out.println("Is Critical: " + isCritical);
	    System.out.println("Ambulance Arrival (Minutes): " + ambulanceArrivalMinutes);
	    System.out.println("First Aid Given: " + firstAidGiven);
	    System.out.println("Emergency Level: " + emergencyLevel);
	    System.out.println("Attending Doctor: " + attendingDoctor);
	    System.out.println();

	    // Gastroenterology
	    String gastroIssue = "Ulcer";
	    String endoscopyStatus = "Scheduled";
	    boolean hasAbdominalPain = true;
	    float stomachAcidLevel = 2.0f;
	    boolean consumingProbiotics = true;
	    String digestiveCondition = "Gastritis";
	    System.out.println("Gastroenterology");
	    System.out.println("Gastro Issue: " + gastroIssue);
	    System.out.println("Endoscopy Status: " + endoscopyStatus);
	    System.out.println("Has Abdominal Pain: " + hasAbdominalPain);
	    System.out.println("Stomach Acid Level: " + stomachAcidLevel);
	    System.out.println("Consuming Probiotics: " + consumingProbiotics);
	    System.out.println("Digestive Condition: " + digestiveCondition);
	    System.out.println();

	    // General
	    String generalDoctor = "Dr. Priya";
	    String consultationType = "Outpatient";
	    float bodyTemperature = 98.6f;
	    boolean hasFever = false;
	    String generalSymptoms = "Headache";
	    int waitingTimeMinutes = 15;
	    System.out.println(" General ");
	    System.out.println("General Doctor: " + generalDoctor);
	    System.out.println("Consultation Type: " + consultationType);
	    System.out.println("Body Temperature: " + bodyTemperature);
	    System.out.println("Has Fever: " + hasFever);
	    System.out.println("General Symptoms: " + generalSymptoms);
	    System.out.println("Waiting Time (Minutes): " + waitingTimeMinutes);
	    System.out.println();

	    // Lab
	    String testName = "Complete Blood Count";
	    boolean isTestCompleted = false;
	    float hemoglobinLevel = 13.4f;
	    String labTechnician = "Mr. Raju";
	    boolean isFastingRequired = true;
	    String labStatus = "In Progress";
	    System.out.println("Lab");
	    System.out.println("Test Name: " + testName);
	    System.out.println("Test Completed: " + isTestCompleted);
	    System.out.println("Hemoglobin Level: " + hemoglobinLevel);
	    System.out.println("Lab Technician: " + labTechnician);
	    System.out.println("Fasting Required: " + isFastingRequired);
	    System.out.println("Lab Status: " + labStatus);
	    System.out.println();

	    // Neurology
	    String neurologistName = "Dr. Meena";
	    String neuroIssue = "Migraine";
	    boolean needsMRI = true;
	    String eegStatus = "Completed";
	    boolean hasSeizures = false;
	    int neuroScore = 5;
	    System.out.println(" Neurology");
	    System.out.println("Neurologist Name: " + neurologistName);
	    System.out.println("Neuro Issue: " + neuroIssue);
	    System.out.println("Needs MRI: " + needsMRI);
	    System.out.println("EEG Status: " + eegStatus);
	    System.out.println("Has Seizures: " + hasSeizures);
	    System.out.println("Neuro Score: " + neuroScore);
	    System.out.println();

	    // Orthopedics
	    String orthoProblem = "Fracture";
	    boolean requiresPlaster = true;
	    float boneDensity = 1.2f;
	    String injurySide = "Left";
	    boolean hasJointPain = false;
	    String rehabStatus = "Ongoing";
	    System.out.println("Orthopedics");
	    System.out.println("Ortho Problem: " + orthoProblem);
	    System.out.println("Requires Plaster: " + requiresPlaster);
	    System.out.println("Bone Density: " + boneDensity);
	    System.out.println("Injury Side: " + injurySide);
	    System.out.println("Has Joint Pain: " + hasJointPain);
	    System.out.println("Rehab Status: " + rehabStatus);
	    System.out.println();

	    // Pulmonology
	    String lungIssue = "Asthma";
	    String inhalerType = "Salbutamol";
	    boolean isSmoker = false;
	    float oxygenSaturation = 96.5f;
	    boolean underVentilator = false;
	    int respirationRate = 18;
	    System.out.println(" Pulmonology");
	    System.out.println("Lung Issue: " + lungIssue);
	    System.out.println("Inhaler Type: " + inhalerType);
	    System.out.println("Is Smoker: " + isSmoker);
	    System.out.println("Oxygen Saturation: " + oxygenSaturation);
	    System.out.println("Under Ventilator: " + underVentilator);
	    System.out.println("Respiration Rate: " + respirationRate);
	    System.out.println();

	    // Additional information
	    
	    String covidStatus = "Negative";
	    boolean hasAllergies = true;
	    String allergyType = "Dust";
	    String bloodGroup = "O+";
	    boolean diabetic = false;
	    float bloodSugar = 89.0f;
	    boolean hasThyroid = false;
	    String vaccinationStatus = "Fully Vaccinated";
	    int vaccineDoses = 2;
	    String insuranceProvider = "Star Health";
	    String policyNumber = "HSP1002098";
	    boolean policyActive = true;
	    int policyValidityYears = 2;
	    String admissionType = "Planned";
	    String admissionDate = "2025-07-29";
	    boolean discharged = false;
	    String dischargeSummary = "Recovery ongoing";
	    String departmentVisited = "ENT";
	    String feedback = "Excellent service";
	    int feedbackScore = 9;
	    boolean referredByDoctor = false;
	    String referralDoctorName = "Dr. Naveen";
	    String currentWard = "General Ward";
	    boolean underObservation = true;
	    System.out.println("Additional Information");
	    System.out.println("COVID Status: " + covidStatus);
	    System.out.println("Has Allergies: " + hasAllergies);
	    System.out.println("Allergy Type: " + allergyType);
	    System.out.println("Blood Group: " + bloodGroup);
	    System.out.println("Diabetic: " + diabetic);
	    System.out.println("Blood Sugar: " + bloodSugar);
	    System.out.println("Has Thyroid: " + hasThyroid);
	    System.out.println("Vaccination Status: " + vaccinationStatus);
	    System.out.println("Vaccine Doses: " + vaccineDoses);
	    System.out.println("Insurance Provider: " + insuranceProvider);
	    System.out.println("Policy Number: " + policyNumber);
	    System.out.println("Policy Active: " + policyActive);
	    System.out.println("Policy Validity (Years): " + policyValidityYears);
	    System.out.println("Admission Type: " + admissionType);
	    System.out.println("Admission Date: " + admissionDate);
	    System.out.println("Discharged: " + discharged);
	    System.out.println("Discharge Summary: " + dischargeSummary);
	    System.out.println("Department Visited: " + departmentVisited);
	    System.out.println("Feedback: " + feedback);
	    System.out.println("Feedback Score: " + feedbackScore);
	    System.out.println("Referred by Doctor: " + referredByDoctor);
	    System.out.println("Referral Doctor Name: " + referralDoctorName);
	    System.out.println("Current Ward: " + currentWard);
	    System.out.println("Under Observation: " + underObservation);
	    System.out.println();
	   
		   }
		}
