package cardiology;

public class AngiogramRecord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
