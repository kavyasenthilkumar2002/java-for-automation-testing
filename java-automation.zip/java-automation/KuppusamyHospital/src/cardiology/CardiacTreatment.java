package cardiology;

public class CardiacTreatment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
