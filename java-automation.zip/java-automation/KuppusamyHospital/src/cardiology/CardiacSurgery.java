package cardiology;

public class CardiacSurgery {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
