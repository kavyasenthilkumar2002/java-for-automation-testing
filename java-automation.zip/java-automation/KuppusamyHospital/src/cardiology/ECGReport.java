package cardiology;

public class ECGReport {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
