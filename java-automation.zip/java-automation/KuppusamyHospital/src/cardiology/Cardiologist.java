package cardiology;

public class Cardiologist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
