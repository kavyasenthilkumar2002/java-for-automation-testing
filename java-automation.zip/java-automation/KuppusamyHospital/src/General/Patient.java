package General;

public class Patient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
