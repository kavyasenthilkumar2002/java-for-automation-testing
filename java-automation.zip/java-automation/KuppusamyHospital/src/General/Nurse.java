package General;

public class Nurse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
