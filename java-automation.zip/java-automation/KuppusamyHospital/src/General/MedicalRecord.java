package General;

public class MedicalRecord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
