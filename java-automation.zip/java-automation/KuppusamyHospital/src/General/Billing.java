package General;

public class Billing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
