package app_user;

public class PatientPortal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
