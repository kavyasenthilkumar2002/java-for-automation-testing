package Pulmonology;

public class COPDCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
