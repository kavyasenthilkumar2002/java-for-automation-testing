package Pulmonology;

public class AsthmaTreatment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
