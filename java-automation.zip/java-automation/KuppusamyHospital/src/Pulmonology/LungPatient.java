package Pulmonology;

public class LungPatient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
