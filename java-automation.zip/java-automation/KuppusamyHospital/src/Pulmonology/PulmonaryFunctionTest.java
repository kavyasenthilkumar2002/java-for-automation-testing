package Pulmonology;

public class PulmonaryFunctionTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
