package Pulmonology;

public class Pulmonologist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
