package Pulmonology;

public class VentilatorSupport {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
