package Orthopedics;

public class BoneFractureCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
