package Orthopedics;

public class JointReplacement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
