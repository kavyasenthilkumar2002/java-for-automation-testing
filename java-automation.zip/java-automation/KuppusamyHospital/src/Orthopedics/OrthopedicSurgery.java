package Orthopedics;

public class OrthopedicSurgery {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
