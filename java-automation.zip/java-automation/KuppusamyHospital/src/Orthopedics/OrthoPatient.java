package Orthopedics;

public class OrthoPatient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
