package Emergency;

public class EmergencyCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
