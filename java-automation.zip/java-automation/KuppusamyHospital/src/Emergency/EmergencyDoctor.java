package Emergency;

public class EmergencyDoctor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
