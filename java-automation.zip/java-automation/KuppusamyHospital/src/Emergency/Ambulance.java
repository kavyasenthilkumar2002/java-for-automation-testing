package Emergency;

public class Ambulance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
