package Emergency;

public class EmergencyTriage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
