package Gastroenterology;

public class GastroSurgery {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
