package Gastroenterology;

public class Gastroenterologist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
