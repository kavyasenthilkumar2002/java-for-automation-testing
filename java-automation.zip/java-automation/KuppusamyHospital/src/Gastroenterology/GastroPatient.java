package Gastroenterology;

public class GastroPatient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
