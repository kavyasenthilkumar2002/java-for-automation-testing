package Gastroenterology;

public class EndoscopyReport {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
