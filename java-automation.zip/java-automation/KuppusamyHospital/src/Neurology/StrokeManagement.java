package Neurology;

public class StrokeManagement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
