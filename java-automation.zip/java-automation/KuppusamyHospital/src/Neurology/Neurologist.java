package Neurology;

public class Neurologist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
