package Neurology;

public class NeuroSurgery {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
