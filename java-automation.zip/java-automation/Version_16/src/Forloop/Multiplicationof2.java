package Forloop;

public class Multiplicationof2 {

	void multiplication()
	{
		for( int i=1;i<=10;i++)
		{
			
		System.out.println(2 + "x" + i + "=" + (i*2));
							
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Multiplicationof2 a=new Multiplicationof2();
		a.multiplication();

	
	}
	}
