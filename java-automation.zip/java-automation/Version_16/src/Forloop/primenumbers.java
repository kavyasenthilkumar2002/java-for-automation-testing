package Forloop;
public class primenumbers {

    static {
        System.out.println("Prime numbers:");
    }

    void primenumber()
    {
    	for (int i = 1; i <= 101; i++) {
            boolean isPrimenumber = true;

            for (int j = 2; j <= i / 2; j++) { 
                if (i % j == 0) {
                	isPrimenumber = false;
                    break;
                }
            }

            if (isPrimenumber) {
                System.out.println(i);
            }
        } 	
    }
    public static void main(String[] args) {

    	primenumbers a=new primenumbers();
    	a.primenumber();
    }
}

