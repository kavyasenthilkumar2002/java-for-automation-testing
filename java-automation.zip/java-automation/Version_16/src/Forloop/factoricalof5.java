package Forloop;
public class factoricalof5 {

	void sum()
	{
		int num=1; 
    	for (int i = 2; i <= 5; i++)
    	{
    		num=num*i;
    		System.out.println(num);
    	}
	}
	    public static void main(String[] args)
	    {
	    	factoricalof5 a = new factoricalof5();
	    	a.sum();
	    }
	}