package Forloop;

public class findtheduplicatecharactersinstring {

	void duplicatestring()
	{
		 String s = "Programming";
	        char[] a = s.toCharArray();

	        for (int i = 0; i < a.length; i++) {
	            for (int j = i + 1; j < a.length; j++) {
	                if (a[i] == a[j]) {
	                    System.out.println(a[i]);
	                    break; 
	                }
	            }
	        }	
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		findtheduplicatecharactersinstring a=new findtheduplicatecharactersinstring();
		a.duplicatestring();
	    }
	}

