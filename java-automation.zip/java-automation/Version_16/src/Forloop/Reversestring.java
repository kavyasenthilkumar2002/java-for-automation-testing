package Forloop;
public class Reversestring {

void string()
	{
	 String OldStr = "Java";
	    String NewStr = "";
	    System.out.println("Old string: " + OldStr);
	        
	    for (int i = 0; i < OldStr.length(); i++) {
	    	NewStr = OldStr.charAt(i) + NewStr;
	    }
	    
	    System.out.println("New string: "+ NewStr);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Reversestring a=new Reversestring();
		a.string();
				
	
	}

}
