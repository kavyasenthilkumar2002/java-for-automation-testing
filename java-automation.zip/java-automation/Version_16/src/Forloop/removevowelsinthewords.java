package Forloop;

public class removevowelsinthewords {

void string()
{
	 String s = "prepinsta";
     String s1 = "";
     s1 = s.replaceAll("[aeiou]", ""); 
     System.out.println("String after removing vowel : "+s1); 
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		removevowelsinthewords a = new removevowelsinthewords();
				a.string();
	
	}

}
