package Forloop;
public class evennumber {

	void math()
	{

			for(int i=1;i<=100;i++)
			{  
				if(i%2==0)
				{
					System.out.println(i);
				}
			
			}		
			}
			public static void main(String[] args) {
				// TODO Auto-generated method stub
				
				evennumber a=new evennumber();
				a.math();
										
		}
	}