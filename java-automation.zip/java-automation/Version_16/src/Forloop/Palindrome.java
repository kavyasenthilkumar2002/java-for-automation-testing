package Forloop;
public class Palindrome {
	
	void palindrome()
	{
		String a = "Level";
        String rev = "";

     
        for (int i = a.length() - 1; i >= 0; i--) {
            rev = rev + a.charAt(i);
        }

          if (a.equals(rev)) {
        	  System.out.println(a + " is a palindrome string");
        } 
          else {
            System.out.println(a + " is not a palindrome string");
        }	
	}
    public static void main(String[] args) {
    
    	Palindrome a = new Palindrome();
    	a.palindrome();
    
    }
}
