package Forloop;
public class counts {
	
	void count()
	{
	for( int i=1; i<11;i++)
	{
		System.out.println(i);
	}
	}
public static void main(String[] args) {
			// TODO Auto-generated method stub
				
	counts a=new counts();
	a.count();
			
		}

	}

