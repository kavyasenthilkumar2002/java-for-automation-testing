package Women;

public class BeautyProducts {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		    String productType= "Face Wash, Lipstick, Shampoo";
		    String brand="Lakme, Mamaearth";
		    String skinType="Oily, Dry, Sensitive, All Skin Types";
		    boolean isOrganic= false; 
		    String ingredients="Aloe Vera, Vitamin C";
		    String usageInstructions="Apply to wet face, rinse off";
		    String gender=" Unisex, Women, Men";
		    String countryOfOrigin="India";
		}

	    		 
	}

