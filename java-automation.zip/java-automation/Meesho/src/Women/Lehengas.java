package Women;

public class Lehengas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		   String fabric1="Cotton";
		   String color1="Blue";
		   String occasion1="Wedding";
		   String pattern1="Floral,";
		   
		   String fabric2="Silk";
		   String color2="Red";
		   String occasion2="Wedding";
		   String pattern2="Floral";
		   
		   String fabric3="Georgette";
		   String color3="Green";
		   String occasion3="Festive";
		   String pattern3="Checked";
	}

}
