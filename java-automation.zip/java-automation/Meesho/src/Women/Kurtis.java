package Women;

public class Kurtis {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 String fabricType1 = "Cotton";
		 String size1= "S";
		 String color1="Blue";
		 boolean Dupatta1= false;
		 boolean Set1 = false;
		 
		 String fabricType2 = "Rayon, Georgette";
		 String size2= " M";
		 String color2=" Red";
		 boolean hasDupatta2= false;
		 boolean isSet2 = true;
		 
		 String fabricType3 = "Georgette";
		 String size3= "XL";
		 String color3="Mustard";
		 boolean hasDupatta3= false;
		 boolean isSet3 = false;
	}

}
