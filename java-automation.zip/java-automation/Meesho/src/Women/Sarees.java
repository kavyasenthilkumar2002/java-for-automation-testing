package Women;

public class Sarees {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	    String fabric="Net";
	    String color="Red";
	    String size="S";
	    String occasion="Wedding";

	    String fabric1=" Silk";
	    String color1="Green";
	    String size1="M";
	    String occasion1="Party";
	    
	    String fabric2="Georgette";
	    String color2="blue";
	    String size2="L";
	    String occasion2="Festive";
	}

}
