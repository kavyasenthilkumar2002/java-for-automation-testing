package Women;

public class WomenBags {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		    String bagType1 = "Handbag";
		    String bagType2 = "Sling Bag";
		    String bagType3 = "Tote";
		    String bagType4 = "Clutch";
		    String bagType5 = "Backpack";

		    String material1 = "PU Leather";
		    String material2 = "Canvas";
		    String material3 = "Cotton";
		    String material4 = "Nylon";
		    String material5 = "Jute";

		    String color1 = "Black";
		    String color2 = "Brown";
		    String color3 = "Beige";
		    String color4 = "Pink";
		    String color5 = "Blue";

		    String size1 = "Small";
		    String size2 = "Medium";
		    String size3 = "Large";

		    String strapType1 = "Adjustable";
		    String strapType2 = "Chain Strap";
		    String strapType3 = "Double Handle";
		    String strapType4 = "Single Handle";

		    String occasion1 = "Casual";
		    String occasion2 = "Party";
		    String occasion3 = "Office";
		    String occasion4 = "Travel";
		   
		}

	}


