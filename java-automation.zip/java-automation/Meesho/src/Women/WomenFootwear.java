package Women;

public class WomenFootwear {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		    String footwearType1 = "Heels";
		    String footwearType2 = "Flats";
		    String footwearType3 = "Sneakers";
		    String footwearType4 = "Sandals";
		    String footwearType5 = "Juttis";
		    String footwearType6 = "Loafers";

		    String color1 = "Black";
		    String color2 = "White";
		    String color3 = "Red";
		    String color4 = "Beige";
		    String color5 = "Blue";

		    String occasion1 = "Casual";
		    String occasion2 = "Party";
		    String occasion3 = "Office";
		    String occasion4 = "Ethnic";
		    String occasion5 = "Daily Wear";

		    String closureType1 = "Slip-On";
		    String closureType2 = "Buckle";
		    String closureType3 = "Lace-Up";
		    String closureType4 = "Velcro";

		    String heelType1 = "Flat";
		    String heelType2 = "Block Heel";
		    String heelType3 = "Wedge Heel";
		    String heelType4 = "Kitten Heel";
		    String heelType5 = "Platform Heel";
		  
		    String soleType1 = "Rubber";
		    String soleType2 = "TPR";
		    String soleType3 = "PVC";
		    String soleType4 = "Leather";

		  
		    String countryOfOrigin = "India";
		}

	}


