package Electronics;

public class MobileAccessories {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String accessoryType1 = "Pop Socket";
		String accessoryType2 = "Phone Cover";
		String accessoryType3 = "Screen Guard";
		String compatibility1 = "iPhone";
		String compatibility2 = "Samsung";

	}

}
