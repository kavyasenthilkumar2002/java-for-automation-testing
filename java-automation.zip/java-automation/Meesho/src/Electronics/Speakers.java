package Electronics;

public class Speakers {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	String type1 = "Bluetooth Speaker";
	String type2 = "Wired Speaker";
	String brand1 = "JBL";
	String brand2 = "Zebronics";
	String battery1 = "6 Hours";
	String battery2 = "12 Hours";

}
}
