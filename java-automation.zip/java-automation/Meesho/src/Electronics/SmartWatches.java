package Electronics;

public class SmartWatches {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	String brand1 = "Noise";
	String brand2 = "boAt";
	String feature1 = "Heart Rate Monitor";
	String feature2 = "Sleep Tracker";
	String display1 = "AMOLED";
	String color1 = "Black";
	String strapType1 = "Silicone";

	}
}
