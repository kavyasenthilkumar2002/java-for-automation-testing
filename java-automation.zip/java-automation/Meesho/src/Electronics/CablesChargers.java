package Electronics;

public class CablesChargers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String type1 = "USB Type-C";
		String type2 = "Micro USB";
		String type3 = "Lightning";
		String usage1 = "Mobile Charging";
		String usage2 = "Laptop Charging";
		String length1 = "1 Meter";
		String length2 = "2 Meter";
		String compatibility1 = "Android";
		String compatibility2 = "iOS";

	}

}
