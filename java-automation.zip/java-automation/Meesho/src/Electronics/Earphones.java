package Electronics;

public class Earphones {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	String type1 = "Wired";
	String type2 = "Wireless";
	String brand1 = "boAt";
	String brand2 = "Realme";
	String color1 = "Black";
	String color2 = "White";
	String connector1 = "3.5mm Jack";
	String connector2 = "Bluetooth";
	
	}
		}