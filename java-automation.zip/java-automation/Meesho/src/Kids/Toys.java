package Kids;

public class Toys {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String toyType1 = "Puzzle";
		String toyType2 = "Soft Toy";
		String ageGroup1 = "3+";

	}

}
