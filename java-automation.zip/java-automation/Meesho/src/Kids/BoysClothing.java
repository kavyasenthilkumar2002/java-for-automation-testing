package Kids;

public class BoysClothing {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		String item1 = "T-Shirt";
		String item2 = "Shorts";
		String size1 = "1-2 Years";
		String color1 = "Blue";

		
	}
}
