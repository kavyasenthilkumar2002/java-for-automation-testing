package Kids;

public class GirlsClothing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String item1 = "Frock";
		String item2 = "Leggings";
		String size1 = "2-3 Years";
		String color1 = "Pink";

	}
	

}
