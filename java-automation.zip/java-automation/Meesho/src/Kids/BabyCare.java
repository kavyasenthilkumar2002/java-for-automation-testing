package Kids;

public class BabyCare {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	String product1 = "Baby Lotion";
	String product2 = "Diapers";
	String brand1 = "Pampers";
	String ageGroup1 = "0-6 Months";

}
}