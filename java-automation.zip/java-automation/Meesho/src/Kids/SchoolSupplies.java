package Kids;

public class SchoolSupplies {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		String supply1 = "School Bag";
		String supply2 = "Lunch Box";
		String brand1 = "Wildcraft";

	}

}
