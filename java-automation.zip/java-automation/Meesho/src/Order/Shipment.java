package Order;

public class Shipment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String carrier1 = "Delhivery";
		String carrier2 = "Blue Dart";
		String carrier3 = "Ecom Express";
		String trackingStatus1 = "Out for Delivery";
		String trackingStatus2 = "Delivered";
		String trackingStatus3 = "Delayed";

	}

}
