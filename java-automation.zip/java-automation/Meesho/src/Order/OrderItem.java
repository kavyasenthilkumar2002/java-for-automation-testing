package Order;

public class OrderItem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		String itemStatus1 = "Packed";
		String itemStatus2 = "In Transit";
		String itemStatus3 = "Delivered";

	}
}

