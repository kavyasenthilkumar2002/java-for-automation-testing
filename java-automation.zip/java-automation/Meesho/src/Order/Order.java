package Order;

public class Order {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String orderStatus1 = "Pending";
		String orderStatus2 = "Shipped";
		String orderStatus3 = "Delivered";
		String orderStatus4 = "Cancelled";

	}

}
