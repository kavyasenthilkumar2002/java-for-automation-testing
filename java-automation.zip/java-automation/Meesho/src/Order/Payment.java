package Order;

public class Payment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String method1 = "Credit Card";
		String method2 = "UPI";
		String method3 = "Cash on Delivery";
		String paymentStatus1 = "Paid";
		String paymentStatus2 = "Failed";

	}

}
