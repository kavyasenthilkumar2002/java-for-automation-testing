package Order;

public class ReturnRequest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String reason1 = "Damaged Product";
		String reason2 = "Wrong Item Delivered";
		String reason3 = "Size Issue";
		String status1 = "Pending";
		String status2 = "Approved";
		String status3 = "Rejected";

	}

}
