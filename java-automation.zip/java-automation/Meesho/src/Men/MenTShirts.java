package Men;

public class MenTShirts {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String neck1 = "Round Neck";
		String sleeve1 = "Half Sleeve";
		String print1 = "Graphic Print";
		String color1 = "Navy Blue";
		String size1 = "M";

	}

}
