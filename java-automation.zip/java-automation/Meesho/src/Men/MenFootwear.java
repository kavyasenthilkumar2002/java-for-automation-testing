package Men;

public class MenFootwear {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String type1 = "Loafers";
		String type2 = "Sandals";
		String type3 = "Sneakers";
		String color1 = "Black";
		String size1 = "UK 8";
		String sole1 = "Rubber";

	}

}
