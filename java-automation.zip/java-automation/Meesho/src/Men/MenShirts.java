package Men;

public class MenShirts {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String sleeve1 = "Full Sleeve";
		String pattern1 = "Checked";
		String collarType1 = "Spread Collar";
		String size1 = "L";
		String fabric1 = "Cotton Blend";

	}

}
