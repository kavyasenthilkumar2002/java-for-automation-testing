package Men;

public class MenEthnicWear {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String item1 = "Kurta";
		String item2 = "Sherwani";
		String fabric1 = "Cotton";
		String color1 = "Maroon";
		String size1 = "M";
		String occasion1 = "Festive";

	}

}
