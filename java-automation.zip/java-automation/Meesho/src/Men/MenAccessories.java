package Men;

public class MenAccessories {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String accessory1 = "Belt";
		String accessory2 = "Wallet";
		String accessory3 = "Sunglasses";
		String color1 = "Black";
		String color2 = "Brown";
		String material1 = "Leather";
		String brand1 = "WildHorn";

	}

}
