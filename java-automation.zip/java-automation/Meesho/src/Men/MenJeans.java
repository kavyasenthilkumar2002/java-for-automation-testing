package Men;

public class MenJeans {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String fitType1 = "Slim Fit";
		String fitType2 = "Regular Fit";
		String washType1 = "Stone Wash";
		String size1 = "32";
		String color1 = "Blue";

	}

}
