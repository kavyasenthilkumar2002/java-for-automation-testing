package Home_kitchen;

public class CleaningSupplies {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String product1 = "Floor Cleaner";
		String product2 = "Toilet Cleaner";
		String brand1 = "Harpic";
		String brand2 = "Lizol";
		String size1 = "500ml";

	}

}
