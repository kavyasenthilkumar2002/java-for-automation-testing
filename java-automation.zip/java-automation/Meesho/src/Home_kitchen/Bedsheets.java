package Home_kitchen;

public class Bedsheets {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	String fabric1 = "Cotton";
	String fabric2 = "Polyester";
	String size1 = "Single";
	String size2 = "Double";
	String print1 = "Floral";
	String print2 = "Geometric";

}
}
