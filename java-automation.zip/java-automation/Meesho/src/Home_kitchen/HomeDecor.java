package Home_kitchen;

public class HomeDecor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String decorType1 = "Wall Hanging";
		String decorType2 = "Table Decor";
		String material1 = "Wood";
		String style1 = "Boho";

	}

}
