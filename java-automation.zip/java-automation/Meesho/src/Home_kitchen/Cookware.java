package Home_kitchen;

public class Cookware {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String type1 = "Non-Stick Pan";
		String type2 = "Pressure Cooker";
		String material1 = "Aluminium";
		String material2 = "Steel";

	}

}
