package Home_kitchen;

public class KitchenStorage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	String storageType1 = "Spice Jar";
	String storageType2 = "Container Set";
	String material1 = "Plastic";
	String size1 = "1L";

}
}