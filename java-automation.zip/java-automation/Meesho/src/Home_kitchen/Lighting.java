package Home_kitchen;

public class Lighting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String type1 = "LED Bulb";
		String type2 = "Fairy Lights";
		String color1 = "Warm White";
		String color2 = "Cool White";

	}

}
