package Marketing;

public class Referral {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String reward1 = "₹100 Wallet Cash";
		String condition1 = "On First Order";
		String limit1 = "5 Referrals";


	}

}
