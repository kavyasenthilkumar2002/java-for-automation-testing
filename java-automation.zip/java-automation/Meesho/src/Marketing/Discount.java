package Marketing;

public class Discount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String type1 = "Percentage";
		String type2 = "Flat";
		String applicableOn1 = "Electronics";
		String applicableOn2 = "Clothing";

	}

}
