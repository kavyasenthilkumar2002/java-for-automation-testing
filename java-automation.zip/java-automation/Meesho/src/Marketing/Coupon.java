package Marketing;

public class Coupon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String couponCode1 = "SAVE50";
		String type1 = "Flat Discount";
		String usage1 = "Once per User";

	}

}
