package Marketing;

public class FlashSale {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String saleName1 = "Mega Monday";
		String timing1 = "12PM - 6PM";
		String discount1 = "60% Off";

	}

}
