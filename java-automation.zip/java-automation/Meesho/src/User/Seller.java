package User;

public class Seller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String businessType1 = "Individual";
		String businessType2 = "Private Ltd";
		String businessType3 = "Partnership";

		String gstStatus1 = "Registered";
		String gstStatus2 = "Unregistered";

		String sellerStatus1 = "Verified";
		String sellerStatus2 = "Pending Verification";
		String sellerStatus3 = "Suspended";

	}

}
