package User;

public class Address {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String city1 = "Chennai";
		String city2 = "Bangalore";
		String city3 = "Mumbai";

		String state1 = "Tamil Nadu";
		String state2 = "Karnataka";
		String state3 = "Maharashtra";

		String country1 = "India";

		String addressType1 = "Home";
		String addressType2 = "Office";
		String addressType3 = "Other";

		String pinCode1 = "600001";
		String pinCode2 = "560001";
		String pinCode3 = "400001";

	}

}
