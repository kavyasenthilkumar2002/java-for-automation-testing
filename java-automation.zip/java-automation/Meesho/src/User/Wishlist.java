package User;

public class Wishlist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	String wishlistType1 = "Personal";
	String wishlistType2 = "Gift";
	String visibility1 = "Private";
	String visibility2 = "Public";
	
	}
}
