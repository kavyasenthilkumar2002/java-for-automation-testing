package User;

public class Customer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	String gender1 = "Female";
	String gender2 = "Male";
	String gender3 = "Other";

	String membership1 = "Basic";
	String membership2 = "Premium";

	String status1 = "Active";
	String status2 = "Blocked";
	
	}
}
