package User;

public class Cart {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	String cartStatus1 = "Active";
	String cartStatus2 = "Checked Out";
	String cartStatus3 = "Abandoned";

	String paymentMode1 = "COD";
	String paymentMode2 = "UPI";
	String paymentMode3 = "Card";
	}
}
