package Product;

public class Product {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String category1 = "Women";
		String category2 = "Men";
		String category3 = "Electronics";
		String availability1 = "In Stock";
		String availability2 = "Out of Stock";
	}

}
