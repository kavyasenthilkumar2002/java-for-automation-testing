package Product;

public class ProductSpecification {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	String specKey1 = "Material";
	String specKey2 = "Dimensions";
	String specKey3 = "Weight";
	String specKey4 = "Color";
	}
}
