package Product;

public class ProductVariant {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String variantType1 = "Color";
		String variantType2 = "Size";
		String variantType3 = "Quantity Pack";

	}

}
