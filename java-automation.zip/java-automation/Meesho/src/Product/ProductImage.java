package Product;

public class ProductImage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String resolution1 = "600x600";
		String resolution2 = "1200x1200";
		String format1 = "JPG";
		String format2 = "PNG";

	}

}
