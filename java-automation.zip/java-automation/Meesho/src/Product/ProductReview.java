package Product;

public class ProductReview {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String rating1 = "1 Star";
		String rating2 = "2 Stars";
		String rating3 = "3 Stars";
		String rating4 = "4 Stars";
		String rating5 = "5 Stars";
		String reviewStatus1 = "Approved";
		String reviewStatus2 = "Pending";

	}

}
