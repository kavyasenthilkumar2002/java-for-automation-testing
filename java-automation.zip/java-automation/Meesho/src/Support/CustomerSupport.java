package Support;

public class CustomerSupport {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	String queryType1 = "Order Issue";
	String queryType2 = "Payment Issue";
	String queryType3 = "Product Query";
	String status1 = "Open";
	String status2 = "Resolved";

}
}
