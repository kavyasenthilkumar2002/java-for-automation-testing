package Support;

public class ReturnPolicy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String returnWindow1 = "7 Days";
		String returnWindow2 = "15 Days";
		String condition1 = "Unopened Only";
		String condition2 = "With Original Tags";

	}

}
