package Support;

public class Ticket {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	String ticketType1 = "Complaint";
	String ticketType2 = "Suggestion";
	String priority1 = "Low";
	String priority2 = "Medium";
	String priority3 = "High";
	}
}
