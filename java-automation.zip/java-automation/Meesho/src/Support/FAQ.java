package Support;

public class FAQ {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	String category1 = "Shipping";
	String category2 = "Returns";
	String category3 = "Payment";
	String visibility1 = "Public";
	}
}
