package Nestedloop;

public class weekdays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//  outerloop
		for(int i= 1;i<3;i++)
		{ //scope 
			System.out.println( "week " + i);

					//  innerloop
				
			for	(int j=1;j<8;j++)
			{	//scope
				
			
				System.out.println( "day " + j);
				
								
			}
			
		
		//scope
			
			
		}
		
	}
}