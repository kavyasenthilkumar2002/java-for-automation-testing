package Nestedloop;

public class star {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//  outerloop
		
		for(int i= 1;i<=6;i++)
		{ 
			//scope 
		   //  innerloop
				
			for	(int j=1;j<=i;j++)
			{	
				//scope
			
				System.out.print("*");
			
			}
			
		//scope
			
			System.out.println();
		}
		
	}
}
