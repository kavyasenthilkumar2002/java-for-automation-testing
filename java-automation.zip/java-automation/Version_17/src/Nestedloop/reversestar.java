package Nestedloop;
public class reversestar {

	void reversestars()
	{
	//  outerloop
			for(int i= 6;i>1;i--)
			{ //scope 
				 
							
				//  innerloop
					
				for	(int j=1;j<i;j++)
				{	//scope
					
				
					System.out.print( "*" );
						
				}
				
					//scope
				
				System.out.println( );
			}
			
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		reversestar a= new reversestar();
		a.reversestars();
				
	}
}