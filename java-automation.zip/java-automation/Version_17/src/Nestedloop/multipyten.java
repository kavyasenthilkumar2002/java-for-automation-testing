package Nestedloop;
public class multipyten {

	void multiply()
	{
	//  outerloop
				for(int i=1;i<11;i++)
				{ //scope 
		
					
					//  innerloop
						
					for	(int j=1;j<11;j++)
					{	//scope
						
						System.out.println(i + "x" + j + "=" +(i*j) );
					
						
					}
					
				
				//scope
						
				}	
	}

		public static void main(String[] args) {
			// TODO Auto-generated method stub

			multipyten a=new multipyten();
			a.multiply();
		}
	}