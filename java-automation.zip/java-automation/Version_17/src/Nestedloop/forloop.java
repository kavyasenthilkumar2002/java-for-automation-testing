package Nestedloop;
public class forloop {

	void Forloop()
	{
	//  outerloop
			for(int i=0;i<3;i++)
			{ //scope 
				
				//System.out.println("value of i is " + i);
				//System.out.println("");
				
				//  innerloop
				for(int j=0;j<3;j++)	
				{	//scope
					//System.out.println("value of i is " + i);
					System.out.println("J value is " + j);
					
				}
			
			//scope
						System.out.println("value of i is " + i);
				System.out.println("");
			}
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		forloop a=new forloop();
		a.Forloop();
	}
}
































