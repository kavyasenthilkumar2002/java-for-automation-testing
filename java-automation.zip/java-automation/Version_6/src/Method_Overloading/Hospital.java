package Method_Overloading;

public class Hospital {


	    void login(String username, String password) {
	        System.out.println("Username: " + username);
	        System.out.println("Password: " + password);
	    }

	    void login1(long phoneNumber, int OTP) {
	        System.out.println("Phone number: " + phoneNumber);
	        System.out.println("OTP: " + OTP);
	    }

	    public static void main(String[] args) {
	    	Hospital hospital = new Hospital();
	        hospital.login("DoctorK", "med123");
	        hospital.login1(9445566778L, 789123);
	    }
	}
