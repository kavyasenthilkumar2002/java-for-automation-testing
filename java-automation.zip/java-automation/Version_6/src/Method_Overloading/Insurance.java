package Method_Overloading;

public class Insurance {

    void login(String username, String password) {
        System.out.println("Username: " + username);
        System.out.println("Password: " + password);
    }

    void login1(int phoneNumber, int OTP) {
        System.out.println("Phone number: " + phoneNumber);
        System.out.println("OTP: " + OTP);
    }

    public static void main(String[] args) {
        Insurance insurance = new Insurance();
        insurance.login("Priya", "insure456");
        insurance.login1(987651234, 654321);
    }
}
