package Method_Overloading;

public class Bank {

	    void login(String username, String password) {
	        System.out.println("Username: " + username);
	        System.out.println("Password: " + password);
	    }

	    void login1(int phoneNumber, int OTP) {
	        System.out.println("Phone number: " + phoneNumber);
	        System.out.println("OTP: " + OTP);
	    }
	    public static void main(String[] args){
	        Bank bank = new Bank();
	        bank.login("Ravi", "bank123");
	        bank.login1(987654321, 456789);
	    }
	}

