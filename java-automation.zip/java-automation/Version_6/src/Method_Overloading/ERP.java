package Method_Overloading;

public class ERP {


	    void login(String username, String password) {
	        System.out.println("Username: " + username);
	        System.out.println("Password: " + password);
	    }

	    void login1(long phoneNumber, int OTP) {
	        System.out.println("Phone number: " + phoneNumber);
	        System.out.println("OTP: " + OTP);
	    }

	    public static void main(String[] args) {
	        ERP erp = new ERP();
	        erp.login("Manager", "erp789");
	        erp.login1(9001122334L, 123456);
	    }
	}


