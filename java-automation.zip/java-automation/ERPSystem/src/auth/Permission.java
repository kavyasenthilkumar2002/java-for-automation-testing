package auth;

public class Permission {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
