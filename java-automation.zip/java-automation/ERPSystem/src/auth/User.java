package auth;

public class User {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
