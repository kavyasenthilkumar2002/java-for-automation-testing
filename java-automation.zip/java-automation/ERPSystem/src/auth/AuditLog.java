package auth;

public class AuditLog {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
