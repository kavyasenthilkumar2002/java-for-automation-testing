package Inventory;

public class StockAdjustment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
