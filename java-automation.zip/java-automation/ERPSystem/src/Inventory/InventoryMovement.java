package Inventory;

public class InventoryMovement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
