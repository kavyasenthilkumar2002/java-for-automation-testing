package Projects;

public class TimeLog {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
