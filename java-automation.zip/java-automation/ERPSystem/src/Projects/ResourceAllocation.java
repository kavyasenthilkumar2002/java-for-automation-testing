package Projects;

public class ResourceAllocation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
