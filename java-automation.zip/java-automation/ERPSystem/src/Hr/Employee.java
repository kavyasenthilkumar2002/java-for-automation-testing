package Hr;

public class Employee {

}
