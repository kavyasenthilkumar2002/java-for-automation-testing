package Hr;

public class Payroll {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
