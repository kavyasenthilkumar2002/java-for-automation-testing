package Hr;

public class LeaveRequest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
