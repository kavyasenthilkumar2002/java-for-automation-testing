package Hr;

public class Recruitment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
