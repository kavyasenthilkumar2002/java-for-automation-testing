package Assets;

public class AssetDisposal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
