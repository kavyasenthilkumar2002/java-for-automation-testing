package Assets;

public class Depreciation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
