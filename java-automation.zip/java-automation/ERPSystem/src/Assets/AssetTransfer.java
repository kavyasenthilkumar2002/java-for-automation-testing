package Assets;

public class AssetTransfer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
