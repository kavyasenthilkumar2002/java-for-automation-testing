package Assets;

public class Asset {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
