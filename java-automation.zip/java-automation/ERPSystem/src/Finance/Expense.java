package Finance;

public class Expense {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
