package Finance;

public class Budget {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
