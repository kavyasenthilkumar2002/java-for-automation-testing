package Finance;

public class Ledger {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
