package Finance;

public class Tax {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
