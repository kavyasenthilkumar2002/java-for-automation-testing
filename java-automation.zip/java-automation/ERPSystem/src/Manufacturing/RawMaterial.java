package Manufacturing;

public class RawMaterial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
