package Manufacturing;

public class BillOfMaterials {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
