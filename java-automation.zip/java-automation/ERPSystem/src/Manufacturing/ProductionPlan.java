package Manufacturing;

public class ProductionPlan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
