
public class ERP {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		        // Assets
		        String assetName = "Dell Laptop";
		        String assetType = "Electronics";
		        boolean assetAssigned = true;
		        float assetValue = 75000.50f;
		        String assetCondition = "New";
		        String assetLocation = "Head Office";
		        boolean assetInsured = true;
		        String warrantyStatus = "Active";
		        String assetVendor = "Dell India";
		        System.out.println("Assets");
		        System.out.println("Asset Name: " + assetName);
		        System.out.println("Asset Type: " + assetType);
		        System.out.println("Assigned: " + assetAssigned);
		        System.out.println("Asset Value: " + assetValue);
		        System.out.println("Condition: " + assetCondition);
		        System.out.println("Location: " + assetLocation);
		        System.out.println("Insured: " + assetInsured);
		        System.out.println("Warranty Status: " + warrantyStatus);
		        System.out.println("Vendor: " + assetVendor);
		        System.out.println();

		        // Auth
		        String username = "admin_hr";
		        String role = "HR Manager";
		        boolean loginSuccess = true;
		        boolean twoFactorEnabled = true;
		        String accessLevel = "High";
		        String loginTime = "2025-07-29 09:00";
		        String lastPasswordChange = "2025-07-01";
		        boolean passwordExpired = false;
		        boolean sessionActive = true;
		        System.out.println("Auth");
		        System.out.println("Username: " + username);
		        System.out.println("Role: " + role);
		        System.out.println("Login Success: " + loginSuccess);
		        System.out.println("2FA Enabled: " + twoFactorEnabled);
		        System.out.println("Access Level: " + accessLevel);
		        System.out.println("Login Time: " + loginTime);
		        System.out.println("Last Password Change: " + lastPasswordChange);
		        System.out.println("Password Expired: " + passwordExpired);
		        System.out.println("Session Active: " + sessionActive);
		        System.out.println();

		        // Finance
		        float totalRevenue = 15500000.75f;
		        float totalExpenses = 9345000.35f;
		        float netProfit = totalRevenue - totalExpenses;
		        String fiscalYear = "2024-2025";
		        boolean auditCompleted = true;
		        String auditorName = "KPMG";
		        boolean gstFiled = true;
		        String gstNumber = "33ABCDE1234F1Z5";
		        boolean taxClearance = true;
		        System.out.println(" Finance ");
		        System.out.println("Total Revenue: " + totalRevenue);
		        System.out.println("Total Expenses: " + totalExpenses);
		        System.out.println("Net Profit: " + netProfit);
		        System.out.println("Fiscal Year: " + fiscalYear);
		        System.out.println("Audit Completed: " + auditCompleted);
		        System.out.println("Auditor: " + auditorName);
		        System.out.println("GST Filed: " + gstFiled);
		        System.out.println("GST Number: " + gstNumber);
		        System.out.println("Tax Clearance: " + taxClearance);
		        System.out.println();

		        // HR
		        String employeeName = "Nandhini";
		        int employeeId = 1001;
		        String department = "HR";
		        String designation = "Recruiter";
		        boolean isOnPayroll = true;
		        float salary = 48000.0f;
		        String joiningDate = "2023-05-12";
		        boolean onProbation = false;
		        boolean performanceBonusEligible = true;
		        System.out.println(" HR ");
		        System.out.println("Employee Name: " + employeeName);
		        System.out.println("Employee ID: " + employeeId);
		        System.out.println("Department: " + department);
		        System.out.println("Designation: " + designation);
		        System.out.println("On Payroll: " + isOnPayroll);
		        System.out.println("Salary: " + salary);
		        System.out.println("Joining Date: " + joiningDate);
		        System.out.println("On Probation: " + onProbation);
		        System.out.println("Performance Bonus Eligible: " + performanceBonusEligible);
		        System.out.println();

		        // Inventory
		        String itemName = "Printer Ink";
		        int itemStock = 320;
		        boolean itemAvailable = true;
		        String itemCategory = "Stationery";
		        float reorderLevel = 100.0f;
		        boolean reorderRequired = false;
		        String itemSupplier = "Canon India";
		        boolean perishable = false;
		        String itemLocation = "Warehouse A";
		        System.out.println(" Inventory ");
		        System.out.println("Item Name: " + itemName);
		        System.out.println("Stock: " + itemStock);
		        System.out.println("Available: " + itemAvailable);
		        System.out.println("Category: " + itemCategory);
		        System.out.println("Reorder Level: " + reorderLevel);
		        System.out.println("Reorder Required: " + reorderRequired);
		        System.out.println("Supplier: " + itemSupplier);
		        System.out.println("Perishable: " + perishable);
		        System.out.println("Location: " + itemLocation);
		        System.out.println();

		        // Manufacturing
		        String productLine = "Textiles";
		        boolean productionActive = true;
		        float productionCost = 250000.0f;
		        String batchCode = "BATCH202507";
		        boolean qualityChecked = true;
		        float defectRate = 1.5f;
		        String machineUsed = "StitchMaster 5000";
		        boolean automatedProcess = true;
		        String productionManager = "Dinesh";
		        System.out.println(" Manufacturing ");
		        System.out.println("Product Line: " + productLine);
		        System.out.println("Production Active: " + productionActive);
		        System.out.println("Production Cost: " + productionCost);
		        System.out.println("Batch Code: " + batchCode);
		        System.out.println("Quality Checked: " + qualityChecked);
		        System.out.println("Defect Rate: " + defectRate);
		        System.out.println("Machine Used: " + machineUsed);
		        System.out.println("Automated Process: " + automatedProcess);
		        System.out.println("Production Manager: " + productionManager);
		        System.out.println();

		        // Projects
		        String projectName = "ERP Revamp";
		        boolean projectApproved = true;
		        String projectManager = "Kavitha";
		        float projectBudget = 1200000.0f;
		        String projectStatus = "In Progress";
		        boolean milestoneOneCompleted = true;
		        String deadline = "2025-12-31";
		        boolean isExternalProject = false;
		        String clientName = "SmartTech Pvt Ltd";
		        System.out.println(" Projects");
		        System.out.println("Project Name: " + projectName);
		        System.out.println("Approved: " + projectApproved);
		        System.out.println("Project Manager: " + projectManager);
		        System.out.println("Budget: " + projectBudget);
		        System.out.println("Status: " + projectStatus);
		        System.out.println("Milestone 1 Completed: " + milestoneOneCompleted);
		        System.out.println("Deadline: " + deadline);
		        System.out.println("External Project: " + isExternalProject);
		        System.out.println("Client Name: " + clientName);
		        System.out.println();

		        // Purchase
		        String purchaseOrderNumber = "PO905432";
		        String purchaseVendor = "Amazon Business";
		        boolean orderConfirmed = true;
		        float orderAmount = 15499.75f;
		        boolean paymentCompleted = true;
		        String deliveryDate = "2025-08-02";
		        String paymentTerms = "Net 30";
		        boolean invoiceReceived = true;
		        String deliveryStatus = "Shipped";

		        System.out.println(" Purchase");
		        System.out.println("PO Number: " + purchaseOrderNumber);
		        System.out.println("Vendor: " + purchaseVendor);
		        System.out.println("Order Confirmed: " + orderConfirmed);
		        System.out.println("Order Amount: " + orderAmount);
		        System.out.println("Payment Completed: " + paymentCompleted);
		        System.out.println("Delivery Date: " + deliveryDate);
		        System.out.println("Payment Terms: " + paymentTerms);
		        System.out.println("Invoice Received: " + invoiceReceived);
		        System.out.println("Delivery Status: " + deliveryStatus);
		        System.out.println();

		        // Reports
		        String reportName = "Monthly Sales";
		        boolean reportGenerated = true;
		        String reportGeneratedBy = "Sales Admin";
		        String reportDate = "2025-07-29";
		        boolean reportShared = false;
		        String fileFormat = "PDF";
		        boolean dataVerified = true;
		        String reportStatus = "Final";
		        boolean reviewedByManager = true;
		        System.out.println(" Reports");
		        System.out.println("Report Name: " + reportName);
		        System.out.println("Generated: " + reportGenerated);
		        System.out.println("Generated By: " + reportGeneratedBy);
		        System.out.println("Date: " + reportDate);
		        System.out.println("Shared: " + reportShared);
		        System.out.println("Format: " + fileFormat);
		        System.out.println("Data Verified: " + dataVerified);
		        System.out.println("Status: " + reportStatus);
		        System.out.println("Reviewed by Manager: " + reviewedByManager);
		        System.out.println();

		        // Sales
		        String salesExecutive = "Ajith Kumar";
		        int salesCount = 48;
		        float salesTarget = 500000.0f;
		        float currentSales = 425000.0f;
		        boolean targetAchieved = false;
		        String region = "South India";
		        boolean incentivesApproved = true;
		        String leadSource = "Online Campaign";
		        boolean customerFeedbackCollected = true;
		        System.out.println(" Sales ");
		        System.out.println("Sales Executive: " + salesExecutive);
		        System.out.println("Sales Count: " + salesCount);
		        System.out.println("Sales Target: " + salesTarget);
		        System.out.println("Current Sales: " + currentSales);
		        System.out.println("Target Achieved: " + targetAchieved);
		        System.out.println("Region: " + region);
		        System.out.println("Incentives Approved: " + incentivesApproved);
		        System.out.println("Lead Source: " + leadSource);
		        System.out.println("Feedback Collected: " + customerFeedbackCollected);
		        System.out.println();
		    


		        
		}

		}


