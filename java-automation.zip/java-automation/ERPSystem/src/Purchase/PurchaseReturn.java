package Purchase;

public class PurchaseReturn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
