package Purchase;

public class PurchaseInvoice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
