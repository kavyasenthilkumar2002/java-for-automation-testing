package Sales;

public class SalesInvoice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
