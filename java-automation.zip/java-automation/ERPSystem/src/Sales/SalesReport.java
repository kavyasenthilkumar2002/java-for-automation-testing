package Sales;

public class SalesReport {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
