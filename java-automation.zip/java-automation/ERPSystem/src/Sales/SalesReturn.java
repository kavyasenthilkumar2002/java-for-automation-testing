package Sales;

public class SalesReturn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
