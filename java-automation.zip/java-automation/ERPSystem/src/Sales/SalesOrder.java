package Sales;

public class SalesOrder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
