package Inheritance_Bank;

	class CurrentAccount extends Bank {
	    double overdraftLimit;

	    // Constructor
	    CurrentAccount(String branchName, String managerName, double overdraftLimit) {
	        super(branchName, managerName);
	        this.overdraftLimit = overdraftLimit;
	    }

	    // Overriding method
	  
	    void showDetails() {
	        super.showDetails();
	        System.out.println("Account Type: Current, Overdraft Limit: " + this.overdraftLimit);
	    }
	    public static void main(String[] args) {
	        Bank b1 = new Bank("Coimbatore Main", "Mr.Senthil Kumar");
	        b1.showDetails();
	        b1.showDetails("Chennai");

	        SavingsAccount sa = new SavingsAccount("Coimbatore Branch", "Mrs. Priya", 50000);
	        sa.showDetails();

	        CurrentAccount ca = new CurrentAccount("Madurai Branch", "Mr. Raj", 100000);
	        ca.showDetails();

	        // Static method call
	        Bank.showTotalAccounts();
	    }
	}

