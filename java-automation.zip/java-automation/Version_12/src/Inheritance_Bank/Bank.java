package Inheritance_Bank;

public class Bank {

	    static int totalAccounts = 0; // static variable for all accounts
	    String branchName;
	    String managerName;

	    // Default constructor
	    Bank() {
	        this.branchName = "Indian Branch";
	        this.managerName = "Maarimuthu";
	        totalAccounts++;
	    }

	    // Parameterized constructor
	    Bank(String branchName, String managerName) {
	        this.branchName = branchName;
	        this.managerName = managerName;
	        totalAccounts++;
	    }

	    // Method to show bank details
	    void showDetails() {
	        System.out.println("Branch: " + branchName + ", Manager: " + managerName);
	    }

	    // Overloaded method
	    void showDetails(String city) {
	        System.out.println("Branch: " + branchName + ", Manager: " + managerName + ", City: " + city);
	    }

	    // Static method
	    static void showTotalAccounts() {
	        System.out.println("Total Accounts Created: " + totalAccounts);
	    }
	}


