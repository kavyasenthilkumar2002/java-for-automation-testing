package Inheritance_Bank;
class SavingsAccount extends Bank {

	double balance;

	    // Constructor using 'this' keyword
	    SavingsAccount(String branchName, String managerName, double balance) {
	        super(branchName, managerName); // calling parent constructor
	        this.balance = balance; // using this to refer current class variable
	    }

	    // Overriding method
	
	    void showDetails() {
	        super.showDetails(); // calling parent method
	        System.out.println("Account Type: Savings, Balance: " + this.balance);
	    }
	}
