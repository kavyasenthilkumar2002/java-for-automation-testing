package inheritance_ERP;

class HRmodule extends ERP {
    String payrollSystem;

    HRmodule(String companyName, String payrollSystem) {
        super(companyName);
        this.payrollSystem = payrollSystem;
    }

    @Override
    void addModule() {
        super.addModule();
        System.out.println("HR Module with Payroll System: " + this.payrollSystem);
    }
}
