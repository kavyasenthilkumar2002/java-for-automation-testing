package inheritance_ERP;

class ERP {
    static int totalModules = 0;
    String companyName;

    ERP(String companyName) {
        this.companyName = companyName;
    }

    void addModule() {
        totalModules++;
        System.out.println("Module added to " + this.companyName + " ERP System");
    }

    void addModule(String moduleName) { // Overloaded
        totalModules++;
        System.out.println("Module: " + moduleName + " added to " + this.companyName + " ERP System");
    }

    static void showModules() {
        System.out.println("Total Modules in ERP: " + totalModules);
    }
}