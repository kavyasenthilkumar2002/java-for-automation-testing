package inheritance_ERP;

class InventoryModule extends ERP {
    int stockCapacity;

    InventoryModule(String companyName, int stockCapacity) {
        super(companyName);
        this.stockCapacity = stockCapacity;
    }

    @Override
    void addModule() {
        super.addModule();
        System.out.println("Inventory Capacity: " + this.stockCapacity + " items");
    }

    public static void main(String[] args) {
        HRmodule hr = new HRmodule("SAP ERP", "Automatic Payroll");
        hr.addModule("HR");

        InventoryModule inv = new InventoryModule("SAP ERP", 5000);
        inv.addModule();

        ERP.showModules();
    }
}