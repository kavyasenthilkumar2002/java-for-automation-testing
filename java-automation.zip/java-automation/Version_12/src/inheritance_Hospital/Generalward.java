package inheritance_Hospital;

class Generalward extends Hospital {
    int bedNo;

    Generalward(String hospitalName, int bedNo) {
        super(hospitalName);
        this.bedNo = bedNo;
    }

    @Override
    void admitPatient() {
        super.admitPatient();
        System.out.println("Admitted to General Ward, Bed No: " + this.bedNo);
    }
}
