package inheritance_Hospital;
class Hospital {
    static int totalPatients = 0;
    String hospitalName;

    Hospital(String hospitalName) {
        this.hospitalName = hospitalName;
    }

    void admitPatient() {
        totalPatients++;
        System.out.println("Patient admitted in " + this.hospitalName);
    }

    void admitPatient(String patientName) {  // Overloading
        totalPatients++;
        System.out.println("Patient " + patientName + " admitted in " + this.hospitalName);
    }

    static void showTotalPatients() {
        System.out.println("Total Patients: " + totalPatients);
    }
}