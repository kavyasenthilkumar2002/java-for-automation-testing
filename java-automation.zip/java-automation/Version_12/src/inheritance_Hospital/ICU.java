package inheritance_Hospital;
class ICU extends Hospital {
    String ventilatorSupport;

    ICU(String hospitalName, String ventilatorSupport) {
        super(hospitalName);
        this.ventilatorSupport = ventilatorSupport;
    }

    @Override
    void admitPatient() {
        super.admitPatient();
        System.out.println("Admitted to ICU, Ventilator Support: " + this.ventilatorSupport);
    }

    public static void main(String[] args) {
        Generalward g = new Generalward("Kuppusamy Hospital", 12);
        g.admitPatient("Ravi");

        ICU icu = new ICU("Kuppusamy Hospital", "Available");
        icu.admitPatient();

        Hospital.showTotalPatients();
    }
}
