package Inheritance_ecommerce;

class FashionStore extends ecommerce {
    String category;

    FashionStore(String sellerName, String category) {
        super(sellerName);
        this.category = category;
    }

    @Override
    void orderPlaced() {
        super.orderPlaced();
        System.out.println("Category: " + this.category);
    }
}