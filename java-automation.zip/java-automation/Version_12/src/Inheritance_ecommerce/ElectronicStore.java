package Inheritance_ecommerce;

class ElectronicsStore extends ecommerce {
    String warranty;

    ElectronicsStore(String sellerName, String warranty) {
        super(sellerName);
        this.warranty = warranty;
    }

    void orderPlaced() {
        super.orderPlaced();
        System.out.println("Warranty: " + this.warranty);
    }


    public static void main(String[] args) {
        FashionStore f = new FashionStore("Meesho Fashion", "Clothing");
        f.orderPlaced("Kurti");

        ElectronicsStore e = new ElectronicsStore("Meesho Electronics", "1 Year");
        e.orderPlaced();

        ecommerce.showTotalOrders();
    }
}