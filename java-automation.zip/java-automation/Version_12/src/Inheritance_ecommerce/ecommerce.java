package Inheritance_ecommerce;

public class ecommerce {
	
	    static int totalOrders = 0;
	    String sellerName;

	    // Constructor
	    ecommerce(String sellerName2) {
	     this.sellerName = sellerName;
		}

		
	    void orderPlaced() {
	        totalOrders++;
	        System.out.println("Order placed by seller: " + this.sellerName);
	    }

	    void orderPlaced(String productName) {  // Overloaded method
	        totalOrders++;
	        System.out.println("Product " + productName + " ordered from seller: " + this.sellerName);
	    }

	    static void showTotalOrders() {
	        System.out.println("Total Orders: " + totalOrders);
	    }
}
