package inheritance_Insurance;

class HealthInsurance extends Insurance {
    int coverageAmount;

    HealthInsurance(String company, int coverageAmount) {
        super(company);
        this.coverageAmount = coverageAmount;
    }

    @Override
    void buyPolicy() {
        super.buyPolicy();
        System.out.println("Health Coverage: ₹" + this.coverageAmount);
    }
}
