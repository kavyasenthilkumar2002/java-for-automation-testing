package inheritance_Insurance;

public class Insurance {

	    static int totalPolicies = 0;
	    String company;

	    Insurance(String company) {
	        this.company = company;
	    }

	    void buyPolicy() {
	        totalPolicies++;
	        System.out.println("Policy purchased from " + this.company);
	    }

	    void buyPolicy(String policyName) { // Overloaded
	        totalPolicies++;
	        System.out.println(policyName + " Policy purchased from " + this.company);
	    }

	    static void showTotalPolicies() {
	        System.out.println("Total Policies Sold: " + totalPolicies);
	    }
	}