package inheritance_Insurance;

class VehicleInsurance extends Insurance {
    String vehicleType;

    VehicleInsurance(String company, String vehicleType) {
        super(company);
        this.vehicleType = vehicleType;
    }

    @Override
    void buyPolicy() {
        super.buyPolicy();
        System.out.println("Vehicle Insured: " + this.vehicleType);
    }

    public static void main(String[] args) {
        HealthInsurance h = new HealthInsurance("Acko Insurance", 500000);
        h.buyPolicy("Health Plus");

        VehicleInsurance v = new VehicleInsurance("Acko Insurance", "Car");
        v.buyPolicy();

        Insurance.showTotalPolicies();
    }
}