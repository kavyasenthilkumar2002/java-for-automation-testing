package M_O_L_G_DC_parameterized;

public class Hospital {

	    // Global variable
	    String hospitalName = "Kuppuswamy Hospital";

	    // Default constructor
	    Hospital() {
	        System.out.println("=== Welcome to " + hospitalName + " ===");
	    }

	    // Parameterized constructor
	    Hospital(String departmentName) {
	        System.out.println("Department: " + departmentName);
	    }

	    void hospital_adminInfo() {
	        // Local variable
	        String adminName = "Dr. Arjun";
	        System.out.println("Hospital: " + hospitalName);
	        System.out.println("Admin Name: " + adminName);
	    }

	    void hospital_userInfo() {
	        String userName = "Kavya";
	        System.out.println("Hospital: " + hospitalName);
	        System.out.println("User Name: " + userName);
	    }

	    public static void main(String[] args) {
	        Hospital h1 = new Hospital();  // Calls default constructor
	        h1.hospital_adminInfo();
	        h1.hospital_userInfo();

	        Hospital h2 = new Hospital("Cardiology"); // Calls parameterized constructor
	    }
	}



