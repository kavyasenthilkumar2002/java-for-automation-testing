package M_O_L_G_DC_parameterized;

public class Insurance {

	    // Global variable
	    String companyName = "ACKO Insurance";

	    // Default Constructor
	    Insurance() {
	        System.out.println("Welcome to " + companyName + "!");
	    }

	    // Parameterized Constructor
	    Insurance(String branchName) {
	        System.out.println("Welcome to " + companyName + " - Branch: " + branchName);
	    }

	    // Local Variable in method
	    void acko_admin() {
	        String adminName = "Ravi Kumar"; 
	        System.out.println(companyName + " - Admin: " + adminName);
	    }

	    void acko_claims() {
	        String claimId = "CLM20250730";
	        System.out.println(companyName + " - Claim ID: " + claimId);
	    }

	    void acko_payment() {
	        String paymentId = "PAY1023";
	        System.out.println(companyName + " - Payment ID: " + paymentId);
	    }


	    public static void main(String[] args) {
	        String branchName = "Main Branch"; 

	        // Using Default Constructor
	        Insurance obj1 = new Insurance();
	        System.out.println("Branch: " + branchName);

	        obj1.acko_admin();
	        obj1.acko_claims();
	        obj1.acko_payment();


	        System.out.println();

	        // Using Parameterized Constructor
	        Insurance obj2 = new Insurance("City Center Branch");
	        obj2.acko_admin();
	        obj2.acko_claims();
	        obj2.acko_payment();

	    }
	}


