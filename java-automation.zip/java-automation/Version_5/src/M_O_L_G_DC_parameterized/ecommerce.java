package M_O_L_G_DC_parameterized;

public class ecommerce {


	    // Global variable
	    String platformName = "Meesho";

	    // Default constructor
	    ecommerce() {
	        System.out.println("Welcome to " + platformName + " E-commerce Platform");
	    }

	    // Parameterized constructor
	    ecommerce(String customPlatform) {
	     System.out.println("Welcome to " + platformName + " E-commerce");
	    }

	    // Product Info
	    void productInfo() {
	        // Local variable
	        String productName = "Floral Anarkali Kurti"; 
	        System.out.println("Platform: " + platformName);
	        System.out.println("Product Name: " + productName);
	    }

	    public static void main(String[] args) {
	        // Calling default constructor
	        ecommerce defaultEcom = new ecommerce();
	        defaultEcom.productInfo();

	        System.out.println("");

	        // Calling parameterized constructor
	        ecommerce paramEcom = new ecommerce("Amazon");
	        paramEcom.productInfo();
	    }
	}


