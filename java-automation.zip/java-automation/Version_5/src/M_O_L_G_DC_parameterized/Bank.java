package M_O_L_G_DC_parameterized;

public class Bank {


	    // Global variable
	    String bankName = "Indian Bank";

	    // Default constructor
	    Bank() {
	        String branchName = "Chennai Branch"; // Local variable in constructor
	        System.out.println("Default Constructor");
	        System.out.println("Bank: " + bankName);
	        System.out.println("Branch: " + branchName);
	    }

	    // Parameterized constructor
	    Bank(String branchName, String managerName) {
	        System.out.println(" Parameterized Constructor");
	        System.out.println("Bank: " + bankName);
	        System.out.println("Branch: " + branchName);
	        System.out.println("Manager: " + managerName);
	    }

	    // Method with a local variable
	    void accountInfo() {
	        String accountHolder = "Kavya"; // Local variable
	        System.out.println("Account Info");
	        System.out.println("Bank: " + bankName);
	        System.out.println("Account Holder: " + accountHolder);
	    }

	    public static void main(String[] args) {
	        Bank b1 = new Bank(); // Calls default constructor
	        b1.accountInfo();

	        Bank b2 = new Bank("Madurai Branch", "Mr. Arjun"); // Calls parameterized constructor
	        b2.accountInfo();
	    }
	}


