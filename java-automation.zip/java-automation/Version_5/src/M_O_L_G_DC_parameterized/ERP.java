package M_O_L_G_DC_parameterized;

public class ERP {


	    // Global Variable
	    String companyName;

	    // Default Constructor
	    ERP() {
	        companyName = "ABC Pvt";
	        System.out.println("Default Constructor: ERP System Initialized for " + companyName);
	    }

	    // Parameterized Constructor
	    ERP(String name) {
	        companyName = name;
	        System.out.println("Parameterized Constructor: ERP System Initialized for " + companyName);
	    }

	    // Local Variable Example
	    void assets() {
	        String assetName = "Dell Laptop"; // Local variable
	        System.out.println(companyName + " - Assets: " + assetName);
	    }

	    void finance() {
	        String fiscalYear = "2024-2025";
	        System.out.println(companyName + " - Finance Year: " + fiscalYear);
	    }

	    void hr() {
	        String employeeName = "Nandhini";
	        System.out.println(companyName + " - Employee: " + employeeName);
	    }

	    void inventory() {
	        String itemName = "Printer Ink";
	        System.out.println(companyName + " - Inventory Item: " + itemName);
	    }

	    void manufacturing() {
	        String productLine = "Textiles";
	        System.out.println(companyName + " - Product Line: " + productLine);
	    }


	    public static void main(String[] args) {
	        // Using Default Constructor
	        ERP e1 = new ERP();
	        e1.assets();
	        e1.finance();
	        e1.hr();
	        e1.inventory();
	        e1.manufacturing();

	        System.out.println();

	        // Using Parameterized Constructor
	        ERP e2 = new ERP("XYZ Solutions");
	        e2.assets();
	        e2.finance();
	        e2.hr();
	        e2.inventory();
	        e2.manufacturing();
	    }
	}

