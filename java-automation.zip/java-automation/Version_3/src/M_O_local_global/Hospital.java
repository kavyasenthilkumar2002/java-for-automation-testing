package M_O_local_global;

public class Hospital {


	    // 1 Global variable (common to all methods)
	    String hospitalName = "Kuppuswamy Hospital";

	    void hospital_adminInfo()
	    {
	        // 1 Local variable
	        String adminName = "Dr. Arjun";
	        System.out.println("Hospital: " + hospitalName);
	        System.out.println("Admin Name: " + adminName);
	    }

	    void hospital_userInfo() 
	    {
	        String userName = "Kavya";
	        System.out.println("Hospital: " + hospitalName);
	        System.out.println("User Name: " + userName);
	    }

	    void hospital_cardiology() 
	    {
	        String doctor = "Dr. Ramesh";
	        System.out.println("Hospital: " + hospitalName);
	        System.out.println("Cardiologist: " + doctor);
	    }

	    void hospital_emergency() 
	    {
	        String doctor = "Dr. Sudha";
	        System.out.println("Hospital: " + hospitalName);
	        System.out.println("Emergency Doctor: " + doctor);
	    }

	    void hospital_gastroenterology() 
	    {
	        String doctor = "Dr. Meena";
	        System.out.println("Hospital: " + hospitalName);
	        System.out.println("Gastroenterologist: " + doctor);
	    }

	    public static void main(String[] args) 
	    {
	    	Hospital h = new Hospital();
	        h.hospital_adminInfo();
	        h.hospital_userInfo();
	        h.hospital_cardiology();
	        h.hospital_emergency();
	        h.hospital_gastroenterology();
	    }
	}

