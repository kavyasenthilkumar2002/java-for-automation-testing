package M_O_local_global;

public class ERP {

	    // 1 Global Variable
	    String companyName = "ABC Pvt";

	    void assets() 
	    {
	        String assetName = "Dell Laptop"; // Local Variable
	        System.out.println(companyName + " - Assets: " + assetName);
	    }


	    void finance() 
	    {
	        String fiscalYear = "2024-2025";
	        System.out.println(companyName + " - Finance Year: " + fiscalYear);
	    }

	    void hr() 
	    {
	        String employeeName = "Nandhini";
	        System.out.println(companyName + " - Employee: " + employeeName);
	    }

	    void inventory() 
	    {
	        String itemName = "Printer Ink";
	        System.out.println(companyName + " - Inventory Item: " + itemName);
	    }

	    void manufacturing() 
	    {
	        String productLine = "Textiles";
	        System.out.println(companyName + " - Product Line: " + productLine);
	    }

	    void projects()
	    {
	        String projectName = "ERP Revamp";
	        System.out.println(companyName + " - Project: " + projectName);
	    }

	   
	    void reports()
	    {
	        String reportName = "Monthly Sales";
	        System.out.println(companyName + " - Report: " + reportName);
	    }

	    void sales() 
	    {
	        String salesExecutive = "Ajith Kumar";
	        System.out.println(companyName + " - Sales Executive: " + salesExecutive);
	    }

	    public static void main(String[] args) 
	    {
	        ERP e = new ERP();
	        e.assets();
	        e.finance();
	        e.hr();
	        e.inventory();
	        e.manufacturing();
	        e.projects();
	        e.reports();
	        e.sales();
	    }
	}

