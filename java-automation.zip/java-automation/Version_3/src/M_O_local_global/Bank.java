package M_O_local_global;

public class Bank {

	    // Global variable
	    String bankName = "Indian Bank";

	    void accountInfo() 
	    {
	        // Local variable
	        String accountHolder = "Kavya";
	        String bankName = "Canara Bank";

	        System.out.println("Bank: " + bankName);
	        System.out.println("Account Holder: " + accountHolder);
	    }

	    void adminInfo() 
	    {
	        String adminName = "Ravi Kumar"; // Local variable
	        System.out.println("Bank: " + bankName);
	        System.out.println("Admin Name: " + adminName);
	    }

	    public static void main(String[] args) 
	    {
	        Bank b = new Bank();
	        b.accountInfo();
	        b.adminInfo();
	    }
	}

