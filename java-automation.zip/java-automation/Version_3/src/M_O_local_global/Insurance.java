	package M_O_local_global;

	public class Insurance {

	    // 1 Global Variable
	    String companyName = "ACKO Insurance";

	    void acko_admin() 
	    {
	        String adminName = "Ravi Kumar"; // Local Variable
	        System.out.println(companyName + " - Admin: " + adminName);
	    }

	    void acko_claims() 
	    {
	        String claimId = "CLM20250730";
	        System.out.println(companyName + " - Claim ID: " + claimId);
	    }


	    void acko_payment()
	    {
	        String paymentId = "PAY1023";
	        System.out.println(companyName + " - Payment ID: " + paymentId);
	    }

	    void acko_policy() 
	    {
	        String policyNumber = "ACKO123456";
	        System.out.println(companyName + " - Policy No: " + policyNumber);
	    }

	    void acko_products() 
	    {
	        String productName = "Car Insurance";
	        System.out.println(companyName + " - Product: " + productName);
	    }

	    void acko_security() 
	    {
	        String loginMethod = "Email";
	        System.out.println(companyName + " - Login Method: " + loginMethod);
	    }

	    void acko_support() 
	    {
	        String agentName = "Divya";
	        System.out.println(companyName + " - Support Agent: " + agentName);
	    }

	    void acko_user() 
	    {
	        String userName = "Kavya";
	        System.out.println(companyName + " - User: " + userName);
	    }


	    void acko_location() 
	    {
	        String city = "Coimbatore";
	        System.out.println(companyName + " - City: " + city);
	    }

	    public static void main(String[] args) 
	    {
	    	Insurance obj = new Insurance();
	        obj.acko_admin();
	        obj.acko_claims();
	        obj.acko_payment();
	        obj.acko_policy();
	        obj.acko_products();
	        obj.acko_security();
	        obj.acko_support();
	        obj.acko_user();
	        obj.acko_location();
	    }
	}

