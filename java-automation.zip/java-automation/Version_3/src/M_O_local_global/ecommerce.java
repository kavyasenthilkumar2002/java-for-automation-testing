package M_O_local_global;

public class ecommerce {


	    // Global variable
	    String platformName = "Meesho";

	    // Product Info
	    void productInfo() 
	    {
	        String productName = "Floral Anarkali Kurti";
	        System.out.println("Platform: " + platformName);
	        System.out.println("Product Name: " + productName);
	    }

	    // Product Price
	    void productPrice()
	    {
	        float price = 749.50f;
	        System.out.println("Platform: " + platformName);
	        System.out.println("Price: ₹" + price);
	    }

	    // Product Category
	    void productCategory() 
	    {
	        String category = "Women's Clothing";
	        System.out.println("Platform: " + platformName);
	        System.out.println("Category: " + category);
	    }

	    // Product Stock Status
	    void stockStatus()
	    {
	        boolean inStock = true;
	        System.out.println("Platform: " + platformName);
	        System.out.println("In Stock: " + inStock);
	    }

	    public static void main(String[] args)
	    {
	    	ecommerce m = new ecommerce();
	        m.productInfo();
	        m.productPrice();
	        m.productCategory();
	        m.stockStatus();
	    }
	}

