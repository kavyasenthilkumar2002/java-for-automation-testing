package ACKOInsurance_Abstract;
abstract class ACKOInsurance {

	    abstract void policyDetails();

	    public static void main(String[] args) {
	        // Abstract class can't be instantiated
	    }
	}