package ACKOInsurance_Abstract;
class InsuranceCompany extends ACKOInsurance {

    void claimProcess() {
        System.out.println("ACKO Insurance Claim Processing...");
    }

    void policyDetails() {
        System.out.println("ACKO provides car, bike, and health insurance policies.");
    }
    
    static
	{
		 System.out.println("ACKOInsurance");
	}
	

    public static void main(String[] args) {
    	InsuranceCompany a = new InsuranceCompany();
        a.claimProcess();
        a.policyDetails();
    }
}