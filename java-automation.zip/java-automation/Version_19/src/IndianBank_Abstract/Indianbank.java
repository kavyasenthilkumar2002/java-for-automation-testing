package IndianBank_Abstract;

public class Indianbank extends Bank {

	static
	{
		 System.out.println("Indianbank");
	}
	
	void branchDetails() {
        System.out.println("Indian Bank - Coimbatore Branch");
    }

    void interestRate() {
        System.out.println("Indian Bank offers 7.2% annual interest on fixed deposits.");
    }

    public static void main(String[] args) {
        Indianbank b = new Indianbank();
        b.branchDetails();
        b.interestRate();
    }
} 