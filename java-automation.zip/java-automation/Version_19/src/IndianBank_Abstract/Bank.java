package IndianBank_Abstract;
abstract class Bank {

    abstract void interestRate();

    public static void main(String[] args) {
        // Abstract class example
    }
}
