package Meesho_Abstarct;

public class meesho extends EcommercePlatform {

	static
	{
		 System.out.println("Meesho");
	}
	
    void companyIntro() {
        System.out.println("Meesho - Online shopping and reseller platform.");
    }

    void availableServices() {
        System.out.println("Services: Online selling, product delivery, and cashback offers.");
    }

    public static void main(String[] args) {
        meesho m = new meesho();
        m.companyIntro();
        m.availableServices();
    }
}
