package Meesho_Abstarct;
abstract class EcommercePlatform {

    abstract void availableServices();

    public static void main(String[] args) {
        // Abstract class example
    }
}
