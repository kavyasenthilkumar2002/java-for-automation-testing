package ERPSystem_Abstarct;
public class ERPSoftware extends  ERP{

	static
	{
		 System.out.println("ERPSoftware");
	}
	
	
	void showCompany() {
        System.out.println("ERP System: Managing business operations efficiently.");
    }

    void showModules() {
        System.out.println("Modules: HR, Finance, Inventory, and Sales.");
    }

    public static void main(String[] args) {
    	ERPSoftware e = new ERPSoftware();
        e.showCompany();
        e.showModules();
    }
}