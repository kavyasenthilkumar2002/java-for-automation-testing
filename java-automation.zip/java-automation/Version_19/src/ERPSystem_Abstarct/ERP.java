package ERPSystem_Abstarct;
abstract class  ERP {

	    abstract void showModules();

	    public static void main(String[] args) {
	        // Abstract class example
	    }
	}