package KuppuswamyHospital_Abstract;
abstract class hospital {

	    abstract void departments();

	    public static void main(String[] args) {
	        // Abstract class example
	    }
	}