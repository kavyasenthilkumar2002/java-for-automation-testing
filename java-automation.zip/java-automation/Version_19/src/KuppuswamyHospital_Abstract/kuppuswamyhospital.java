package KuppuswamyHospital_Abstract;
public class kuppuswamyhospital extends hospital {

	static
	{
		 System.out.println("Kuppuswamyhospital");
	}
	
    void hospitalInfo() {
        System.out.println("Kuppusamy Hospital - Multispeciality Care, Coimbatore.");
    }

    void departments() {
        System.out.println("Departments: Cardiology, Neurology, Orthopedics, Pediatrics.");
    }

    public static void main(String[] args) {
    	kuppuswamyhospital h = new kuppuswamyhospital();
        h.hospitalInfo();
        h.departments();
    }
}