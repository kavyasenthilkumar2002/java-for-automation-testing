package Withthis;

public class Insurance {

				
					//Global variable
						int number;
						String Company;
						String Type;
						
						// methods
					 void diplayname (int Number,String SystemName,String About) {
						 // this keyword is used 
						 this.number= Number;
						 this.Company= SystemName;
						 this.Type=About;
						 
					 }
					
					void display() {
						System.out.println("Acho insurance");
						System.out.println("Number is: " + number);
						System.out.println("SystemName is: " + Company);
						System.out.println("About is:" + Type);
					}
				 

					public static void main(String[] args) {
						// TODO Auto-generated method stub

						Insurance a=new Insurance();
						a.diplayname (07, "Acho insurance","Good insurance");
						a.display();
					}

				}






