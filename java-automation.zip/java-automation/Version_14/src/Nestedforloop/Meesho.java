package Nestedforloop;

public class Meesho {


    void products() {
        int totalCategories = 3;

        for (int i = 1; i <= totalCategories; i++) {
        	
            System.out.println("Category " + i + ":");

            // Inner loop prints products for each category
            for (int j = 1; j <= 4; j++) {
            	
            	// Category 1
                if (i == 1) {
                    if (j == 1) System.out.println(" Saree");
                    if (j == 2) System.out.println(" Kurthi");
                    if (j == 3) System.out.println(" Chudi");
                    if (j == 4) System.out.println(" Jeans");
                }
                
             // Category 2
                if (i == 2) { 
                    if (j == 1) System.out.println(" Shoes");
                    if (j == 2) System.out.println(" Sandals");
                    if (j == 3) System.out.println(" Slippers");
                }
                
             // Category 3
                if (i == 3) { 
                    if (j == 1) System.out.println(" Watch");
                    if (j == 2) System.out.println(" Bracelet");
                    if (j == 3) System.out.println(" Earrings");
                }
            }

            System.out.println(); 
        }
    }

    void display() {
        this.products();
    }

    public static void main(String[] args) {
        Meesho m = new Meesho();
        m.display();
    }
}