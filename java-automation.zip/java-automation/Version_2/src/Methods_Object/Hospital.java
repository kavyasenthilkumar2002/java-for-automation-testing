package Methods_Object;
public class Hospital {


	    void hospital_adminInfo() 
	    {
	        String adminName = "Dr. Arjun";
	        String adminEmail = "arjun@hospital.com";
	        boolean adminActive = true;
	        String adminRole = "Administrator";
	        int adminId = 101;

	        System.out.println("Admin Info");
	        System.out.println("Admin Name: " + adminName);
	        System.out.println("Admin Email: " + adminEmail);
	        System.out.println("Admin Active: " + adminActive);
	        System.out.println("Admin Role: " + adminRole);
	        System.out.println("Admin ID: " + adminId);
	        System.out.println();
	    }

	    void hospital_userInfo() 
	    {
	        String userName = "Kavya";
	        String userEmail = "kavya@gmail.com";
	        String userRole = "Patient";
	        boolean userVerified = true;
	        int userAge = 25;
	        String userGender = "Female";
	        String userPhone = "9876543210";
	        String userCity = "Coimbatore";
	        boolean isInsured = true;

	        System.out.println("App User Info");
	        System.out.println("User Name: " + userName);
	        System.out.println("User Email: " + userEmail);
	        System.out.println("User Role: " + userRole);
	        System.out.println("User Verified: " + userVerified);
	        System.out.println("User Age: " + userAge);
	        System.out.println("User Gender: " + userGender);
	        System.out.println("User Phone: " + userPhone);
	        System.out.println("User City: " + userCity);
	        System.out.println("Insured: " + isInsured);
	        System.out.println();
	    }

	    void hospital_cardiology() 
	    {
	        String cardiologistName = "Dr. Ramesh";
	        String heartCondition = "Arrhythmia";
	        float heartRate = 78.5f;
	        boolean requiresECG = true;
	        String cholesterolStatus = "Normal";
	        boolean takingBetaBlockers = false;
	        int bloodPressureSystolic = 120;
	        int bloodPressureDiastolic = 80;
	        boolean hasFamilyHistory = true;

	        System.out.println("Cardiology");
	        System.out.println("Cardiologist Name: " + cardiologistName);
	        System.out.println("Heart Condition: " + heartCondition);
	        System.out.println("Heart Rate: " + heartRate);
	        System.out.println("Requires ECG: " + requiresECG);
	        System.out.println("Cholesterol Status: " + cholesterolStatus);
	        System.out.println("Taking Beta Blockers: " + takingBetaBlockers);
	        System.out.println("Blood Pressure Systolic: " + bloodPressureSystolic);
	        System.out.println("Blood Pressure Diastolic: " + bloodPressureDiastolic);
	        System.out.println("Family History: " + hasFamilyHistory);
	        System.out.println();
	    }

	    void hospital_emergency() 
	    {
	        String emergencyDoctor = "Dr. Sudha";
	        boolean isCritical = true;
	        String emergencyType = "Accident";
	        int emergencyLevel = 5;
	        boolean requiresSurgery = true;
	        boolean ambulanceArrived = true;
	        String patientCondition = "Unconscious";

	        System.out.println("Emergency Department");
	        System.out.println("Doctor: " + emergencyDoctor);
	        System.out.println("Is Critical: " + isCritical);
	        System.out.println("Emergency Type: " + emergencyType);
	        System.out.println("Emergency Level: " + emergencyLevel);
	        System.out.println("Requires Surgery: " + requiresSurgery);
	        System.out.println("Ambulance Arrived: " + ambulanceArrived);
	        System.out.println("Patient Condition: " + patientCondition);
	        System.out.println();
	    }

	    void hospital_gastroenterology() 
	    {
	        String gastroDoctor = "Dr. Meena";
	        String condition = "Ulcer";
	        boolean isChronic = false;
	        float stomachAcidLevel = 3.5f;
	        String dietRecommendation = "Soft diet";
	        boolean lactoseIntolerant = true;
	        int painScale = 4;

	        System.out.println("Gastroenterology");
	        System.out.println("Doctor: " + gastroDoctor);
	        System.out.println("Condition: " + condition);
	        System.out.println("Is Chronic: " + isChronic);
	        System.out.println("Stomach Acid Level: " + stomachAcidLevel);
	        System.out.println("Diet Recommendation: " + dietRecommendation);
	        System.out.println("Lactose Intolerant: " + lactoseIntolerant);
	        System.out.println("Pain Scale: " + painScale);
	        System.out.println();
	    }

	    void hospital_general() 
	    {
	        String doctorName = "Dr. Anitha";
	        String diagnosis = "Fever";
	        float temperature = 101.2f;
	        boolean takingAntibiotics = true;
	        String medication = "Paracetamol";
	        int daysOfRest = 3;
	        boolean followUpRequired = false;

	        System.out.println("General Medicine");
	        System.out.println("Doctor: " + doctorName);
	        System.out.println("Diagnosis: " + diagnosis);
	        System.out.println("Temperature: " + temperature);
	        System.out.println("Taking Antibiotics: " + takingAntibiotics);
	        System.out.println("Medication: " + medication);
	        System.out.println("Days of Rest: " + daysOfRest);
	        System.out.println("Follow-up Required: " + followUpRequired);
	        System.out.println();
	    }

	    void hospital_gynecology() 
	    {
	        System.out.println("Gynecology Department");
	        System.out.println("Doctor: Dr. Leela");
	        System.out.println("Patient Status: 2nd Trimester");
	        System.out.println("Ultrasound Done: true");
	        System.out.println("Supplements: Iron, Calcium");
	        System.out.println();
	    }

	    void hospital_neurology()
	    {
	        System.out.println("Neurology Department");
	        System.out.println("Doctor: Dr. Naveen");
	        System.out.println("Condition: Migraine");
	        System.out.println("MRI Done: true");
	        System.out.println("Medication: Pain management");
	        System.out.println();
	    }

	    void hospital_orthopedics() {
	        System.out.println("Orthopedics Department");
	        System.out.println("Doctor: Dr. Ravi");
	        System.out.println("Injury: Fractured Arm");
	        System.out.println("Surgery Required: false");
	        System.out.println("Recovery Time: 6 weeks");
	        System.out.println();
	    }

	    void hospital_ent() 
	    {
	        System.out.println("ENT Department");
	        System.out.println("Doctor: Dr. Sangeetha");
	        System.out.println("Issue: Sinus Infection");
	        System.out.println("Prescribed: Antibiotics");
	        System.out.println();
	    }

	    void hospital_dental()
	    {
	        System.out.println("Dental Department");
	        System.out.println("Doctor: Dr. Prakash");
	        System.out.println("Treatment: Root Canal");
	        System.out.println("Follow-up Needed: true");
	        System.out.println();
	    }

	    void hospital_pediatrics() 
	    {
	        System.out.println("Pediatrics Department");
	        System.out.println("Doctor: Dr. Sneha");
	        System.out.println("Age Group: Infant");
	        System.out.println("Issue: Cold and Fever");
	        System.out.println();
	    }

	    void hospital_dermatology() 
	    {
	        System.out.println("Dermatology Department");
	        System.out.println("Doctor: Dr. Bala");
	        System.out.println("Skin Issue: Acne");
	        System.out.println("Treatment: Topical Creams");
	        System.out.println();
	    }

	    void hospital_physiotherapy()
	    {
	        System.out.println("Physiotherapy Department");
	        System.out.println("Therapist: Mr. Arun");
	        System.out.println("Sessions Scheduled: 10");
	        System.out.println();
	    }

	    void hospital_urology() 
	    {
	        System.out.println("Urology Department");
	        System.out.println("Doctor: Dr. Mahesh");
	        System.out.println("Issue: Kidney Stones");
	        System.out.println("Procedure: Lithotripsy");
	        System.out.println();
	    }

	    void hospital_ophthalmology() 
	    {
	        System.out.println("Ophthalmology Department");
	        System.out.println("Doctor: Dr. Vinod");
	        System.out.println("Issue: Cataract");
	        System.out.println("Surgery Scheduled: true");
	        System.out.println();
	    }

	    void hospital_radiology() 
	    {
	        System.out.println("Radiology Department");
	        System.out.println("Scan Type: CT Scan");
	        System.out.println("Findings: Normal");
	        System.out.println();
	    }

	    void hospital_psychiatry() {
	        System.out.println("Psychiatry Department");
	        System.out.println("Doctor: Dr. Hari");
	        System.out.println("Diagnosis: Anxiety");
	        System.out.println("Therapy Suggested: CBT");
	        System.out.println();
	    }

	    void hospital_oncology() 
	    {
	        System.out.println("Oncology Department");
	        System.out.println("Doctor: Dr. Raji");
	        System.out.println("Cancer Type: Breast Cancer");
	        System.out.println("Stage: 2");
	        System.out.println();
	    }

	    void hospital_nephrology() 
	    {
	        System.out.println("Nephrology Department");
	        System.out.println("Doctor: Dr. Deepak");
	        System.out.println("Issue: Kidney Failure");
	        System.out.println("Dialysis Required: true");
	        System.out.println();
	    }

	    void hospital_pulmonology() 
	    {
	        System.out.println("Pulmonology Department");
	        System.out.println("Doctor: Dr. Kiran");
	        System.out.println("Issue: Asthma");
	        System.out.println("Inhaler Prescribed: true");
	        System.out.println();
	    }

			    // Add remaining departments here (Gynecology, Neurology, etc.)

			    public static void main(String[] args) 
			    {
			        
			    	Hospital h = new Hospital();

			        h.hospital_adminInfo();
			        h.hospital_userInfo();
			        h.hospital_cardiology();
			        h.hospital_emergency();
			        h.hospital_gastroenterology();
			        h.hospital_general();
			        h.hospital_gynecology();
			        h.hospital_neurology();
			        h.hospital_orthopedics();
			        h.hospital_ent();
			        h.hospital_dental();
			        h.hospital_pediatrics();
			        h.hospital_dermatology();
			        h.hospital_physiotherapy();
			        h.hospital_urology();
			        h.hospital_ophthalmology();
			        h.hospital_radiology();
			        h.hospital_psychiatry();
			        h.hospital_oncology();
			        h.hospital_nephrology();
			        h.hospital_pulmonology();
			    	}
			    }
	
	



