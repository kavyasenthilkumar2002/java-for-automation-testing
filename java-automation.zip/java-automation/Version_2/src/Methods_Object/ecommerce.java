package Methods_Object;
public class ecommerce {
	

		void meesho_productinfo() 
		{
		    String productName = "Floral Anarkali Kurti";
		    int productId = 1001;
		    float price = 749.50f;
		    float discountPercentage = 10.5f;
		    boolean inStock = true;
		    boolean isCODAvailable = true;
		    System.out.println("Product Info");
	        System.out.println("Product Name: " + productName);
	        System.out.println("Product ID: " + productId);
	        System.out.println("Price: " + price);
	        System.out.println("Discount Percentage: " + discountPercentage);
	        System.out.println("In Stock: " + inStock);
	        System.out.println("COD Available: " + isCODAvailable);
	        System.out.println("");
	        
	        
		}
		
		void meesho_category() 
		{
		 String category = "Women";
		    String subCategory = "Kurthis";
		    String productType = "Ethnic Wear";
	     System.out.println("Category");
	     System.out.println("Category: " + category);
	     System.out.println("Subcategory: " + subCategory);
	     System.out.println("Product Type: " + productType);
	     System.out.println("");
		}
		
		void meesho_kurthi() 
		{
			String fabric = "Rayon";
		    String color = "Mustard Yellow";
		    String size = "M";
		    String fitType = "Regular Fit";
		    String neckDesign = "Round Neck";
		    String pattern = "Printed";
		    String occasion = "Festive";
		    boolean hasDupatta = false;
		    boolean isComboSet = false;
		    System.out.println("Kurthi");
		    System.out.println("Fabric: " + fabric);
	        System.out.println("Color: " + color);
	        System.out.println("Size: " + size);
	        System.out.println("Fit Type: " + fitType);
	        System.out.println("Neck Design: " + neckDesign);
	        System.out.println("Pattern: " + pattern);
	        System.out.println("Occasion: " + occasion);
	        System.out.println("Has Dupatta: " + hasDupatta);
	        System.out.println("Is Combo Set: " + isComboSet);
	        System.out.println("");
		}
		
		void meesho_stockOrder() 
		{
	    int stockQuantity = 25;
	    int minOrderQty = 1;
	    System.out.println("Stock & Order");
	    System.out.println("Stock Quantity: " + stockQuantity);
	    System.out.println("Minimum Order Quantity: " + minOrderQty);
	    System.out.println("");
		}
	    		
	    void meesho_reviews() 
	    {
	    float rating = 4.3f;
	    int totalReviews = 152;
	    int reviewId = 9001;
	    String reviewComment = "Great quality and fit!";
	    int reviewRating = 5;
	    boolean isReviewApproved = true;
	    System.out.println("Reviews");
	    System.out.println("Rating: " + rating);
	    System.out.println("Total Reviews: " + totalReviews);
	    System.out.println("Review ID: " + reviewId);
	    System.out.println("Review Comment: " + reviewComment);
	    System.out.println("Review Rating: " + reviewRating);
	    System.out.println("Review Approved: " + isReviewApproved);
	    System.out.println("");
	    }
	    
	    void meesho_customerInfo() 
	    {
	    String customerName = "Sneha";
	    String email = "sneha@gmail.com";
	    String gender = "Female";
	    int age = 23;
	    boolean isPremiumUser = true;
	    System.out.println("Customer Info");
	    System.out.println("Customer Name: " + customerName);
	    System.out.println("Email: " + email);
	    System.out.println("Gender: " + gender);
	    System.out.println("Age: " + age);
	    System.out.println("Premium User: " + isPremiumUser);
	    System.out.println("");
	    }
	    
	    void meesho_ddressInfo() 
	    {
	    String addressLine = "123, Gandhi park";
	    String city = "Coimbatore";
	    String state = "Tamil Nadu";
	    String country = "India";
	    String pinCode = "641503";
	    String addressType = "Home";
	    System.out.println("Address Info");
	    System.out.println("Address Line: " + addressLine);
	    System.out.println("City: " + city);
	    System.out.println("State: " + state);
	    System.out.println("Country: " + country);
	    System.out.println("Pin Code: " + pinCode);
	    System.out.println("Address Type: " + addressType);
	    System.out.println("");
	    }
	    
	    void meesho_OrderInfo() 
	    {
	    int orderId = 101245;
	    String orderStatus = "Shipped";
	    boolean isGiftWrapped = false;
	    boolean isReturnable = true;
	    System.out.println("Order Info");
	    System.out.println("Order ID: " + orderId);
	    System.out.println("Order Status: " + orderStatus);
	    System.out.println("Gift Wrapped: " + isGiftWrapped);
	    System.out.println("Returnable: " + isReturnable);
	    System.out.println("");
	    }
	    
	    void meesho_paymentInfo() 
	    {
	    String paymentMethod = "UPI";
	    boolean paymentSuccess = true;
	    System.out.println("Payment Info");
	    System.out.println("Payment Method: " + paymentMethod);
	    System.out.println("Payment Success: " + paymentSuccess);
	    System.out.println("");
	    }
	    
	    	void meesho_sellerInfo() 
	    	{
	        String sellerName = "Trendy Fashions";
	        String sellerType = "Individual";
	        boolean isSellerVerified = true;
	        float sellerRating = 4.6f;
	        int sellerId = 501;
	        System.out.println("Seller Info");
	        System.out.println("Seller Name: " + sellerName);
	        System.out.println("Seller Type: " + sellerType);
	        System.out.println("Seller Verified: " + isSellerVerified);
	        System.out.println("Seller Rating: " + sellerRating);
	        System.out.println("Seller ID: " + sellerId);
	        System.out.println("");
	    }

	    	void meesho_cartInfo() 
	    	{
	        boolean cartActive = true;
	        int cartItemCount = 3;
	        boolean isCartActive = true;
	        int cartItems = 4;
	        System.out.println("Cart Info");
	        System.out.println("Cart Active: " + cartActive);
	        System.out.println("Cart Item Count: " + cartItemCount);
	        System.out.println("Is Cart Active: " + isCartActive);
	        System.out.println("Cart Items: " + cartItems);
	        System.out.println("");
	    }

	    	void meesho_wishlistInfo() 
	    	{
	        boolean isWishlistPublic = false;
	        String wishlistType = "Personal";
	        boolean isPublic = false;
	        String wishlistType1 = "Personal";
	        System.out.println("Wishlist Info");
	        System.out.println("isWishlistPublic: " + isWishlistPublic);
	        System.out.println("wishlistType: " + wishlistType);
	        System.out.println("isPublic: " + isPublic);
	        System.out.println("wishlistType1: " + wishlistType1);
	        System.out.println("");
	    }

	    	void meesho_shipmentInfo() 
	    	{
	        String shipmentPartner = "Delhivery";
	        String trackingId = "DEL789456IND";
	        boolean isOutForDelivery = true;
	        String carrierName1 = "Blue Dart";
	        boolean isDelivered = true;
	        System.out.println("Shipment Info");
	        System.out.println("Shipment Partner: " + shipmentPartner);
	        System.out.println("Tracking ID: " + trackingId);
	        System.out.println("Out for Delivery: " + isOutForDelivery);
	        System.out.println("Carrier Name: " + carrierName1);
	        System.out.println("Delivered: " + isDelivered);
	        System.out.println("");
	    }

	    	void meesho_productVariants() 
	    	{
	        String color1 = "Black";
	        String color2 = "Maroon";
	        String size1 = "M";
	        String size2 = "L";
	        System.out.println("Product Variants");
	        System.out.println("Color Variant 1: " + color1);
	        System.out.println("Color Variant 2: " + color2);
	        System.out.println("Size Variant 1: " + size1);
	        System.out.println("Size Variant 2: " + size2);
	        System.out.println("");
	    }

	    	void meesho_occasionExtra()
	    	{
	        String occasion1 = "Casual";
	        String occasion2 = "Festive";
	        System.out.println("Occasion Extra");
	        System.out.println("Occasion 1: " + occasion1);
	        System.out.println("Occasion 2: " + occasion2);
	        System.out.println("");
	    }

	    	void meesho_washingInstruction() 
	    	{
	        String washCare1 = "Machine Wash";
	        System.out.println("Washing Instruction");
	        System.out.println("Wash Care: " + washCare1);
	        System.out.println("");
	    }

	    	void meesho_footwear() 
	    	{
	        String footwearType1 = "Heels";
	        float shoeSize1 = 7.0f;
	        boolean isSlipOn = true;
	        System.out.println("Footwear");
	        System.out.println("Footwear Type: " + footwearType1);
	        System.out.println("Shoe Size: " + shoeSize1);
	        System.out.println("Is Slip On: " + isSlipOn);
	        System.out.println("");
	    }

	    	void meesho_bags()
	    	{
	        String bagType1 = "Bags";
	        String material1 = "PU Leather";
	        int compartmentCount = 3;
	        boolean hasZip = true;
	        System.out.println("Bags");
	        System.out.println("Bag Type: " + bagType1);
	        System.out.println("Material: " + material1);
	        System.out.println("Compartment Count: " + compartmentCount);
	        System.out.println("Has Zip: " + hasZip);
	        System.out.println("");
	    }

	    	void meesho_beautyProducts() 
	    	{
	        String productType1 = "Beauty Products";
	        boolean isOrganic = true;
	        String skinType1 = "All Skin Types";
	        System.out.println("Beauty Products");
	        System.out.println("Beauty Product Type: " + productType1);
	        System.out.println("Is Organic: " + isOrganic);
	        System.out.println("Skin Type: " + skinType1);
	        System.out.println("");
	    }

	    	void meesho_electronics() 
	    	{
	        String electronicType1 = "Smart Watch";
	        boolean isBluetoothEnabled = true;
	        float batteryLifeHours = 24.0f;
	        System.out.println("Electronics");
	        System.out.println("Electronic Type: " + electronicType1);
	        System.out.println("Bluetooth Enabled: " + isBluetoothEnabled);
	        System.out.println("Battery Life (Hours): " + batteryLifeHours);
	        System.out.println("");
	    }

	    	void meesho_kidsProducts() 
	    	{
	        String toyType1 = "Puzzle";
	        int minAge = 3;
	        System.out.println("Kids Products");
	        System.out.println("Toy Type: " + toyType1);
	        System.out.println("Minimum Age: " + minAge);
	        System.out.println("");
	    }

	    	void meesho_bedsheets()
	    	{
	        String bedSize1 = "Double";
	        String printType1 = "Floral";
	        System.out.println("Bedsheets");
	        System.out.println("Bed Size: " + bedSize1);
	        System.out.println("Print Type: " + printType1);
	        System.out.println("");
	    }

	    	void meesho_cookware() 
	    	{
	        String cookwareType1 = "Non-Stick Pan";
	        boolean isInductionSafe = false;
	        System.out.println("Cookware");
	        System.out.println("Cookware Type: " + cookwareType1);
	        System.out.println("Induction Safe: " + isInductionSafe);
	        System.out.println("");
	    }

	    	void meesho_decor() 
	    	{
	        String decorType1 = "Wall Clock";
	        System.out.println("Decor");
	        System.out.println("Decor Type: " + decorType1);
	        System.out.println("");
	    }

	    	void meesho_menFashion() 
	    	{
	        String shirtFit1 = "Slim Fit";
	        String collarType1 = "Mandarin";
	        String jeansStyle1 = "Straight Fit";
	        String menShoeType1 = "Sneakers";
	        System.out.println("Men Fashion");
	        System.out.println("Men Shirt Fit: " + shirtFit1);
	        System.out.println("Collar Type: " + collarType1);
	        System.out.println("Jeans Style: " + jeansStyle1);
	        System.out.println("Men Shoe Type: " + menShoeType1);
	        System.out.println("");
	    }

	    	void meesho_paymentExtended()
	    	{
	        String paymentMode1 = "UPI";
	        boolean isPaymentCompleted = true;
	        System.out.println("Payment Extended");
	        System.out.println("Payment Mode: " + paymentMode1);
	        System.out.println("Payment Completed: " + isPaymentCompleted);
	        System.out.println("");
	    }

	    	void meesho_returnRequest()
	    	{
	        String returnReason1 = "Size Issue";
	        boolean isApproved = false;
	        System.out.println("Return Request");
	        System.out.println("Return Reason: " + returnReason1);
	        System.out.println("Return Approved: " + isApproved);
	        System.out.println("");
	    }

	    	void meesho_customerAlt() 
	    	{
	        String city1 = "Chennai";
	        String state1 = "Tamil Nadu";
	        System.out.println("Customer Alt");
	        System.out.println("Customer City (Alt): " + city1);
	        System.out.println("Customer State (Alt): " + state1);
	        System.out.println("");
	    }

	    	void meesho_reviewsAlt() {
	        float rating1 = 4.7f;
	        String reviewStatus = "Approved";
	        System.out.println("Reviews (Alt)");
	        System.out.println("Rating (Alt): " + rating1);
	        System.out.println("Review Status: " + reviewStatus);
	        System.out.println("");
	    }

	    	void meesho_productImage()
	    	{
	        String resolution1 = "600x600";
	        String format1 = "JPG";
	        System.out.println("Product Image");
	        System.out.println("Resolution: " + resolution1);
	        System.out.println("Format: " + format1);
	        System.out.println("");
	    }

		
		public static void main(String[] args) 
		{
			
			ecommerce m= new ecommerce();
			m.meesho_productinfo();
	        m.meesho_category();
	        m.meesho_kurthi();
	        m.meesho_stockOrder();
	        m.meesho_reviews();
	        m.meesho_customerInfo();
	        m.meesho_ddressInfo();
	        m.meesho_OrderInfo();
	        m.meesho_paymentInfo();
	        m.meesho_sellerInfo();
	        m.meesho_cartInfo();
	        m.meesho_wishlistInfo();
	        m.meesho_shipmentInfo();
	        m.meesho_productVariants();
	        m.meesho_occasionExtra();
	        m.meesho_washingInstruction();
	        m.meesho_footwear();
	        m.meesho_bags();
	        m.meesho_beautyProducts();
	        m.meesho_electronics();
	        m.meesho_kidsProducts();
	        m.meesho_bedsheets();
	        m.meesho_cookware();
	        m.meesho_decor();
	        m.meesho_menFashion();
	        m.meesho_paymentExtended();
	        m.meesho_returnRequest();
	        m.meesho_customerAlt();
	        m.meesho_reviewsAlt();
	        m.meesho_productImage();
		      
		}
		}



