package Policy;

public class PolicyDocument {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
