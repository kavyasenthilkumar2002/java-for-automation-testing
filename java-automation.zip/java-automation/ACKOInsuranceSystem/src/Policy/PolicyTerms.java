package Policy;

public class PolicyTerms {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
