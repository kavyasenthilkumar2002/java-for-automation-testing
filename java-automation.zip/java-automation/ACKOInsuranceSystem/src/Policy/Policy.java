package Policy;

public class Policy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
