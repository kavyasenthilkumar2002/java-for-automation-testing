package Products;

public class LifeInsurance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
