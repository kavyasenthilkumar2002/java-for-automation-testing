package Products;

public class MobileInsurance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
