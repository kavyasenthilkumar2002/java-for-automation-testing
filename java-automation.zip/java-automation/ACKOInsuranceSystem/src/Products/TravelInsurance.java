package Products;

public class TravelInsurance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
