package Products;

public class CarInsurance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
