package Security;

public class BiometricVerification {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
