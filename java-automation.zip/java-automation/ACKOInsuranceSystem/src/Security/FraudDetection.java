package Security;

public class FraudDetection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
