package Security;

public class OTPService {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
