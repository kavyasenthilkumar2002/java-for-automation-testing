package Security;

public class EncryptionService {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
