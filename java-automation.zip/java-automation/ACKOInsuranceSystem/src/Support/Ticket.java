package Support;

public class Ticket {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
