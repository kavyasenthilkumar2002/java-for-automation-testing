package Notifications;

public class SMSService {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		long number= 6379318081L;
		
	}

}
