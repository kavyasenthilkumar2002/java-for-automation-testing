package Notifications;

public class Notifications {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
