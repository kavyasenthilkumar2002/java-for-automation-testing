package Notifications;

public class EmailService {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String email_id="skavyasenthil2002@gmail.com";
				
	}

}
