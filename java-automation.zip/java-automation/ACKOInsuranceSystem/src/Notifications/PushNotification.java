package Notifications;

public class PushNotification {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
