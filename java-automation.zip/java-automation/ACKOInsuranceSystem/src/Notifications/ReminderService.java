package Notifications;

public class ReminderService {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
