package User;

public class UserProfile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
