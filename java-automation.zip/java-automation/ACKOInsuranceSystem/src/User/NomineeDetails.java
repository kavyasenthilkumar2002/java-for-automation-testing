package User;

public class NomineeDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
