package User;

public class KYCDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
