package Underwriting;

public class RiskAssessment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
