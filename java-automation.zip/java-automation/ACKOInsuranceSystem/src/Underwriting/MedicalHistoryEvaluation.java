package Underwriting;

public class MedicalHistoryEvaluation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
