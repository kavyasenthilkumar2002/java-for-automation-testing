package Payment;

public class EMIPlan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
