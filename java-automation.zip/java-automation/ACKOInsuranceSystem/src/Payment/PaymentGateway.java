package Payment;

public class PaymentGateway {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
