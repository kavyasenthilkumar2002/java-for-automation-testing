package Payment;

public class PremiumCalculation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
