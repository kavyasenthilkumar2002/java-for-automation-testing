package Claims;

public class ClaimAssessment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
