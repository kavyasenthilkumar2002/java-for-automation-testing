package Claims;

public class Claim {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
