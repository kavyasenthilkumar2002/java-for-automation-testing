package Claims;

public class ClaimDocument {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
