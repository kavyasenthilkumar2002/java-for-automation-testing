package Claims;

public class ClaimStatus {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
