package Admin;

public class ReportGenerator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
