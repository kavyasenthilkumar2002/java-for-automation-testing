package Admin;

public class UserManagement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
