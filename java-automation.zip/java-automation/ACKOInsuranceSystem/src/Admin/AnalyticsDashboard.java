package Admin;

public class AnalyticsDashboard {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
