package Admin;

public class Admin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        String name="Kavya";
        String password="WELc@me123";
       
	}

}
