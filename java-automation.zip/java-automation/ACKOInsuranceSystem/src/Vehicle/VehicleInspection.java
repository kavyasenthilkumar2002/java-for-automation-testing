package Vehicle;

public class VehicleInspection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
