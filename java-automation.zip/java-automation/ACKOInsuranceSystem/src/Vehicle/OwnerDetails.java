package Vehicle;

public class OwnerDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
