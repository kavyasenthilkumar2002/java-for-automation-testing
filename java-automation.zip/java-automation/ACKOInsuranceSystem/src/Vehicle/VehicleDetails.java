package Vehicle;

public class VehicleDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
