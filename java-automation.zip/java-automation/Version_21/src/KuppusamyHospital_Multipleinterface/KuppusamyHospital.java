package KuppusamyHospital_Multipleinterface;
public class KuppusamyHospital implements Doctor, Nurse {

	static
	{
		System.out.println("KuppusamyHospital:");
		System.out.println("");
	}
	
    public void diagnosePatient() {
        System.out.println("Doctor diagnosing patient based on symptoms");
    }

    public void assistDoctor() {
        System.out.println("Nurse assisting doctor during treatment");
    }

    public static void main(String[] args) {
    	KuppusamyHospital a=new KuppusamyHospital();
    	a.diagnosePatient();
    	a.assistDoctor();
      
}
}
