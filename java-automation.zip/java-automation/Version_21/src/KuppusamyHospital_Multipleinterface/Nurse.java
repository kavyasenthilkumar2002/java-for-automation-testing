package KuppusamyHospital_Multipleinterface;
interface Nurse {
    void assistDoctor();
}

