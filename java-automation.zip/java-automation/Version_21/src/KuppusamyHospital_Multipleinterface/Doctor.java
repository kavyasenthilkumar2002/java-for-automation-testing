package KuppusamyHospital_Multipleinterface;
interface Doctor {
    void diagnosePatient();
}
