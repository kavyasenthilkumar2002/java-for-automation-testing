package ACKOInsurance_Multipleinterface;
interface InsurancePolicy {
    void calculatePremium();
}

