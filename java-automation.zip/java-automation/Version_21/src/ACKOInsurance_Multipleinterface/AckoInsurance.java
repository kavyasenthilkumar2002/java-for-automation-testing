package ACKOInsurance_Multipleinterface;
public class AckoInsurance implements ClaimProcess, InsurancePolicy {

	static
	{
		System.out.println("AckoInsurance:");
		System.out.println("");
	}
	
    public void calculatePremium() {
        System.out.println("Calculating insurance premium based on customer profile");
    }

    public void processClaim() {
        System.out.println("Processing claim for the insured customer");
    }

    public static void main(String[] args) {
        AckoInsurance obj = new AckoInsurance();
        obj.calculatePremium();
        obj.processClaim();
    }
}
