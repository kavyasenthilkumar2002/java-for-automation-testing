package ACKOInsurance_Multipleinterface;
interface ClaimProcess {
    void processClaim();
}


	


