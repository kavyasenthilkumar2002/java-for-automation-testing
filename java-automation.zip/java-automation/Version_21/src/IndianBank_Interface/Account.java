package IndianBank_Interface;
interface Account {
    void openAccount();
}

