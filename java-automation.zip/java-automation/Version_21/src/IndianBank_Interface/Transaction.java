package IndianBank_Interface;
interface Transaction {
    void makeTransaction();
}

