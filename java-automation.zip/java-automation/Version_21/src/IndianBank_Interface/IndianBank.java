package IndianBank_Interface;
public class IndianBank implements Account, Transaction {

	static
	{
		System.out.println("IndianBank:");
		System.out.println("");
	}
	
    public void openAccount() {
        System.out.println("Opening new savings account at Indian Bank");
    }

    public void makeTransaction() {
        System.out.println("Performing secure bank transaction");
    }

    public static void main(String[] args) {
    	IndianBank a= new IndianBank();
    	a.openAccount();
    	a.makeTransaction();
    }
}