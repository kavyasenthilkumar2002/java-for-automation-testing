package ERP_Multipleinterface;
interface Payroll {
    void processSalary();
}

	

