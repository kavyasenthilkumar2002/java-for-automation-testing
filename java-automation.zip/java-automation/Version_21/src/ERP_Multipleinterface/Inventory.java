package ERP_Multipleinterface;
	interface Inventory {
	    void manageStock();
	}

