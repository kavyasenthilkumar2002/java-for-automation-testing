package ERP_Multipleinterface;
public class ERPSystem implements Inventory, Payroll {

	static
	{
		System.out.println("ERPSystem:");
		System.out.println("");
	}
	
	    public void manageStock() {
	        System.out.println("Managing product inventory in ERP system");
	    }

	    public void processSalary() {
	        System.out.println("Processing monthly salary for employees");
	    }

	    public static void main(String[] args) {
	    	ERPSystem a = new ERPSystem();
	    	a.manageStock();
	    	a.processSalary();
	        
	        
	}
}

	