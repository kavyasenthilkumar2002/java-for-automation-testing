package Meesho_Interface;
public class Meesho implements Seller, Buyer {

	static
	{
		System.out.println("Meesho:");
		System.out.println("");
	}
	
	    public void listProduct() {
	        System.out.println("Seller lists new product on Meesho platform...");
	    }

	    public void placeOrder() {
	        System.out.println("Buyer places order using Meesho app...");
	    }

	    public static void main(String[] args) {
	    	Meesho app= new Meesho();
	    	app.listProduct();
	    	app.placeOrder();
	}
	}
