package Meesho_Interface;
interface Seller {
    void listProduct();
}

