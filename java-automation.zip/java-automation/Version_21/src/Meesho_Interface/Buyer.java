package Meesho_Interface;
interface Buyer {
    void placeOrder();
}

