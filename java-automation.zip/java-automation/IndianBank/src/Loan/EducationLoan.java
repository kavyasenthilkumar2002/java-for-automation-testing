package Loan;

public class EducationLoan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
