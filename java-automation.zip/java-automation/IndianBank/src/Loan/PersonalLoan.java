package Loan;

public class PersonalLoan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
