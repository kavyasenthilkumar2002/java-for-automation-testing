package Loan;

public class VehicleLoan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
