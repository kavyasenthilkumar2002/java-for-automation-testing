package Loan;

public class LoanEligibility {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
