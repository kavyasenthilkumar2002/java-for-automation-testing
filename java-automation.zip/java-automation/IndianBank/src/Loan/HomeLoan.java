package Loan;

public class HomeLoan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
