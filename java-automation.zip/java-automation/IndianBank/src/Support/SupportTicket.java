package Support;

public class SupportTicket {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
