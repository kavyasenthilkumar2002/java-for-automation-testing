package Account;

public class SavingsAccount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
