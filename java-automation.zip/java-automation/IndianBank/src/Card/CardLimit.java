package Card;

public class CardLimit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
