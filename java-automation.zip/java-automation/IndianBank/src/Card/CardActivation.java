package Card;

public class CardActivation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
