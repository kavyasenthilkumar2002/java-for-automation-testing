package Transaction;

public class IMPSPayment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
