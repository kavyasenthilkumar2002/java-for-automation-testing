package Transaction;

public class FundTransfer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
