package Transaction;

public class RTGSPayment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
