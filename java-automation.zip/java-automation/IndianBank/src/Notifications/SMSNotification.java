package Notifications;

public class SMSNotification {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
