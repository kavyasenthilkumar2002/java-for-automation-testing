package Notifications;

public class TransactionAlert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
