package Notifications;

public class EmailNotification {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
