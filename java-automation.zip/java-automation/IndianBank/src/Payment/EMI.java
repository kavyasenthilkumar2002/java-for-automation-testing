package Payment;

public class EMI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
