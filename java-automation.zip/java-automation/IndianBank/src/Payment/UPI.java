package Payment;

public class UPI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
