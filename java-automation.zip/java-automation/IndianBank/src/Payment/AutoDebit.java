package Payment;

public class AutoDebit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
