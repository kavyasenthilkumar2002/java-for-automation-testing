package Payment;

public class RechargeService {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
