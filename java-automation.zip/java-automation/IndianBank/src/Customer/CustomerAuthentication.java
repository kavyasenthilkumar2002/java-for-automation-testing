package Customer;

public class CustomerAuthentication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
