package Customer;

public class CustomerProfile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
