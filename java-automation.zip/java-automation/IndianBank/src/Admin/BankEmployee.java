package Admin;
public class BankEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
