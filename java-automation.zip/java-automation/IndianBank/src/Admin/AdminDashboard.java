package Admin;

public class AdminDashboard {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
