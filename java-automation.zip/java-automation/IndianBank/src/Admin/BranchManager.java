package Admin;

public class BranchManager {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
