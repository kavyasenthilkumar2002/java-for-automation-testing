package Hospital_Overriding;

public class hospital_info {

	    void department(String deptName, int doctors, String head) {
	        System.out.println("DEPARTMENT INFO");
	        System.out.println("Department : " + deptName);
	        System.out.println("Doctors Available : " + doctors);
	        System.out.println("Head of Department : " + head);
	        System.out.println();
	    }

	    void patient_services(String service, String availability) {
	        System.out.println("PATIENT SERVICES");
	        System.out.println("Service : " + service);
	        System.out.println("Availability : " + availability);
	        System.out.println();
	    }

	    void emergency(String facility, String contact) {
	        System.out.println("EMERGENCY SERVICES");
	        System.out.println("Facility : " + facility);
	        System.out.println("Contact : " + contact);
	        System.out.println();
	    }
	}

