package Hospital_Overriding;

public class hospital_details {

	    void hospital_info() {
	        String name = "Kuppuswamy Hospital";
	        String type = "Multi-speciality";
	        String about = "Kuppuswamy Hospital provides quality healthcare services with advanced facilities in cardiology, neurology, pediatrics, and emergency care.";

	        System.out.println("HOSPITAL DETAILS");
	        System.out.println("Name : " + name);
	        System.out.println("Type : " + type);
	        System.out.println("About : " + about);
	        System.out.println();
	    }
	}


