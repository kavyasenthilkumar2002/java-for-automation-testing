package Hospital_Overriding;

public class Overriding {

	    void patient(String name, int age, String id) {
	        System.out.println("PATIENT DETAILS");
	        System.out.println("Name : " + name);
	        System.out.println("Age : " + age);
	        System.out.println("Patient ID : " + id);
	        System.out.println();
	    }

	    void patient(String phone, String address) {
	        System.out.println("Phone : " + phone);
	        System.out.println("Address : " + address);
	        System.out.println();
	    }

	    public static void main(String[] args) {
	        hospital_details details = new hospital_details();
	        details.hospital_info();
	        System.out.println("********");

	        Overriding p1 = new Overriding();
	        p1.patient("Ravi Kumar", 42, "HSP0987");
	        p1.patient("9876543210", "Chennai, Tamil Nadu");
	        System.out.println("********");

	        hospital_info info = new hospital_info();
	        info.department("Cardiology", 12, "Dr. Arjun");
	        info.patient_services("ICU", "24x7");
	        info.emergency("Ambulance", "108");
	    }
	}


