package ERPSystem_Overriding;

public class erp_details {

    erp_details() {
        String systemName = "ERP System";
        String systemType = "Enterprise Resource Planning";
        String about = "ERP is a business management software that integrates applications to manage core processes like finance, HR, supply chain, and operations.";

        System.out.println("ERP SYSTEM DETAILS");
        System.out.println("System Name : " + systemName);
        System.out.println("System Type : " + systemType);
        System.out.println("About : " + about);
        System.out.println();
    }
}
