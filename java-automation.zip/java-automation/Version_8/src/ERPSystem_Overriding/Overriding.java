package ERPSystem_Overriding;

public class Overriding {


	    void user_details(String username, String role, String id) {
	        System.out.println("USER DETAILS");
	        System.out.println("Username : " + username);
	        System.out.println("Role : " + role);
	        System.out.println("User ID : " + id);
	        System.out.println();
	    }

	    void user_details(int empId, String department) {
	        System.out.println("Employee ID : " + empId);
	        System.out.println("Department : " + department);
	        System.out.println();
	    }

	    public static void main(String[] args) {
	        erp_details details = new erp_details();

	        Overriding user = new Overriding();
	        user.user_details("Kavya", "Admin", "ERP0987");
	        user.user_details(1201, "Finance");
	        System.out.println("********");

	        erp_info info = new erp_info();
	        info.finance_module("Accounts", "Handles transactions, ledgers, and reporting");
	        info.hr_module("HRM", 250);
	        info.supply_chain("Inventory", "Manages stock and logistics");
	    }
	}


