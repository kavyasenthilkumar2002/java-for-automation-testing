package ERPSystem_Overriding;

public class erp_info {

	    void finance_module(String moduleName, String desc) {
	        System.out.println("FINANCE MODULE");
	        System.out.println("Name : " + moduleName);
	        System.out.println("Description : " + desc);
	        System.out.println();
	    }

	    void hr_module(String moduleName, int employeesManaged) {
	        System.out.println("HR MODULE");
	        System.out.println("Name : " + moduleName);
	        System.out.println("Employees Managed : " + employeesManaged);
	        System.out.println();
	    }

	    void supply_chain(String moduleName, String processHandled) {
	        System.out.println("SUPPLY CHAIN MODULE");
	        System.out.println("Name : " + moduleName);
	        System.out.println("Process Handled : " + processHandled);
	        System.out.println();
	    }
	}


