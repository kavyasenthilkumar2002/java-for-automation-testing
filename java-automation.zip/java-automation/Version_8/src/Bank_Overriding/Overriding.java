package Bank_Overriding;

public class Overriding {

	    void customer_details(String phone, String name, String custId) {
	        System.out.println("CUSTOMER DETAILS");
	        System.out.println("Phone Number : " + phone);
	        System.out.println("Name : " + name);
	        System.out.println("Customer ID : " + custId);
	        System.out.println();
	    }

	    // Overloaded example
	    void customer_details(int accountNo, String branch) {
	        System.out.println("Account Number : " + accountNo);
	        System.out.println("Branch : " + branch);
	        System.out.println();
	    }

	    public static void main(String[] args) {
	        // Bank Details
	        Indianbank_details detail = new Indianbank_details();
	        detail.bank_details();
	        System.out.println("-------------------------");

	        // Customer
	        Overriding cust = new Overriding();
	        cust.customer_details("9876543210", "Kavya", "IB0097");
	        cust.customer_details(12345678, "Chennai Main");
	        System.out.println("-------------------------");

	        // Bank Services
	        Indianbank_info info = new Indianbank_info();
	        info.savings_account("Regular Savings", 1000.0, 3.5f);
	        System.out.println("-------------------------");
	        info.loan_info("Home Loan", 2500000.0, 8.2f, 20);
	        System.out.println("-------------------------");
	        info.digital_services("Net Banking", "Access your account and transfer funds online");
	    }
	}


