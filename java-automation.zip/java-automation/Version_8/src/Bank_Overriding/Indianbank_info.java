package Bank_Overriding;

public class Indianbank_info {

    void savings_account(String accType, double minBalance, float interestRate) {
        System.out.println("SAVINGS ACCOUNT");
        System.out.println("Account Type : " + accType);
        System.out.println("Minimum Balance : " + minBalance);
        System.out.println("Interest Rate : " + interestRate + "%");
        System.out.println();
    }

    void loan_info(String loanType, double loanAmount, float interestRate, int tenure) {
        System.out.println("LOAN INFORMATION");
        System.out.println("Loan Type : " + loanType);
        System.out.println("Loan Amount : " + loanAmount);
        System.out.println("Interest Rate : " + interestRate + "%");
        System.out.println("Tenure : " + tenure + " years");
        System.out.println();
    }

    void digital_services(String serviceName, String description) {
        System.out.println("DIGITAL SERVICES");
        System.out.println("Service : " + serviceName);
        System.out.println("Description : " + description);
        System.out.println();
    }
}
