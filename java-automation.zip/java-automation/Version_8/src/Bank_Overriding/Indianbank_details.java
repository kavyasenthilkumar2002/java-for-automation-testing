package Bank_Overriding;

public class Indianbank_details {

    void bank_details() {
        String bankName = "Indian Bank";
        String bankType = "Public Sector Bank";
        String about = "Indian Bank is one of the leading public sector banks in India, offering banking, loans, cards, and digital services.";

        System.out.println("INDIAN BANK DETAILS");
        System.out.println("");
        System.out.println("Bank Name : " + bankName);
        System.out.println("Bank Type : " + bankType);
        System.out.println("About Bank : " + about);
        System.out.println();
    }
}
