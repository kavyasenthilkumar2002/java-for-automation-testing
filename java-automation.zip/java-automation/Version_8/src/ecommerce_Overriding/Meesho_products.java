package ecommerce_Overriding;

public class Meesho_products {
	
		void fashion_products(String dress_item, String dress_brand, int dress_price, String dress_size) {
			System.out.println("FASHION PRODUCTS");
			System.out.println("");
			System.out.println("Dress Name : " + dress_item);
			System.out.println("Brand : " + dress_brand);
			System.out.println("Price : " + dress_price);
			System.out.println("Size : " + dress_size);
			System.out.println("");
		}
		
		void home_products(String home_item, String home_brand, String home_material, int home_price) {
			System.out.println("HOME PRODUCTS");
			System.out.println("");
			System.out.println("Product Name : " + home_item);
			System.out.println("Brand : " + home_brand);
			System.out.println("Material : " + home_material);
			System.out.println("Price : " + home_price);
			System.out.println("");
		}
		
		void kitchen_products(String kitchen_item, String kitchen_brand, String kitchen_type, int kitchen_price, String kitchen_qty) {
			System.out.println("KITCHEN PRODUCTS");
			System.out.println("");
			System.out.println("Item : " + kitchen_item);
			System.out.println("Brand : " + kitchen_brand);
			System.out.println("Type : " + kitchen_type);
			System.out.println("Price : " + kitchen_price);
			System.out.println("Quantity : " + kitchen_qty);
			System.out.println("");
		}
		
		void electronics_products(String electronic_item, String electronic_brand, String electronic_specs, int electronic_price) {
			System.out.println("ELECTRONICS PRODUCTS");
			System.out.println("");
			System.out.println("Product : " + electronic_item);
			System.out.println("Brand : " + electronic_brand);
			System.out.println("Specifications : " + electronic_specs);
			System.out.println("Price : " + electronic_price);
			System.out.println("");
		}
		
		void accessories_products(String accessory_item, String accessory_brand, String accessory_type, int accessory_price) {
			System.out.println("ACCESSORIES PRODUCTS");
			System.out.println("");
			System.out.println("Product : " + accessory_item);
			System.out.println("Brand : " + accessory_brand);
			System.out.println("Type : " + accessory_type);
			System.out.println("Price : " + accessory_price);
			System.out.println("");
		}

		public static void main(String[] args) {
			Meesho_products product = new Meesho_products();
			product.fashion_products("Anarkali Kurti", "Aurelia", 799, "M");
			product.home_products("Bedsheet", "Bombay Dyeing", "Cotton", 1299);
			product.kitchen_products("Mixer Grinder", "Prestige", "3 Jar", 2999, "1 Unit");
			product.electronics_products("Earbuds", "boAt", "Bluetooth v5.1", 1499);
			product.accessories_products("Handbag", "Lavie", "Leather Tote", 2499);
		}
	}



