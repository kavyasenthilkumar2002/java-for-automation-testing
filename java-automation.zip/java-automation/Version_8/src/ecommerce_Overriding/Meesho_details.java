package ecommerce_Overriding;

public class Meesho_details {

		void meesho_details () {
			String App_name = "Meesho";
			String App_Type = "E-commerce";
			String About_Meesho = "Meesho is India’s leading social commerce platform enabling small businesses and individuals to start online stores with zero investment, offering fashion, home, and lifestyle products at affordable prices.";
		
			System.out.println("APP DETAILS");
			System.out.println("");
			System.out.println("App Name : " + App_name);
			System.out.println("App Type : " + App_Type);
			System.out.println("About Meesho : " + About_Meesho);
		}

		public static void main(String[] args) {
			Meesho_details app = new Meesho_details();
			app.meesho_details();
		}
	}


