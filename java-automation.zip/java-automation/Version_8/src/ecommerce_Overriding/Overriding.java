package ecommerce_Overriding;

public class Overriding {

	void Billing_products(String Customer_Phone_num, String customer_name, String customer_id) {
		System.out.println("Customer Phone Number : " + Customer_Phone_num);
		System.out.println("Customer Name : " + customer_name);
		System.out.println("Customer ID : " + customer_id);
	}
	
	
	void fashion_products(int order_id, String payment_mode) {
		System.out.println("Order ID : " + order_id);
		System.out.println("Payment Mode : " + payment_mode);
	}
	void kitchen_products(int order_id, String payment_mode) {
		System.out.println("Order ID : " + order_id);
		System.out.println("Payment Mode : " + payment_mode);
	}


	public static void main(String[] args) {
		
		// App Details
		Meesho_details detail = new Meesho_details();
		detail.meesho_details();   // changed to Meesho
		System.out.println("-------------------------------");
		
		// Customer Billing
		Overriding bill = new Overriding();
		bill.Billing_products("9876543210", "Kavya", "MSH0097");
		System.out.println("---------------------------------");
		
		// ✅ Use meesho_products object (not Overriding)
		Overriding product = new Overriding();
		product.fashion_products(101,"Gpay");
		product.kitchen_products(101,"Gpay");
	}
}
