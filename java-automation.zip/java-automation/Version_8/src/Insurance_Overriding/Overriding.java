package Insurance_Overriding;
public class Overriding {

    void customer(String name, String id, String phone) {
        System.out.println("CUSTOMER DETAILS");
        System.out.println("Name : " + name);
        System.out.println("Customer ID : " + id);
        System.out.println("Phone : " + phone);
        System.out.println();
    }

    void customer(int policyNo, String email) {
        System.out.println("Policy No : " + policyNo);
        System.out.println("Email : " + email);
        System.out.println();
    }

    public static void main(String[] args) {
        acko_details details = new acko_details();
        details.insurance_details();
        System.out.println("********");

        Overriding cust = new Overriding();
        cust.customer("Kavya", "ACK123", "9876543210");
        cust.customer(45789, "kavya@email.com");
        System.out.println("********");

    }
}
