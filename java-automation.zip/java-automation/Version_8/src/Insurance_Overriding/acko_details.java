package Insurance_Overriding;

public class acko_details {


	    void insurance_details() {
	        String company = "Acko Insurance";
	        String type = "General Insurance";
	        String about = "Acko Insurance offers digital-first insurance solutions including car, bike, health, and travel insurance.";

	        System.out.println("ACKO INSURANCE DETAILS");
	        System.out.println("Company : " + company);
	        System.out.println("Type : " + type);
	        System.out.println("About : " + about);
	        System.out.println();
	    }
	}

