package Insurance_Overriding;

public class AckoInfo {
	
	    void policy(String policyType, int coverageAmount, float premium) {
	        System.out.println("POLICY INFORMATION");
	        System.out.println("Policy : " + policyType);
	        System.out.println("Coverage : " + coverageAmount);
	        System.out.println("Premium : " + premium);
	        System.out.println();
	    }

	    void claim(String claimType, String status, double claimAmount) {
	        System.out.println("CLAIM INFORMATION");
	        System.out.println("Type : " + claimType);
	        System.out.println("Status : " + status);
	        System.out.println("Amount : " + claimAmount);
	        System.out.println();
	    }

	    void support(String channel, String availability) {
	        System.out.println("CUSTOMER SUPPORT");
	        System.out.println("Channel : " + channel);
	        System.out.println("Availability : " + availability);
	        System.out.println();
	    }
	}


